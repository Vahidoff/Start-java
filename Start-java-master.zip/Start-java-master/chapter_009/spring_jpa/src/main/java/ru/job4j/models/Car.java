package ru.job4j.models;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version jpa.
 * @since 2018
 */
@Entity(name = "cars")
public class Car {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column
    private String brand;

    @Column
    private String model;

    @Column
    private String transmission;

    @Column(name = "engine")
    private float engineCapacity;

    @Column
    private int year;

    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY, mappedBy = "car")
    private Declaration declaration;

    /**
     * Default constructor.
     */
    public Car() {

    }

    /**
     * Constructor with parameter.
     */
    public Car(long id) {
        this.id = id;
    }

    /**
     * Constructor with parameters.
     */
    public Car(String brand, String model, String transmission, float engineCapacity, int year) {
        this.brand = brand;
        this.model = model;
        this.transmission = transmission;
        this.engineCapacity = engineCapacity;
        this.year = year;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getTransmission() {
        return transmission;
    }

    public void setTransmission(String transmission) {
        this.transmission = transmission;
    }

    public float getEngineCapacity() {
        return engineCapacity;
    }

    public void setEngineCapacity(float engineCapacity) {
        this.engineCapacity = engineCapacity;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public Declaration getDeclaration() {
        return this.declaration;
    }

    public void setDeclaration(Declaration declaration) {
        this.declaration = declaration;
    }

    @Override
    public String toString() {
        return "Car{"
                + "id=" + id
                + ", brand='" + brand + '\''
                + ", model='" + model + '\''
                + ", transmission='" + transmission + '\''
                + ", engineCapacity=" + engineCapacity
                + ", year=" + year
                + '}';
    }
}
