package ru.job4j.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import ru.job4j.models.User;
import ru.job4j.repositories.UserRepository;

import static ru.job4j.services.ConstantKeep.NOINDB;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version security
 * @since 2018
 */
@Service
public class UserService {

    @Autowired
    UserRepository repository;

    @Autowired
    private AuthenticationManager manager;

    @Autowired
    private UserDetailsService detailsService;

    @Autowired
    private BCryptPasswordEncoder encoder;

    public User getByLoginAndPassword(final String login, final String password) {
        User user = this.repository.findUserByLogin(login);
        if (user == null || !encoder.matches(password, user.getPassword())) {
            user = new User(NOINDB);
        }
        return user;
    }

    public Long createUser(final User user) {
        this.repository.save(user);
        return user.getId();
    }

    public User getByLogin(final String login) {
        User user = this.repository.findUserByLogin(login);
        if (user == null) {
            user = new User(NOINDB);
        }
        return user;
    }

    public Object findCurrentUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        Object obj = this.repository.findUserByLogin(auth.getName());
        if (obj == null) {
            User user = new User(NOINDB);
            user.setPassword(String.valueOf(NOINDB));
            obj = user;
        }
        return obj;
    }

    public void putUserLogin(final String login, final String password) {
        UserDetails userDetails = this.detailsService.loadUserByUsername(login);
        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(
                userDetails, password, userDetails.getAuthorities());
        this.manager.authenticate(token);
        if (token.isAuthenticated()) {
            SecurityContextHolder.getContext().setAuthentication(token);
        }
    }
}
