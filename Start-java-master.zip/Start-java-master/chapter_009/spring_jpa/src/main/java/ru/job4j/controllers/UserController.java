package ru.job4j.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import ru.job4j.models.Role;
import ru.job4j.models.User;
import ru.job4j.services.RoleService;
import ru.job4j.services.UserService;

import javax.servlet.http.HttpSession;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import static ru.job4j.services.ConstantKeep.*;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version security
 * @since 2018
 */
@Controller
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private RoleService roleService;

    @Autowired
    private BCryptPasswordEncoder encoder;
    /**
     * create new User from register.jsp
     */
    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public String createUser(@RequestParam(value = "login") String login,
                             @RequestParam(value = "password") String password,
                             @RequestParam(value = "name") String name,
                             @RequestParam(value = "surname") String surname,
                             @RequestParam(value = "tel_number") String tel,
                             HttpSession session) {
        if (login.equals("") || password.equals("") || name.equals("") || tel.equals("")) {
            return "redirect:/register";
        } else {
            User userFind = this.userService.getByLogin(login);
            if (userFind.getId() == NOINDB) {
                password = this.encoder.encode(password);
                User user = new User(login, password, name, surname, tel);
                Set<Role> roles = new HashSet<>();
                roles.add(this.roleService.getRoleByName(SELLER));
                user.setRoles(roles);

                long id = this.userService.createUser(user);
                user.setId(id);
                session.setAttribute("user", user);
                this.userService.putUserLogin(login, password);
                session.setAttribute("brand", CHOOSE_ALL);
                session.setAttribute("year", CHOOSE_ALL);
                return "redirect:/";
            } else {
                return "redirect:/login";
            }
        }
    }

    /**
     * verification the login and password.
     */
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public String loginControl(@RequestParam(value = "login") String login,
                               @RequestParam(value = "password") String password,
                               HttpSession session) {
        if (Objects.equals(login, "") || Objects.equals(password, "")) {
            return "redirect:/login";
        } else {
            User userCheck = this.userService.getByLoginAndPassword(login, password);
            if (userCheck.getId() != NOINDB) {
                this.userService.putUserLogin(login, password);
                session.setAttribute("brand", CHOOSE_ALL);
                session.setAttribute("year", CHOOSE_ALL);
                return "redirect:/";
            } else {
                return "redirect:/login";
            }
        }
    }

    @RequestMapping(value = "/getuserid", method = RequestMethod.POST)
    @ResponseBody
    public long getUserId() {
         User user = (User) this.userService.findCurrentUser();
         return user.getId();
    }

}
