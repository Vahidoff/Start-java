package ru.job4j.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Repository;
import ru.job4j.models.User;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version security
 * @since 2018
 */
@Repository
public interface UserRepository extends CrudRepository<User, Integer> {

    @Nullable
    User findUserByLogin(final String login);
}
