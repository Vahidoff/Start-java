package ru.job4j.models;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Objects;
import java.util.Set;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com).
 * @version security
 * @since 2018
 */
@Entity(name = "roles")
public class Role {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column
    private String role;

    @JsonIgnore
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "user_roles", joinColumns = @JoinColumn(name = "role_id"),
                             inverseJoinColumns = @JoinColumn(name = "user_id"))
    private Set<User> users;

    public Role() {
    }

    public Role(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Set<User> getUsers() {
        return users;
    }

    public void setUsers(Set<User> users) {
        this.users = users;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || obj.getClass() != this.getClass()) {
            return false;
        }
        Role role = (Role) obj;
        return this.getId() == role.getId()
                && Objects.equals(this.role, role.getRole());
    }

    @Override
    public int hashCode() {
        int result = id;
        result = 17 * result
                + (this.role != null ? this.role.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return String.format("Role: id=%s name=%s.", this.id, this.role);
    }
}
