package ru.job4j.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.job4j.models.Foto;
import ru.job4j.repositories.FotoRepository;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version security
 * @since 2018
 */
@Service
public class FotoService {

    @Autowired
    private FotoRepository repository;

    public String getFileName(final int id) {
        return this.repository.findById((long) id).getName();
    }

    public void saveFoto(final Foto foto) {
        this.repository.save(foto);
    }

    public void deleteFoto(final Foto foto) {
        this.repository.delete(foto);
    }
}
