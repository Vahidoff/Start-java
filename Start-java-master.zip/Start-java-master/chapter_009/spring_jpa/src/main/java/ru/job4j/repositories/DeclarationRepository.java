package ru.job4j.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.job4j.models.Declaration;

import java.util.List;
import java.util.Optional;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version jpa
 * @since 2018
 */
@Repository
public interface DeclarationRepository extends CrudRepository<Declaration, Integer> {

    List<Declaration> findDeclarationByCarBrandAndCarYearOrderByCreateDate(final String brand, final int year);
    List<Declaration> findDeclarationByCarBrand(final String brand);
    List<Declaration> findDeclarationByCarYear(final int year);
    List<Declaration> findAllByOrderByCreateDateDesc();

    Optional<Declaration> findDeclarationById(final long id);

}
