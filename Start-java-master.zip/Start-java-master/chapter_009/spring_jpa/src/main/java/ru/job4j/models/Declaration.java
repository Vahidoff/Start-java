package ru.job4j.models;

import javax.persistence.*;
import java.sql.Timestamp;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version jpa
 * @since 2018
 */
@Entity(name = "declarations")
public class Declaration {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "description")
    private String desc;

    @Column
    private boolean sold;

    @Column(name = "create_date")
    private Timestamp createDate;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id")
    private User user;

    @OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.MERGE)
    @JoinColumn(name = "car_id")
    private Car car;

    @OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.MERGE)
    @JoinColumn(name = "foto_id")
    private Foto foto;

    public Declaration() {

    }
    /**
     * Constructor with parameter.
     */
    public Declaration(long id) {
        this.id = id;
    }
    /**
     * Constructor with parameters.
     */
    public Declaration(String desc, User user, Car car, Foto foto) {
        this.desc = desc;
        this.sold = false;
        this.createDate = new Timestamp(System.currentTimeMillis());
        this.user = user;
        this.car = car;
        this.foto = foto;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public void setSold(boolean sold) {
        this.sold = sold;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public long getId() {
        return id;
    }

    public String getDesc() {
        return desc;
    }

    public boolean isSold() {
        return sold;
    }

    public Timestamp getCreateDate() {
        return createDate;
    }

    public User getUser() {
        return this.user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Car getCar() {
        return this.car;
    }

    public void setCar(Car car) {
        this.car = car;
    }
    public Foto getFoto() {
        return this.foto;
    }

    public void setFoto(Foto foto) {
        this.foto = foto;
    }

    @Override
    public String toString() {
        return "Declaration{"
                + "id=" + id
                + ", desc='" + desc + '\''
                + ", sold=" + sold
                + ", createDate=" + String.valueOf(createDate)
                + ", user=" + user.getName()
                + ", car=" + car.getBrand()
                + ", foto=" + foto.getName()
                + '}';
    }
}
