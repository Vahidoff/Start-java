package ru.job4j.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import ru.job4j.models.User;
import ru.job4j.services.RoleService;
import ru.job4j.services.UserService;

import javax.servlet.http.HttpSession;

import static ru.job4j.services.ConstantKeep.ADMIN;
import static ru.job4j.services.ConstantKeep.CHOOSE_ALL;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version security
 * @since 2018
 */
@Controller
public class ViewController {

    @Autowired
    private UserService userService;

    @Autowired
    private RoleService roleService;

    @GetMapping(value = "/")
    public ModelAndView getAdverts(HttpSession session) {
        ModelAndView view = new ModelAndView();
        view.setViewName("index");
        return view;
    }

    @GetMapping(value = "/declaration")
    public ModelAndView getSigninUp() {
        ModelAndView view = new ModelAndView();
        view.setViewName("declaration");
        return view;
    }

    @RequestMapping(value = "/register", method = RequestMethod.GET)
    public ModelAndView getCreatteDeclaration() {
        ModelAndView view = new ModelAndView();
        view.setViewName("register");
        return view;
    }

    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public ModelAndView getLoginView() {
        ModelAndView view = new ModelAndView();
        view.setViewName("login");
        return view;
    }
    /**
     * log out.
     */
    @RequestMapping("/quit")
    public String quit(HttpSession session) {
        session.setAttribute("brand", CHOOSE_ALL);
        session.setAttribute("year", CHOOSE_ALL);
        return "redirect:/";
    }

    @GetMapping(value = "/edit")
    public ModelAndView getEditAdmin(HttpSession session) {
        ModelAndView view = new ModelAndView();
        User user = (User) this.userService.findCurrentUser();
        if (user.getRoles().contains(this.roleService.getRoleByName(ADMIN))) {
            view.setViewName("edit");
            session.setAttribute("brand", CHOOSE_ALL);
            session.setAttribute("year", CHOOSE_ALL);
            return view;
        } else {
            view.setViewName("index");
            return view;
        }
    }
}
