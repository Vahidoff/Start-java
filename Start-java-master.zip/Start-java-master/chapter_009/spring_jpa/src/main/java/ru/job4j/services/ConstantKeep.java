package ru.job4j.services;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version security
 * @since 2018
 */
public final class ConstantKeep {

    private ConstantKeep() {
    }

    /**
     * DeclarationController, FotoController.
     */
    public static final String IMAGES = "C:/Data/images/";
    /**
     * DeclarationService, DeclarationController, UserController, ViewController.
     */
    public static final String CHOOSE_ALL = "Choose all";
    /**
     * DeclarationService, UserService, UserController.
     */
    public static final int NOINDB = -111;

    /**
     * UserController.
     */
    public static final String SELLER = "seller";

    /**
     * ViewController.
     */
    public static final String ADMIN = "admin";
}
