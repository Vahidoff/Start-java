package ru.job4j.services;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.job4j.models.Car;
import ru.job4j.repositories.CarRepository;

import java.util.List;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version security
 * @since 2018
 */
@Service
public class CarService {

    @Autowired
    private CarRepository repository;

    public List<Car> getCars() {
        return (List<Car>) this.repository.findAll();
    }

    public void saveCar(final Car car) {
        this.repository.save(car);
    }

    public void deleteCar(final Car car) {
        this.repository.delete(car);
    }
}
