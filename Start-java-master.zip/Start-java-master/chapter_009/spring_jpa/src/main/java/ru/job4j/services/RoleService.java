package ru.job4j.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.job4j.models.Role;
import ru.job4j.repositories.RoleRepository;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version security
 * @since 2018
 */
@Service
public class RoleService {

    @Autowired
    RoleRepository repository;

    public Role getRoleByName(final String name) {
        return this.repository.findRoleByRole(name);
    }
}
