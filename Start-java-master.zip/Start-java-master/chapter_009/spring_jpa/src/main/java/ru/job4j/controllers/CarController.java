package ru.job4j.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import ru.job4j.models.Car;
import ru.job4j.services.CarService;

import java.util.List;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version jpa
 * @since 2018
 */
@Controller
public class CarController {

    @Autowired
    private CarService carService;

    @RequestMapping("/brands")
    @ResponseBody
    public List<Car> getAllCars() {
        return this.carService.getCars();
    }


}
