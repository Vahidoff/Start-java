package ru.job4j.models;

/**
 * parameters for creating a new declaration, from declaration.jsp.
 * RequestMapping(value = "/create",
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version jpa
 * @since 2018
 */
public class BlankDeclaration {

    private String desc;

    private String brand;

    private String model;

    private String transmission;

    private String year;

    private String capacity;

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getTransmission() {
        return transmission;
    }

    public void setTransmission(String transmission) {
        this.transmission = transmission;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getCapacity() {
        return capacity;
    }

    public void setCapacity(String capacity) {
        this.capacity = capacity;
    }
}
