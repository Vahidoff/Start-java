package ru.job4j.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.job4j.models.Car;
import ru.job4j.models.Declaration;
import ru.job4j.models.Foto;
import ru.job4j.models.User;
import ru.job4j.repositories.DeclarationRepository;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static ru.job4j.services.ConstantKeep.CHOOSE_ALL;
import static ru.job4j.services.ConstantKeep.NOINDB;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version security
 * @since 2018
 */
@Service
public class DeclarationService {

    @Autowired
    private DeclarationRepository repository;

    public Declaration saveDeclaration(final Declaration declaration) {
        this.repository.save(declaration);
        return declaration;
    }

    public Declaration getById(final int id) {
        Optional<Declaration> optional = this.repository.findDeclarationById((long) id);
        return optional.orElseGet(() -> new Declaration(NOINDB));
    }

    public List<Declaration> getAll(final String brand, final String year) {
        Iterable<Declaration> list;
        if (Objects.equals(brand, CHOOSE_ALL) & Objects.equals(year, CHOOSE_ALL)) {
            list = this.repository.findAllByOrderByCreateDateDesc();
        } else {
            if (Objects.equals(brand, CHOOSE_ALL)) {
                list = this.repository.findDeclarationByCarYear(Integer.parseInt(year));
            } else {
                if (Objects.equals(year, CHOOSE_ALL)) {
                    list = this.repository.findDeclarationByCarBrand(brand);
                } else {
                    list = this.repository.findDeclarationByCarBrandAndCarYearOrderByCreateDate(
                            brand, Integer.parseInt(year));
                }
            }
        }
        return (List<Declaration>) list;
    }

    public Long createDeclaration(
            final String description, final User user, final Car car, final Foto photo) {
        Declaration declaration = new Declaration(description, user, car, photo);
        this.repository.save(declaration);
        return declaration.getId();
    }

    public void deleteDeclaration(final Declaration declaration) {
        this.repository.delete(declaration);
    }
}
