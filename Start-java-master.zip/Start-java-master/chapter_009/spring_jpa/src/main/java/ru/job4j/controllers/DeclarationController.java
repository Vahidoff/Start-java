package ru.job4j.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import ru.job4j.models.*;
import ru.job4j.services.CarService;
import ru.job4j.services.DeclarationService;
import ru.job4j.services.FotoService;
import ru.job4j.services.UserService;

import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import static ru.job4j.services.ConstantKeep.CHOOSE_ALL;
import static ru.job4j.services.ConstantKeep.IMAGES;
import static ru.job4j.services.ConstantKeep.NOINDB;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version security
 * @since 2018
 */
@Controller
public class DeclarationController {

    /**
     * Advert service.
     */
    @Autowired
    private DeclarationService declarationService;

    @Autowired
    private CarService carService;

    @Autowired
    private FotoService fotoService;

    @Autowired
    private UserService userService;
    /**
     * receiving all declarations from the database.
     */
    @RequestMapping(value = "/allad", method = RequestMethod.POST)
    @ResponseBody
    public List<Declaration> getAll(HttpSession session) {
        String brand = (String) session.getAttribute("brand");
        String year = (String) session.getAttribute("year");
        if (brand == null) {
            brand = CHOOSE_ALL;
        }
        if (year == null) {
            year = CHOOSE_ALL;
        }
        return this.declarationService.getAll(brand, year);
    }
    /**
     * change the sale status.
     */
    @RequestMapping(value = "/setSold", method = RequestMethod.POST)
    public String changeStatus(@RequestParam int id) {
        Declaration declaration = this.declarationService.getById(id);
        if (declaration.getId() != NOINDB) {
            declaration.setSold(!declaration.isSold());
            this.declarationService.saveDeclaration(declaration);
        }
        return "redirect:/";
    }
    /**
     * create a new declaration.
     */
    @RequestMapping(value = "/create", method = RequestMethod.POST, consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
    public String addDeclaration(BlankDeclaration blank,
                                 HttpSession session,
                                 @RequestParam("file") MultipartFile file) throws IOException {

        Car car = new Car();
        car.setBrand(blank.getBrand());
        car.setModel(blank.getModel());
        car.setTransmission(blank.getTransmission());
        if (blank.getYear().equals("") | blank.getBrand().equals("") | blank.getModel().equals("")) {
            session.setAttribute("brand", CHOOSE_ALL);
            session.setAttribute("year", CHOOSE_ALL);
            return "redirect:/declaration";
        } else {
            car.setYear(Integer.valueOf(blank.getYear()));
            car.setEngineCapacity(Float.valueOf(blank.getCapacity()));

            Foto foto = this.putPhotoLocalStorage(file);

            User user = (User) this.userService.findCurrentUser();
            this.carService.saveCar(car);
            this.fotoService.saveFoto(foto);

            this.declarationService.createDeclaration(blank.getDesc(), user, car, foto);
            session.setAttribute("brand", CHOOSE_ALL);
            session.setAttribute("year", CHOOSE_ALL);
            return "redirect:/";
        }
    }
    /**
     * setting up the declarations filter.
     */
    @RequestMapping(value = "/change", method = RequestMethod.POST)
    public String choiceBrandYear(@RequestParam(value = "brand") String brand,
                                  @RequestParam(value = "year") String year,
                                  HttpSession session) {
        session.setAttribute("brand", brand);
        session.setAttribute("year", year);
        return "redirect:/";
    }

    @RequestMapping(value = "/deleteDec", method = RequestMethod.POST)
    public String deleteDeclaration(@RequestParam int id) {
        Declaration declaration = this.declarationService.getById(id);
        if (declaration.getId() != NOINDB) {
            Car car = declaration.getCar();
            Foto foto = declaration.getFoto();

            this.declarationService.deleteDeclaration(declaration);
            this.carService.deleteCar(car);
            this.fotoService.deleteFoto(foto);
        }
        return "redirect:/";
    }

    private Foto putPhotoLocalStorage(final MultipartFile multi) {
        Foto foto = new Foto();
        File dir = new File(IMAGES);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        File file = new File(dir.getAbsolutePath() + "/" + multi.getOriginalFilename());
        try (FileOutputStream fos = new FileOutputStream(file)) {
            fos.write(multi.getBytes());
            fos.flush();
            foto.setName(file.getName());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return foto;
    }
}
