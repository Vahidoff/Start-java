### Chapter spring_jpa
#  Сайт объявлений продаж автомобилей 
	Аналогичное web приложение как и в Chapter 2_car_site, но back-ebd выполнен с использованием 
	Spring and JPA так же Spring Security. Реализовано взоимодействие с пользователями, которые имеют разные роли. 
	Доступ к определенным страницам происходит согласно настройкам WebSecurityConfig.java
	
### Возможен просмотр всех объявлений не авторизованными пользователями, 
которые могут тутже зарегистрироваться или войти.  

<a href='https://s26.postimg.org/odu6hz3h5/anonimus.png'>
     <img src='https://s26.postimg.org/odu6hz3h5/anonimus.png' width=500>
</a>

### Подать новое объявление могут только авторизованные пользователи.

<a href='https://s26.postimg.org/wgc1jgp95/declaration.png'>
     <img src='https://s26.postimg.org/wgc1jgp95/declaration.png' width=500>
</a>

### Удалять и редактировать объявления может только администратор
 <a href='https://s26.postimg.org/mm17n24op/edit_admin.png'>
      <img src='https://s26.postimg.org/mm17n24op/edit_admin.png' width=500>
 </a>
 
  * Данные хранятся в PostgreSQL.
* При просмотре всех объявление реализован фильтр по бренду и году вупуска, что осуществляется 
запросами в БД через Spring Data — JPA. 
* Пользовательские картинки загружаются и сохраняются на сервере 
с помощью фреймворка Apache Commons FileUpload ™.
* Внешний вид реализован с помощью фреймворков Bootstrap и jQuery.

###   В приложении были использованы следующие технологии и библиотеки:
      * Spring Data — JPA
      * Spring Security
      * Tomcat Servlet Container
      * Apache Commons FileUpload
      * HTML, CSS, Bootstrap, JavaScript, jQuery, Ajax, JSON
  Предусмотрено две роли "SELLER" и "ADMIN", константы храняться в ConstantKeep.java,
Роли и пользователи связанны через таблицу user_roles. Каждому зарегистрированному
пользователю автоматически присваивается роль SELLER. Роль админа надо прописывть в БД
вручную.  
      