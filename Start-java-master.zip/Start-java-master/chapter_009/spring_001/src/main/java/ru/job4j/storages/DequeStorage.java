package ru.job4j.storages;

import org.springframework.stereotype.Component;
import ru.job4j.data.models.Foto;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Class for creating ArrayDeque storage.
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version $Id$
 * @since 2018.
 */
@Component
public class DequeStorage implements Storage {

    private Deque<Foto> deque = new ArrayDeque<>();

    @Override
    public void add(Foto photo) {
        this.deque.push(photo);
        System.out.format("Saving a %s in deque %n", photo.getName());
    }

    @Override
    public Foto getPhoto() {
        return this.deque.pop();
    }
}
