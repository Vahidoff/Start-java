package ru.job4j.storages;

import ru.job4j.data.models.Foto;

/**
 * Interface for creating storage instances.
 *
 */
public interface Storage {
    /**
     * add Entity to storage.
     */
    void add(Foto photo);

    Foto getPhoto();
}
