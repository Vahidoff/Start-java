package ru.job4j.storages;


import ru.job4j.data.models.Foto;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Class for creating LinkedHashSet storage.
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version $Id$
 * @since 2018.
 */
public class SetStorage implements Storage {

    private Set<Foto> set = new LinkedHashSet<>();

    @Override
    public void add(Foto photo) {
        this.set.add(photo);
        System.out.println(String.format("Saving a %s in LinkedHashSet %n", photo.getName()));

    }

    @Override
    public Foto getPhoto() {
        Iterator<Foto> iterator = this.set.iterator();
        Foto photo = iterator.next();
        iterator.remove();
        return photo;
    }
}
