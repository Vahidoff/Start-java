package ru.job4j.storages;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.job4j.data.models.Foto;

/**
 * storage factory for class "Foto".
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version $Id$
 * @since 2018.
 */
@Component
public class PhotoStorage {
    /**
     * User storage.
     */
    private final Storage storage;

    /**
     * Constructor.
     */
    @Autowired
    public PhotoStorage(final Storage storage) {
        this.storage = storage;
    }

    /**
     * Add user to storage.
     */
    public void add(Foto photo) {
        this.storage.add(photo);
    }

    public Foto getPhoto() {
        return this.storage.getPhoto();
    }
}
