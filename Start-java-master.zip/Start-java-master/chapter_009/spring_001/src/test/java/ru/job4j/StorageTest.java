package ru.job4j;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import ru.job4j.data.models.Foto;
import ru.job4j.storages.DequeStorage;
import ru.job4j.storages.PhotoStorage;
import ru.job4j.storages.SetStorage;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * interface "Storage" and "spring context" are testing.
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version $Id$
 * @since 2018.
 */
public class StorageTest {
    /**
     * Test 1, spring context isn't using.
     */
    @Test
    public void whenAddUserShouldContent() {
        SetStorage memory = new SetStorage();
        PhotoStorage storage = new PhotoStorage(memory);
        storage.add(new Foto("Photo fifth "));
        storage.add(new Foto("Photo sixth"));

        String verification = memory.getPhoto().getName().concat(memory.getPhoto().getName());
        String expected = "Photo fifth Photo sixth";

        assertThat(verification, is(expected));
    }
    /**
     * Test 2, spring context bean.
     */
    @Test
    public void whenMemoryStorageShouldGetMemoryStorage() {
        ApplicationContext context =
                new ClassPathXmlApplicationContext("spring-context.xml");
        DequeStorage memory = context.getBean(DequeStorage.class);

        memory.add(new Foto("Photo third"));
        memory.add(new Foto("Photo fourth "));

        String verification = memory.getPhoto().getName().concat(memory.getPhoto().getName());
        String expected = "Photo fourth Photo third";

        assertThat(verification, is(expected));
    }
    /**
     * Test 3, context:component-scan.
     */
    @Test
    public void whenUserStorageShouldGet() {
        ApplicationContext context =
                new ClassPathXmlApplicationContext("spring-context.xml");
        PhotoStorage memory = context.getBean(PhotoStorage.class);

        memory.add(new Foto("Photo seventh"));
        memory.add(new Foto("Photo eighth "));

        String verification = memory.getPhoto().getName().concat(memory.getPhoto().getName());
        String expected = "Photo eighth Photo seventh";

        assertThat(verification, is(expected));
    }
}
