package ru.job4j.storage;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import ru.job4j.ImportUser;
import ru.job4j.models.User;

import java.util.List;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

/**
 * Test User storage class.
 * Save User to hash map or to jdbc template (database).
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @since 2018.
 */
public class UserStorageTest {

    @Test
    public void whenSaveObjectShouldInStorage() {
        ApplicationContext context =
                new ClassPathXmlApplicationContext("spring-context.xml");

        Storage<User> storage = context.getBean(UserStorage.class);
        User user = new User(1, ImportUser.generateString(), ImportUser.generateString(),
                ImportUser.generateString());

        storage.save(user);
        assertThat(storage.getById(user.getId()), is(user));
    }

    @Test
    public void whenDeleteObjectShouldDeletedFromStorage() {
        ApplicationContext context =
                new ClassPathXmlApplicationContext("spring-context.xml");
        Storage<User> storage = context.getBean(UserStorage.class);

        User user = new User(1, ImportUser.generateString(), ImportUser.generateString(),
                ImportUser.generateString());
        storage.save(user);

        assertThat(storage.getById(user.getId()), is(user));

        storage.deleteObject(user);

        assertFalse(storage.getAllObject().contains(user));
    }

    @Test
    public void whenGetAllShouldReturnFullList() {
        ApplicationContext context =
                new ClassPathXmlApplicationContext("spring-context.xml");
        Storage<User> storage = context.getBean(UserStorage.class);

        User userThirty = new User(1, ImportUser.generateString(), ImportUser.generateString(),
                ImportUser.generateString());
        User userForty = new User(2, ImportUser.generateString(), ImportUser.generateString(),
                ImportUser.generateString());

        storage.save(userThirty);
        storage.save(userForty);

        List<User> list = storage.getAllObject();

        System.out.println(list);
        assertTrue(list.contains(userThirty));
        assertTrue(list.contains(userForty));
    }
}