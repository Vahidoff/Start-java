package ru.job4j.storage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.job4j.models.User;

import java.util.List;

/**
 * User storage.
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @since 04.12.2017.
 */
@Component
public class UserStorage implements Storage<User> {

    private final Storage storage;

    @Autowired
    public UserStorage(final Storage storage) {
        this.storage = storage;
    }

    @Override
    public User save(final User user) {
        return (User) this.storage.save(user);
    }

    @Override
    public User getById(final int id) {
        return (User) this.storage.getById(id);
    }

    @Override
    public List<User> getAllObject() {
        return this.storage.getAllObject();
    }

    @Override
    public void deleteObject(User entity) {
        this.storage.deleteObject(entity);
    }
}
