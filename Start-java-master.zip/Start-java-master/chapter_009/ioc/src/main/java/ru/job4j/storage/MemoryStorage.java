package ru.job4j.storage;

import ru.job4j.models.User;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Memory storage, save to object to hash map.
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @since 2018.
 */
//@Component
public class MemoryStorage implements Storage<User> {

    private final Map<Integer, User> storage;

    public MemoryStorage() {
        this.storage = new HashMap<>();
    }

    @Override
    public User save(final User user) {
        this.storage.put(user.getId(), user);
        System.out.format("User %s has been saved in HashMap<> \n", user);
        return user;
    }

    @Override
    public User getById(final int id) {
        return this.storage.get(id);
    }

    @Override
    public List<User> getAllObject() {
        return new ArrayList<>(this.storage.values());
    }

    @Override
    public void deleteObject(User entity) {
        this.storage.remove(entity.getId());
    }
}
