package ru.job4j.storage;

import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Component;
import ru.job4j.models.User;

import java.io.IOException;
import java.io.InputStream;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.Properties;

/**
 * Jdbc storage, save to object to database with spring jdbcTemplate.
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @since 2018.
 */
@Component
public class JdbcStorage implements Storage<User> {

    /**
     * Spring jdbcTemplate.
     */
    private JdbcTemplate jdbcTemplate;

    private String tableName;
    private static final org.slf4j.Logger LOG = LoggerFactory.getLogger(JdbcStorage.class);

    /**
     * Constructor.
     */
    public JdbcStorage(final JdbcTemplate jdbcTemplate) throws IOException {
        this.getProperties();
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public User save(final User user) {
        final String sql =
                String.format("insert into %s (name, login, password) values (?, ?, ?)",
                        this.tableName);
        final KeyHolder keyHolder = new GeneratedKeyHolder();

        jdbcTemplate.update(
                connection -> {
                    PreparedStatement ps = connection.prepareStatement(sql, new String[]{"id"});
                    ps.setString(1, user.getName());
                    ps.setString(2, user.getLogin());
                    ps.setString(3, user.getPassword());
                    return ps;
                }, keyHolder);

        user.setId(keyHolder.getKey().intValue());
        return user;
    }

    @Override
    public User getById(final int id) {

        List<User> users = jdbcTemplate.query(String.format("select * from %s where id =?",
                this.tableName),
                new Object[]{id}, (resultSet, i) -> new User(
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getString("login"),
                        resultSet.getString("password")));
        if (users.size() == 1) {
            return users.get(0);
        } else {
            return null;
        }
    }

    @Override
    public List<User> getAllObject() {
        final String query = String.format("select * from %s", this.tableName);
        return this.jdbcTemplate.query(query, new BeanPropertyRowMapper<>(User.class));
    }

    @Override
    public void deleteObject(final User entity) {
        jdbcTemplate.update(String.format("delete from %s where id = ?", this.tableName),
                entity.getId());
    }

    private void getProperties() throws IOException {
        Properties properties = new Properties();
        try (InputStream in = this.getClass().getClassLoader().
                getResourceAsStream("connection.properties")) {
            properties.load(in);

            this.tableName = properties.getProperty("tableName");

        } catch (IOException e) {
            LOG.error(e.getMessage(), e);
        }
    }
}
