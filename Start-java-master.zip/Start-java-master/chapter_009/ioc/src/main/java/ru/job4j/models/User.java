package ru.job4j.models;

import java.util.Objects;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @since 2018.
 */

public class User {

    private int id;

    private String name;

    private String login;

    private String password;

    public User() {

    }

    public User(int id, String name, String login, String password) {
        this.id = id;
        this.name = name;
        this.login = login;
        this.password = password;
    }

    public int getId() {
        return id;
    }

    public void setId(final int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(final String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(final String password) {
        this.password = password;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || obj.getClass() != this.getClass()) {
            return false;
        }
        User user = (User) obj;
        return this.getId() == user.getId()
                && Objects.equals(this.getName(), user.getName())
                && Objects.equals(this.getLogin(), user.getLogin())
                && Objects.equals(this.getPassword(), user.getPassword());
    }
    @Override
    public int hashCode() {
        int result = id;
        result = 17 * result
                + (this.name != null ? this.name.hashCode() : 0)
                + (this.login != null ? this.login.hashCode() : 0)
                + (this.password != null ? this.password.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "User{"
                + "id=" + id
                + ", name='" + name + '\''
                + ", login='" + login + '\''
                + ", password='" + password + '\''
                + '}';
    }
}
