package ru.job4j.storage;

import java.util.List;

/**
 * Storage interface.
 * @since 2018.
 */
public interface Storage<T> {

    T save(final T entity);

    T getById(final int id);

    List<T> getAllObject();

    void deleteObject(final T entity);
}
