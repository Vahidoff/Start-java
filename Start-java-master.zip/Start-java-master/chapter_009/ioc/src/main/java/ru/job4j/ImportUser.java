package ru.job4j;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import ru.job4j.models.User;
import ru.job4j.storage.Storage;
import ru.job4j.storage.UserStorage;

import java.util.UUID;

/**
 * Run for jdbc template (database), then the id will change in accordance with the database.
 * users can also be saved in memory: MemoryStorage.
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @since 2018.
 */
public class ImportUser {

    public static void main(String[] args) {
        ApplicationContext context =
                new ClassPathXmlApplicationContext("spring-context.xml");
        Storage<User> storage = context.getBean(UserStorage.class);

        User userOne = new User(1, generateString(), generateString(), generateString());
        storage.save(userOne);
        User userTwo = new User(2, generateString(), generateString(), generateString());
        storage.save(userTwo);

        System.out.format("Receiving a userOne through an id %s %n", storage.getById(userOne.getId()));

        System.out.format("Receiving all user %s %n", storage.getAllObject());

        storage.deleteObject(userOne);
        System.out.format("After the userOne is deleted receiving all user %s %n",
                storage.getAllObject());
    }

    public static String generateString() {
        return UUID.randomUUID().toString().substring(25);
    }
}
