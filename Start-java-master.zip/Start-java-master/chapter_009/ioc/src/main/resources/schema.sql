CREATE TABLE users (
  id       SERIAL PRIMARY KEY,
  name     VARCHAR(100),
  login    VARCHAR(100) NOT NULL,
  password VARCHAR(100) NOT NULL
);