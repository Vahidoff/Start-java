### Chapter_009

### Chapter ioc
* Реализованно приложение: сохранение данных пользователей,
на основе Spring Framework IoC.
* Данные храняться в PostgreSql или HashMap.
* Выбор хранилища происходит указанием аннотации @Component
в классах JdbcStorage или MemoryStorage соответственно.