package ru.job4j;

/**
 * factory for classes "A" and "B".
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version $Id$
 * @since 2018.
 */
public class PuttableFactory {

    private static final Puttable PUT = new B();
    private static final Puttable PUTTABLE = new A();

    public static Puttable getPutA() {
        return PUTTABLE;
    }

    public static Puttable getPutB() {
        return PUT;
    }
}
