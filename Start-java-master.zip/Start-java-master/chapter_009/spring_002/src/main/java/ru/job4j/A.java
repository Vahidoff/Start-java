package ru.job4j;

import java.util.LinkedHashMap;
import java.util.Map;

public class A implements Puttable {

    private int index = 1;

    private Map<String, String> mapA = new LinkedHashMap<>();

    private static final String MAP = "AMap";

    @Override
    public void putObj(String s) {
        this.mapA.put(MAP + this.index++, s);
    }

    @Override
    public Map<String, String> getMap() {
        return this.mapA;
    }
}
