package ru.job4j;

import java.util.Map;

/**
 * interface for different "map".
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version $Id$
 * @since 2018.
 */
public interface Puttable {

    void putObj(String s);

    Map<String, String> getMap();
}
