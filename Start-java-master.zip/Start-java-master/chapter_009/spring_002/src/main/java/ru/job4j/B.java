package ru.job4j;

import java.util.IdentityHashMap;
import java.util.Map;

public class B implements Puttable {

    private int index = 1;

    private Map<String, String> mapB = new IdentityHashMap<>();

    private static final String MAP = "BMap";

    @Override
    public void putObj(String s) {
        this.mapB.put(MAP + this.index, s);
    }

    @Override
    public Map<String, String> getMap() {
        return this.mapB;
    }
}
