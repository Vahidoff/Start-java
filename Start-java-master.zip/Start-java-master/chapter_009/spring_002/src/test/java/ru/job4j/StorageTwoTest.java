package ru.job4j;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Iterator;
import java.util.Set;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * interface "Puttable" and "spring context" are testing.
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version $Id$
 * @since 2018.
 */
public class StorageTwoTest {

    /**
     * method "putObj" from class "A" is testing.
     */
    @Test
    public void testOne() {
        ApplicationContext context =
                new ClassPathXmlApplicationContext("spring-context.xml");

        Puttable aObj = (Puttable) context.getBean("p");

        aObj.putObj("Test twenty first");
        aObj.putObj("Test thirty second");

        System.out.println(aObj.getMap());

        Set<String> keyA = aObj.getMap().keySet();
        Iterator<String> iterator = keyA.iterator();
        String verification = iterator.next().concat(iterator.next());
        String expected = "AMap1AMap2";

        assertThat(verification, is(expected));
    }

    /**
     * method "putObj" from class "B" is testing.
     */
    @Test
    public void testTwo() {
        ApplicationContext context =
                new ClassPathXmlApplicationContext("spring-context.xml");

        Puttable bObj = (Puttable) context.getBean("b");

        bObj.putObj("Test fifty-fourth");
        bObj.putObj("Test forty-third");

        System.out.println(bObj.getMap());

        Set<String> keyB = bObj.getMap().keySet();
        Iterator<String> iterator = keyB.iterator();
        String verification = iterator.next().concat(iterator.next());
        String expected = "BMap1BMap1";

        assertThat(verification, is(expected));
    }

}
