## Chapter spring_mvc
#  Сайт объявлений продаж автомобилей 
	Это web приложение по функционалу полностью совпадает с приложением
	из Chapter 2_car_site.
	Однако back-ebd полностью переработан и основан на Spring MVC
	
### Список объявлений:	
<a href='https://s26.postimg.org/wosrb1tx5/Car_shop_mvc.png'>
     <img src='https://s26.postimg.org/wosrb1tx5/Car_shop_mvc.png' width=500>
</a>
     
### Реализован двухуровневый пользовательский фильтр
<a href='https://s26.postimg.org/i5lm9pt3d/choice_mvc.png'>
<img src='https://s26.postimg.org/i5lm9pt3d/choice_mvc.png' width=500>
</a>

### Данные хранятся в PostgreSQL, а доступ к ней обеспечивается с помощью HibernateTemplate.

 Пользовательские картинки загружаются и сохраняются на сервере 
с помощью фреймворка Apache Commons FileUpload.
Внешний вид реализован с помощью фреймворков Bootstrap и jQuery.

      В приложении были использованы следующие технологии и библиотеки:
      * Spring MVC
      * Hibernate ORM
      * Hibernate HQL
      * Tomcat Servlet Container
      * Apache Commons FileUpload
      * HTML, CSS, Bootstrap, JavaScript, jQuery, Ajax, JSON