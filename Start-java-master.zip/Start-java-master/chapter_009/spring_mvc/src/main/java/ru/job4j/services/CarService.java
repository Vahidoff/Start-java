package ru.job4j.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.job4j.models.Car;
import ru.job4j.storage.DbStorage;

import java.util.List;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @since 2018
 */
@Service
public class CarService {

    @Autowired
    private DbStorage storage;

    public List<Car> getCars() {
        return this.storage.getCars();
    }

    public void saveCar(Car car) {
        this.storage.saveCar(car);
    }

}
