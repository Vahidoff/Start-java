package ru.job4j.models;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @since 2018
 */
public class Foto {

    private long id;

    private String name;

    public Foto(String name) {
        this.name = name;
    }

    public Foto() {
    }

    public Foto(long id) {
        this.id = id;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
