package ru.job4j.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.job4j.models.Car;
import ru.job4j.models.Declaration;
import ru.job4j.models.Foto;
import ru.job4j.models.User;
import ru.job4j.storage.DbStorage;

import java.util.List;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @since 2018
 */
@Service
public class DeclarationService {

    @Autowired
    private DbStorage storage;

    /**
     * Uses storage what would save a advert to database.
     */
    public Long saveDeclaration(final Declaration declaration) {
        return this.storage.saveDeclaration(declaration);
    }

    /**
     * Uses storage what would get a advert by id.
     */
    public Declaration getById(final int id) {
        return this.storage.getDeclarationById(id);
    }

    /**
     * Uses storage what would get the list of a adverts.
     */
    public List<Declaration> getAll(String brand, String year) {
        return this.storage.getAll(brand, year);
    }

    public Long createAdvertisement(String description, User user, Car car, Foto photo) {
        return this.storage.createAdvertisement(description, user, car, photo);
    }
}
