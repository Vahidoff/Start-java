package ru.job4j.controllers;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import ru.job4j.services.FotoService;

import java.io.*;

import static ru.job4j.services.ConstantKeep.IMAGES;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @since 2018
 */
@Controller
public class FotoController {

    @Autowired
    private FotoService fotoService;
    /**
     * sending an image to a index.jsp.
     */
    @ResponseBody
    @GetMapping(value = "/image/{photoID}", produces = MediaType.IMAGE_JPEG_VALUE)
    public byte[] getPhoto(@PathVariable final int photoID) throws IOException {
        File file = new File(IMAGES + fotoService.getFileName(photoID));
        InputStream input = new FileInputStream(file);
        return IOUtils.toByteArray(input);
    }
}
