package ru.job4j.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.job4j.models.Foto;
import ru.job4j.storage.DbStorage;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @since 2018
 */
@Service
public class FotoService {

    @Autowired
    private DbStorage storage;

    public String getFileName(final int id) {
        return this.storage.getFileName(id);
    }

    public void saveFoto(Foto foto) {
        this.storage.saveFoto(foto);
    }
}
