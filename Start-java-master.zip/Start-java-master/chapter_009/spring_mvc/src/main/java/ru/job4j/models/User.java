package ru.job4j.models;

import org.hibernate.Hibernate;
import org.hibernate.proxy.HibernateProxy;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @since 2018
 */
public class User {

    private long id;

    private String login;

    private String password;

    private String name;

    private String surname;

    private String telNumber;

    private List<Declaration> declarationList;

    /**
     * Default constructor.
     */
    public User() {

    }

    /**
     * Constructor with parameter.
     */
    public User(long id) {
        this.id = id;
    }

    /**
     * Constructor with parameter.
     */
    public User(String login, String password, String name, String surname,
                String telNumber) {
        this.login = login;
        this.password = password;
        this.name = name;
        this.surname = surname;
        this.telNumber = telNumber;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getTelNumber() {
        return telNumber;
    }

    public void setTelNumber(String telNumber) {
        this.telNumber = telNumber;
    }

    public List<Declaration> getDeclarationList() {
        List<Declaration> result = null;
        if (this.declarationList != null && this.declarationList.size() != 0) {
            result = new ArrayList<>();
            for (Declaration declaration : declarationList) {
                if (declaration instanceof HibernateProxy) {
                    Hibernate.initialize(declaration);
                    declaration = (Declaration) ((HibernateProxy) declaration)
                            .getHibernateLazyInitializer()
                            .getImplementation();
                    result.add(declaration);
                }
            }
        }
        return result;
    }

    public void setDeclarationList(List<Declaration> declarationList) {
        this.declarationList = declarationList;
    }

    @Override
    public String toString() {

        return "User{"
                + "id=" + id
                + ", login='" + login + '\''
                + ", password='" + password + '\''
                + ", name='" + name + '\''
                + ", surname='" + surname + '\''
                + ", telNumber='" + telNumber + '\''
                + '}';
    }
}
