package ru.job4j.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @since 2018
 */
@Controller
public class ViewController {

    private static final String CHOOSE_ALL = "Choose all";

    @GetMapping(value = "/index")
    public ModelAndView getAdverts() {
        ModelAndView view = new ModelAndView();
        view.setViewName("index");
        return view;
    }

    @GetMapping(value = "/declaration")
    public ModelAndView getSigninUp() {
        ModelAndView view = new ModelAndView();
        view.setViewName("declaration");
        return view;
    }

    @RequestMapping(value = "/register", method = RequestMethod.GET)
    public ModelAndView getCreatteDeclaration() {
        ModelAndView view = new ModelAndView();
        view.setViewName("register");
        return view;
    }

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public ModelAndView getLoginView() {
        ModelAndView view = new ModelAndView();
        view.setViewName("login");
        return view;
    }
    /**
     * log out.
     */
    @RequestMapping("/quit")
    public String quit(HttpSession session) {
        session.removeAttribute("user");
        session.setAttribute("brand", CHOOSE_ALL);
        session.setAttribute("year", CHOOSE_ALL);
        return "redirect:/";
    }
}
