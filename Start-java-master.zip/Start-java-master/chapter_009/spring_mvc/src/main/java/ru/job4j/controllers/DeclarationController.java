package ru.job4j.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import ru.job4j.models.Car;
import ru.job4j.models.Declaration;
import ru.job4j.models.Foto;
import ru.job4j.models.User;
import ru.job4j.services.CarService;
import ru.job4j.services.DeclarationService;
import ru.job4j.services.FotoService;

import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import static ru.job4j.services.ConstantKeep.CHOOSE_ALL;
import static ru.job4j.services.ConstantKeep.IMAGES;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @since 2018
 */
@Controller
public class DeclarationController {

    /**
     * Advert service.
     */
    @Autowired
    private DeclarationService declarationService;

    @Autowired
    private CarService carService;

    @Autowired
    private FotoService fotoService;
    /**
     * receiving all declarations from the database.
     */
    @RequestMapping(value = "/allad", method = RequestMethod.POST)
    @ResponseBody
    public List<Declaration> getAll(HttpSession session) {
        return this.declarationService.getAll(
                (String) session.getAttribute("brand"),
                (String) session.getAttribute("year"));
    }
    /**
     * change the sale status.
     */
    @RequestMapping(value = "/setSold", method = RequestMethod.POST)
    public String changeStatus(@RequestParam int id) {
        Declaration declaration = this.declarationService.getById(id);
        declaration.setSold(!declaration.isSold());
        this.declarationService.saveDeclaration(declaration);
        return "redirect:/index";
    }
    /**
     * create a new declaration.
     */
    @RequestMapping(value = "/create", method = RequestMethod.POST, consumes = {MediaType.MULTIPART_FORM_DATA_VALUE})
    public String addDeclaration(
                                 @RequestParam(value = "desc") String description,
                                 @RequestParam(value = "brand") String brand,
                                 @RequestParam(value = "model") String model,
                                 @RequestParam(value = "transmission") String transmission,
                                 @RequestParam(value = "year") String year,
                                 @RequestParam(value = "capacity") String capacity,
                                 HttpSession session,
                                 @RequestParam("file") MultipartFile file) throws IOException {

        Car car = new Car();
        car.setBrand(brand);
        car.setModel(model);
        car.setTransmission(transmission);
        if (year.equals("") | car.getBrand().equals("") | car.getModel().equals("")) {
            session.setAttribute("brand", CHOOSE_ALL);
            session.setAttribute("year", CHOOSE_ALL);
            return "redirect:/declaration";
        } else {
            car.setYear(Integer.valueOf(year));
            car.setEngineCapacity(Float.valueOf(capacity));

            Foto foto = this.putPhotoLocalStorage(file);

            User user = (User) session.getAttribute("user");
            this.carService.saveCar(car);
            this.fotoService.saveFoto(foto);

            this.declarationService.createAdvertisement(description, user, car, foto);
            session.setAttribute("brand", CHOOSE_ALL);
            session.setAttribute("year", CHOOSE_ALL);
            return "redirect:/index";
        }
    }
    /**
     * setting up the declarations filter.
     */
    @RequestMapping(value = "/change", method = RequestMethod.POST)
    public String choiceBrandYear(@RequestParam(value = "brand") String brand,
                                  @RequestParam(value = "year") String year,
                                  HttpSession session) {
        session.setAttribute("brand", brand);
        session.setAttribute("year", year);
        return "redirect:/index";
    }

    private Foto putPhotoLocalStorage(final MultipartFile multi) {
        Foto foto = new Foto();
        File dir = new File(IMAGES);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        File file = new File(dir.getAbsolutePath() + "/" + multi.getOriginalFilename());
        try (FileOutputStream fos = new FileOutputStream(file)) {
            fos.write(multi.getBytes());
            fos.flush();
            foto.setName(file.getName());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return foto;
    }
}
