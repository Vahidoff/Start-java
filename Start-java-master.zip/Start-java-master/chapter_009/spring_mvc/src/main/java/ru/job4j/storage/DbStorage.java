package ru.job4j.storage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import ru.job4j.models.Declaration;
import ru.job4j.models.Car;
import ru.job4j.models.Foto;
import ru.job4j.models.User;

import java.util.List;
import java.util.Objects;

import static ru.job4j.services.ConstantKeep.NOINDB;
import static ru.job4j.services.ConstantKeep.CHOOSE_ALL;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @since 2018
 */
@Repository
public class DbStorage {

    @Autowired
    private HibernateTemplate template;

    @Transactional()
    public Long createAdvertisement(String description, User user, Car car, Foto photo) {
        Declaration declaration = new Declaration(description, user, car, photo);
        this.template.save(declaration);
        return user.getId();
    }

    @Transactional()
    public Long saveDeclaration(final Declaration declaration) {
        this.template.saveOrUpdate(declaration);
        return declaration.getId();
    }

    public List<Car> getCars() {
        List<?> list = this.template.find("FROM Car");
        return (List<Car>) list;
    }

    @Transactional
    public void saveCar(Car car) {
        this.template.save(car);
    }

    public String getFileName(final int id) {
        return (String) this.template.find(
                "SELECT f.name from Foto as f where f.id=?", (long) id).get(0);
    }

    @Transactional
    public void saveFoto(Foto photo) {
        this.template.save(photo);
    }

    public Declaration getDeclarationById(final int id) {
        return this.template.get(Declaration.class, (long) id);
    }

    public List<Declaration> getAll(String brand, String year) {
        List<Declaration> result;
        if (Objects.equals(brand, CHOOSE_ALL) & Objects.equals(year, CHOOSE_ALL)) {
            result = this.getAllDeclaration();
        } else {
            List<?> list;
                if (Objects.equals(brand, CHOOSE_ALL)) {
                    list = this.template.find(
                            "from Declaration as d where d.car.year=?",
                            Integer.valueOf(year));
                } else {
                    if (Objects.equals(year, CHOOSE_ALL)) {
                        list = this.template.find(
                                "from Declaration as d where d.car.brand=?", brand);
                    } else {
                        list = this.template.find(
                                "from Declaration as d where d.car.brand=? "
                                 + "AND d.car.year=?", brand, Integer.valueOf(year));
                    }
                }
                result = (List<Declaration>) list;
        }
        return result;
    }

    private List<Declaration> getAllDeclaration() {
        List<?> list = this.template.find(
                "FROM Declaration as d order by d.createDate desc");
        return (List<Declaration>) list;
    }


    public User getUserByLoginAndPassword(String login, String password) {
        List<?> objects = this.template.find(
                "from User as u where u.login=? and u.password=?", login, password);
        if (objects.isEmpty()) {
            return new User(NOINDB);
        } else {
            return (User) objects.get(0);
        }
    }

    @Transactional()
    public Long createUser(final User user) {
        this.template.saveOrUpdate(user);
        return user.getId();
    }

}
