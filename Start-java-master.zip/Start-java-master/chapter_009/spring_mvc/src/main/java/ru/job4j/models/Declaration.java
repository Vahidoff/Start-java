package ru.job4j.models;

import org.hibernate.Hibernate;
import org.hibernate.proxy.HibernateProxy;

import java.sql.Timestamp;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @since 2018
 */
public class Declaration {

    private long id;

    private String desc;

    private boolean sold;

    private Timestamp createDate;

    private User user;

    private Car car;

    private Foto foto;

    public Declaration() {

    }
    /**
     * Constructor with parameter.
     */
    public Declaration(long id) {
        this.id = id;
    }
    /**
     * Constructor with parameters.
     */
    public Declaration(String desc, User user, Car car, Foto foto) {
        this.desc = desc;
        this.sold = false;
        this.createDate = new Timestamp(System.currentTimeMillis());
        this.user = user;
        this.car = car;
        this.foto = foto;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public void setSold(boolean sold) {
        this.sold = sold;
    }

    public void setCreateDate(Timestamp createDate) {
        this.createDate = createDate;
    }

    public long getId() {
        return id;
    }

    public String getDesc() {
        return desc;
    }

    public boolean isSold() {
        return sold;
    }

    public Timestamp getCreateDate() {
        return createDate;
    }

    public User getUser() {
        if (user instanceof HibernateProxy) {
            Hibernate.initialize(user);
            user = (User) ((HibernateProxy) user)
                    .getHibernateLazyInitializer()
                    .getImplementation();
        }
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Car getCar() {
        if (car instanceof HibernateProxy) {
            Hibernate.initialize(car);
            car = (Car) ((HibernateProxy) car)
                    .getHibernateLazyInitializer()
                    .getImplementation();
        }
        return car;
    }

    public Foto getFoto() {
        if (foto instanceof HibernateProxy) {
            Hibernate.initialize(foto);
            foto = (Foto) ((HibernateProxy) foto)
                    .getHibernateLazyInitializer()
                    .getImplementation();
        }
        return foto;
    }

    public void setFoto(Foto foto) {
        this.foto = foto;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    @Override
    public String toString() {
        return "Declaration{"
                + "id=" + id
                + ", desc='" + desc + '\''
                + ", sold=" + sold
                + ", createDate=" + String.valueOf(createDate)
                + ", user=" + user.getName()
                + ", car=" + car.getBrand()
                + ", foto=" + foto.getName()
                + '}';
    }
}
