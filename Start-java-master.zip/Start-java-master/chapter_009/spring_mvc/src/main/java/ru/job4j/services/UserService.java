package ru.job4j.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.job4j.models.User;
import ru.job4j.storage.DbStorage;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @since 2018
 */
@Service
public class UserService {

    @Autowired
    private DbStorage storage;

    public User getUserByLoginAndPassword(String login, String password) {
        return this.storage.getUserByLoginAndPassword(login, password);
    }

    public Long createUser(final User user) {
        return this.storage.createUser(user);
    }

}
