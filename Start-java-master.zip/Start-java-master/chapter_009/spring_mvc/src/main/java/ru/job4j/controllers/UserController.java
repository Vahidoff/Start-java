package ru.job4j.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import ru.job4j.models.User;
import ru.job4j.services.UserService;

import javax.servlet.http.HttpSession;
import java.util.Objects;

import static ru.job4j.services.ConstantKeep.CHOOSE_ALL;
import static ru.job4j.services.ConstantKeep.NOINDB;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @since 2018
 */
@Controller
public class UserController {

    @Autowired
    private UserService userService;
    /**
     * create new User from register.jsp
     */
    @RequestMapping(value = "/signinup", method = RequestMethod.POST)
    public String createUser(@RequestParam(value = "login") String login,
                             @RequestParam(value = "password") String password,
                             @RequestParam(value = "name") String name,
                             @RequestParam(value = "surname") String surname,
                             @RequestParam(value = "tel_number") String tel,
                             HttpSession session) {
        if (login.equals("") || password.equals("") || name.equals("") || tel.equals("")) {
            return "redirect:/register";
        } else {
            User userOptional = this.userService.getUserByLoginAndPassword(login, password);
            if (userOptional.getId() == NOINDB) {
                User user = new User(login, password, name, surname, tel);
                long id = this.userService.createUser(user);
                user.setId(id);
                session.setAttribute("user", user);
                session.setAttribute("brand", CHOOSE_ALL);
                session.setAttribute("year", CHOOSE_ALL);
                return "redirect:/index";
            } else {
                return "redirect:/";
            }
        }
    }

    /**
     * verification the login and password.
     */
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public String loginControl(@RequestParam(value = "login") String login,
                               @RequestParam(value = "password") String password,
                               HttpSession session) {
        if (Objects.equals(login, "") || Objects.equals(password, "")) {
            return "redirect:/";
        } else {
            User userCheck = this.userService.getUserByLoginAndPassword(login, password);
            if (userCheck.getId() != NOINDB) {
                session.setAttribute("user", userCheck);
                session.setAttribute("brand", CHOOSE_ALL);
                session.setAttribute("year", CHOOSE_ALL);
                return "redirect:/index";
            } else {
                return "redirect:/";
            }
        }
    }

    @RequestMapping("/getUser")
    @ResponseBody
    public User getUser(HttpSession session) {
        return (User) session.getAttribute("user");
    }

}
