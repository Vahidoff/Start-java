package ru.job4j.loop;
 /**
 * Paint.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Paint {
	/**
	 * Piramid.
     * the sum of the even numbers of the range
	 * @param h - pyramid height
	 * @return pyramid
	 */
	public String piramid(int h) {
		StringBuilder pyramid = new StringBuilder();
		for (int index = 1; index <= h; index++) {
			for (int beam = 1; beam <= (2 * h - 1); beam++) {
				if ((h - index) < beam & beam < (h + index)) {
					pyramid.append('^');
				} else {
				pyramid.append(' ');
				}
			}
			if (h == index) {
				break;
			}
			pyramid.append(System.getProperty("line.separator"));
		}
		return pyramid.toString();
	}
}