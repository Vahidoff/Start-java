package ru.job4j.loop;
 /**
 * Board.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Board {
	/**
     * @param colour - cell color.
    */
    private int colour = 1;
	/**
	 * Paint.
     * the sum of the even numbers of the range
	 * @param width - board width
	 * @param height - board height
	 * @return chess board
	 */
	public String paint(int width, int height) {
		StringBuilder chess = new StringBuilder();
		for (int index = 0; index < height; index++) {
			for (int beam = 0; beam < width; beam++) {
				if ((colour % 2) == 0) {
					chess.append(' ');
					} else {
						chess.append('x');
					}
					colour++;
				}
				chess.append(System.getProperty("line.separator"));
		}
		return chess.toString();
	}
}