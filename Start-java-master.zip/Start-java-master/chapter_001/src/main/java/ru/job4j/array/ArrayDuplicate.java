package ru.job4j.array;
import java.util.Arrays;
 /**
 * ArrayDuplicate.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class ArrayDuplicate {
	/**
	 * remove.
     * getting rid of repetitions in an array
	 * @param array - source array
	 * @return changes array
	 */
	public String[] remove(String[] array) {
		int max = array.length - 1;
		String temp;
		for (int index = 0; index < max; index++) {
			for (int beam = index + 1; beam <= max; beam++) {
				if (array[index] == array[beam]) {
					temp = array[max];
					array[max] = array[beam];
					array[beam] = temp;
					beam--;
					max--;
				}
			}
		}
		return Arrays.copyOf(array, (max + 1));
	}
}