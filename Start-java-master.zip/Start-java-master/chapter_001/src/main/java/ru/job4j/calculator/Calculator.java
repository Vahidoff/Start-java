package ru.job4j.calculator;
/**
 * Calculator.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */

public class Calculator {
	/**
     * @param result.
    */
    private double result;
	/**
	 * Add.
     * сложение.
	 * @param first - первое число
	 * @param second - второе число
    */
    public void add(double first, double second) {
        this.result = first + second;
    }
	/**
	 * Substruck.
     * вычитание.
	 * @param first - первое число
	 * @param second - второе число
    */
	public void substruck(double first, double second) {
        this.result = first - second;
    }
    /**
	 * Div.
     * деление.
	 * @param first - первое число
	 * @param second - второе число
    */
	public void div(double first, double second) {
        this.result = first / second;
    }
	/**
	 * Multiple.
     * умножение.
	 * @param first - первое число
	 * @param second - второе число
    */
	public void multiple(double first, double second) {
        this.result = first * second;
    }
	/**
	 * GetResult.
     * @return возвращение результата.
    */
    public double getResult() {
        return this.result;
    }
}