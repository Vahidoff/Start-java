package ru.job4j.array;
 /**
 * BubbleSort.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class BubbleSort {
	/**
	 * Sort.
     * sort a massive ascending order
	 * @param array - source array
	 * @return changes array
	 */
	public int[] sort(int[] array) {
		int temp;
		int right = array.length - 1;
		for (int beam = 0; beam < (array.length - 1); beam++) {
			for (int index = 0; index < right; index++) {
				if (array[index] > array[index + 1]) {
					temp = array[index + 1];
					array[index + 1] = array[index];
					array[index] = temp;
				}
			}
			right--;
		}
		return array;
	}
}