package ru.job4j.max;
/**
 * Max.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Max {
	/**
	 * Max.
     * максимальное число.
	 * @param first - первое число
	 * @param second - второе число
	 * @return max
	 */
    public int max(int first, int second) {
		return (first > second ? first : second);
	}
	/**
	 * Maxtriple.
     * максимальное число of three.
	 * @param first - первое число
	 * @param second - второе число
	 * @param third - third number
	 * @return maxtriple
	 */
	public int maxtriple(int first, int second, int third) {
		return (max(third, (max(first, second))));
	}
}