package ru.job4j.array;
 /**
 * PartArray.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class PartArray {
	/**
	* @param rule.
	*/
	private boolean rule;
	/**
	 * contains.
     * the content of a string in another
	 * @param origin - large string
	 * @param sub - substring
	 * @return boolean
	 */
	public boolean contains(String origin, String sub) {
		char[] large = origin.toCharArray();
		char[] small = sub.toCharArray();
		int max = large.length - small.length;
		for (int index = 0; index <= max; index++) {
			int beam = index;
			for (char letter : small) {
				if (large[beam] == letter) {
					rule = true;
					beam++;
				} else {
					rule = false;
					break;
				}
			}
			if (rule) {
				break;
			}
		}
		return rule;
	}
}