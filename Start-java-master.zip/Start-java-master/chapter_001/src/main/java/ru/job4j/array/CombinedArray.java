package ru.job4j.array;
 /**
 * CombinedArray.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class CombinedArray {
	/**
	 * Integration.
     * combining sorted arrays
	 * @param a - large array
	 * @param b - small array
	 * @return combined array
	 */
	public int[] integration(int[] a, int[] b) {
		int[] joint = new int[a.length + b.length];
		/**
		* @param indexA - a array's counter.
		* @param indexB - b array's counter.
		*/
		int indexA = 0;
		int indexB = 0;
		for (int i = 0; i < (a.length + b.length); i++) {
			if ((b.length == 0 || indexB > (b.length - 1)) || (a.length != 0 && (indexA < a.length & a[indexA] <= b[indexB]))) {
				joint[i] = a[indexA];
				indexA++;
			} else {
				joint[i] = b[indexB];
				indexB++;
			}
		}
		return joint;
	}
}