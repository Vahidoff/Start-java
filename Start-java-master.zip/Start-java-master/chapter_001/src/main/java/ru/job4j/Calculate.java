package ru.job4j;

/***
 * class Calculate.
 *
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Calculate {
    /**
     * Main.
	 * вывод строки в консоль.
     * @param args - args.
     */
    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}
