package ru.job4j.array;
 /**
 * BubbleSort.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class RotateArray {
	/**
	 * rotate.
     * rotation of a square array
	 * @param array - source array
	 * @return changes array
	 */
	public int[][] rotate(int[][] array) {
		int temp;
		int max = array[1].length - 1;
		for (int min = 0; min < (array[1].length / 2); min++) {
			for (int index = 0; index < max; index++) {
				temp = array[min][min + index];
				array[min][min + index] = array[max - index][min];
				array[max - index][min] = array[max][max - index];
				array[max][max - index] = array[min + index][max];
				array[min + index][max] = temp;
				if ((max - min) < 2) {
					break;
				}
			}
			max--;
		}
		return array;
	}
}