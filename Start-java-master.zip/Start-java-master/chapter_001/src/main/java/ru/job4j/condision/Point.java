package ru.job4j.condition;
 /**
 * Point.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Point {
	/**
     * @param x.
    */
   private int x;
   /**
	 * @param y.
    */
   private int y;
 /**
	 * costructor Point.
	 * @param x - первая координата
	 * @param y - вторая координата
    */
   public  Point(int x, int y) {
      this.x = x;
      this.y = y;
  }
 /**
	 * GetX.
     * @return возвращение x.
    */
	public int getX() {
      return this.x;
  }
 /**
	 * GetY.
     * @return возвращение y.
    */
  public int getY() {
     return this.y;
  }
  /**
	 * Is.
     * соответствие функции.
	 * @param a - parameter of equation
	 * @param b - parameter of equation
	 * @return condition
	 */
  public boolean is(int a, int b) {
	  return (this.y == a * this.x + b);
  }
}