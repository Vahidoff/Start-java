package ru.job4j.loop;
 /**
 * Counter.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Counter {
	/**
     * @param result.
    */
    private int result = 0;
	/**
	 * Add.
     * the sum of the even numbers of the range
	 * @param start - a start of the range
	 * @param finish - an end of the range
	 * @return result
	 */
	public int add(int start, int finish) {
		for (int index = start; index <= finish; index++) {
			if ((index % 2) == 0) {
				result += index;
				}
			}
		return result;
	}
}