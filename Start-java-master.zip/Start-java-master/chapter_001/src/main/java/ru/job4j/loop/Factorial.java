package ru.job4j.loop;
 /**
 * Factorial.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Factorial {
	/**
     * @param result.
    */
    private int result;
	/**
	 * Calc.
     * factorial number calculation
	 * @param n - positive integer
	 * @return result
	 */
	public int calc(int n) {
		if (n == 0) {
				result = 1;
			} else {
				result = 1;
				for (int index = 1; index <= n; index++) {
					result *= index;
				}
			}
			return result;
	}
}