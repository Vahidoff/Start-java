package ru.job4j.condition;
/**
 * Triangle.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Triangle {
	/**
	* @param a.
	*/
  private Point a;
  /**
	* @param b.
	*/
  private Point b;
  /**
	* @param c.
	*/
  private Point c;
 /**
	 * costructor Triangle.
	 * @param a - first dot
	 * @param b - second dot
	 * @param c - third dot
    */
  public Triangle(Point a, Point b, Point c) {
    this.a = a;
    this.b = b;
    this.c = c;
  }
 /**
	 * Area.
     * calculate the triangle area.
	 * @return area
	 */
  public double area() {
	  double part1 = (this.c.getX() - this.a.getX()) / (this.b.getX() - this.a.getX());
	  double part2 = (this.c.getY() - this.a.getY()) / (this.b.getY() - this.a.getY());
	  if (Math.abs(part1 - part2) < 0.01D) {
		  return -1;
	  } else {
	  double part3 = (this.a.getX() - this.c.getX()) * (this.b.getY() - this.c.getY());
	  double part4 = (this.b.getX() - this.c.getX()) * (this.a.getY() - this.c.getY());
	  return (Math.abs(part3 - part4) / 2.0);
	  }
  }
}