package ru.job4j.array;
 /**
 * Turn.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Turn {
	/**
	 * Back.
     * changes array back to front
	 * @param array - source array
	 * @return changes array
	 */
	public int[] back(int[] array) {
		int temp;
		for (int index = 0; index <= (array.length / 2 - 1); index++) {
			temp = array[index];
			array[index] = array[array.length - index - 1];
			array[array.length - index - 1] = temp;
		}
		return array;
	}
}