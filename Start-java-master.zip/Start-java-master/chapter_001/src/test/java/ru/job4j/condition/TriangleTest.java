package ru.job4j.condition;

import org.junit.Test;

//import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.hamcrest.number.IsCloseTo.closeTo;
/**
 * Test.
 *
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class TriangleTest {
	/**
     * Test1 area.
     */
    @Test
	public void whenTriangle1ThenArea() {
		Point a = new Point(12, 19);
		Point b = new Point(31, 47);
		Point c = new Point(40, 27);
		Triangle delta = new Triangle(a, b, c);
		double result = delta.area();
		double except = 316;
		assertThat(result, closeTo(except, 0.01));
	}
	/**
     * Test2 area.
     */
    @Test
	public void whenTriangle2ThenMinusone() {
		Point a = new Point(10, 54);
		Point b = new Point(8, 44);
		Point c = new Point(39, 199);
		Triangle delta = new Triangle(a, b, c);
		double result = delta.area();
		double except = -1;
		assertThat(result, closeTo(except, 0.01));
	}
	/**
     * Test3 area.
     */
    @Test
	public void whenTriangle3ThenArea() {
		Point a = new Point(-8, -15);
		Point b = new Point(-9, -20);
		Point c = new Point(40, 27);
		Triangle delta = new Triangle(a, b, c);
		double result = delta.area();
		double except = 99;
		assertThat(result, closeTo(except, 0.01));
	}
}