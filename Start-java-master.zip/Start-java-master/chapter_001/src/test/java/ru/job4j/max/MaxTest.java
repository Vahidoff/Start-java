package ru.job4j.max;

import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * Test.
 *
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class MaxTest {
	/**
     * Test1 max.
     */
    @Test
    public void whenMaxTwoComperaOneThenTwo() {
        Max maxim = new Max();
        int result = maxim.max(2, 1);
        int expected = 2;
        assertThat(result, is(expected));
    }
	/**
     * Test2 max.
     */
    @Test
    public void whenMaxTwoComperaFourThenFour() {
        Max maxim = new Max();
		int result = maxim.max(2, 4);
        int expected = 4;
        assertThat(result, is(expected));
    }
	/**
     * Test3 max.
     */
    @Test
    public void whenMaxTwoComperaTwoThenTwo() {
        Max maxim = new Max();
		int result = maxim.max(2, 2);
        int expected = 2;
        assertThat(result, is(expected));
    }
	/**
     * Test4 maxtriple.
     */
    @Test
    public void whenMaxtripleTwoAndOneComperaThreeThenThree() {
        Max maxim = new Max();
		int result = maxim.maxtriple(2, 1, 3);
        int expected = 3;
        assertThat(result, is(expected));
    }
	/**
     * Test5 maxtriple.
     */
    @Test
    public void whenMaxtripleMtwoAndNoneComperaMthreeThenMthree() {
        Max maxim = new Max();
		int result = maxim.maxtriple(-2, -1, -3);
        int expected = -1;
        assertThat(result, is(expected));
    }
	/**
     * Test6 maxtriple.
     */
    @Test
    public void whenMaxtripleFortyoneAndTwelveComperaFifteenThenFortyone() {
        Max maxim = new Max();
		int result = maxim.maxtriple(41, 12, 15);
        int expected = 41;
        assertThat(result, is(expected));
    }
}