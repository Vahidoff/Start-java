package ru.job4j.array;

import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
/**
 * Test.
 *
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class ArrayDuplicateTest {
	/**
     * Test1 remove.
     */
    @Test
    public void whenRemoveDuplicatesThenArrayWithoutDuplicate() {
        ArrayDuplicate solid = new ArrayDuplicate();
        String[] result = solid.remove(new String[] {"Hello", "World", "Hello", "Super", "World"});
        String[] expected = {"Hello", "World", "Super"};
        assertThat(result, is(expected));
	}
	/**
     * Test2 remove.
     */
    @Test
    public void whenRemoveDuplicatesThenArrayWithoutDuplicate2() {
        ArrayDuplicate solid = new ArrayDuplicate();
        String[] result = solid.remove(new String[] {"successful", "excellent", "beautiful", "beautiful", "wonderful", "famous", "famous", "excellent", "primely"});
        String[] expected = {"successful", "excellent", "beautiful", "primely", "wonderful", "famous"};
        assertThat(result, is(expected));
	}
	/**
     * Test3 remove.
     */
    @Test
    public void whenRemoveDuplicatesThenArrayWithoutDuplicate3() {
        ArrayDuplicate solid = new ArrayDuplicate();
        String[] result = solid.remove(new String[] {"successful", "successful", "successful"});
        String[] expected = {"successful"};
        assertThat(result, is(expected));
	}
 }