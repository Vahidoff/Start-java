package ru.job4j.array;

import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
/**
 * Test.
 *
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class RotateArrayTest {
	/**
     * Test1 rotate.
     */
    @Test
     public void whenRotateTwoRowTwoColArrayThenRotatedArray() {
        RotateArray solid = new RotateArray();
        int[][] result = solid.rotate(new int[][] {{1, 5}, {8, 2}});
        int[][] expected = {{8, 1}, {2, 5}};
        assertThat(result, is(expected));
	}
	/**
     * Test2 rotate.
     */
    @Test
     public void whenRotateThreeColArrayThenRotatedArray() {
        RotateArray solid = new RotateArray();
        int[][] result = solid.rotate(new int[][] {{8, 9, 5}, {7, 4, 1}, {0, 3, 6}});
        int[][] expected = {{0, 7, 8}, {3, 4, 9}, {6, 1, 5}};
        assertThat(result, is(expected));
	}
	/**
     * Test3 rotate.
     */
    @Test
     public void whenRotateFourColArrayThenRotatedArray() {
        RotateArray solid = new RotateArray();
        int[][] result = solid.rotate(new int[][] {{10, 37, 40, 9}, {51, 14, 8, 87}, {5, 7, 35, 67}, {44, 51, 30, 91}});
        int[][] expected = {{44, 5, 51, 10}, {51, 7, 14, 37}, {30, 35, 8, 40}, {91, 67, 87, 9}};
        assertThat(result, is(expected));
	}
}