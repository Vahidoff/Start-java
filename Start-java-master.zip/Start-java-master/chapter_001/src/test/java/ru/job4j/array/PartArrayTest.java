package ru.job4j.array;

import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
/**
 * Test.
 *
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class PartArrayTest {
	/**
     * Test1 contains.
     */
    @Test
    public void whenStringPartAnotherThenTrue() {
        PartArray solid = new PartArray();
        boolean result = solid.contains("But the more a furious president has taken his defence into his own hands, the", "furious president");
        boolean expected = true;
        assertThat(result, is(expected));
	}
	/**
     * Test2 contains.
     */
    @Test
    public void whenStringPartAnotherThenTrue2() {
        PartArray solid = new PartArray();
        boolean result = solid.contains("But the more a furious president has taken his defence into his own hands, the", "But the more");
        boolean expected = true;
        assertThat(result, is(expected));
	}
	/**
     * Test3 contains.
     */
    @Test
    public void whenStringPartAnotherThenTrue3() {
        PartArray solid = new PartArray();
        boolean result = solid.contains("But the more a furious president has taken his defence into his own hands, the", "hands, the");
        boolean expected = true;
        assertThat(result, is(expected));
	}
	/**
     * Test4 contains.
     */
    @Test
    public void whenStringPartAnotherThenTrue4() {
        PartArray solid = new PartArray();
        boolean result = solid.contains("But the more a furious president has taken his defence into his own hands, the", "hands the");
        boolean expected = false;
        assertThat(result, is(expected));
	}
}