package ru.job4j.loop;

import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
/**
 * Test.
 *
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class CounterTest {
	/**
     * Test1 add.
     */
    @Test
    public void whenSumEvenNumbersFromStartToFinishThenResult() {
		Counter sum = new Counter();
		int result = sum.add(2, 14);
        int expected = 56;
        assertThat(result, is(expected));
	}
	/**
     * Test2 add.
     */
    @Test
    public void whenSumEvenNumbersFromZeroToTenThenThirty() {
		Counter sum = new Counter();
		int result = sum.add(0, 10);
        int expected = 30;
        assertThat(result, is(expected));
	}
	/**
     * Test3 add.
     */
    @Test
    public void whenSumEvenNumbersFromMtwelveToMtwoThenMfortytwo() {
		Counter sum = new Counter();
		int result = sum.add(-12, -2);
        int expected = -42;
        assertThat(result, is(expected));
	}
}