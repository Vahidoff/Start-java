package ru.job4j.array;

import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
/**
 * Test.
 *
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class CombinedArrayTest {
	/**
     * Test1 intagration.
     */
    @Test
    public void whenCombiningArraysThenCombinedArray() {
        CombinedArray solid = new CombinedArray();
        int[] result = solid.integration(new int[] {2, 4, 5, 7}, new int[] {1, 3, 5});
        int[] expected = {1, 2, 3, 4, 5, 5, 7};
        assertThat(result, is(expected));
	}
	/**
     * Test2 intagration.
     */
    @Test
    public void whenCombiningArraysThenCombinedArray2() {
        CombinedArray solid = new CombinedArray();
        int[] result = solid.integration(new int[] {2, 2, 5, 7, 10, 14, 14}, new int[] {1, 2, 5, 10, 11, 12});
        int[] expected = {1, 2, 2, 2, 5, 5, 7, 10, 10, 11, 12, 14, 14};
        assertThat(result, is(expected));
	}
	/**
     * Test3 intagration.
     */
    @Test
    public void whenCombiningArraysThenCombinedArray3() {
        CombinedArray solid = new CombinedArray();
        int[] result = solid.integration(new int[] {2, 4, 7}, new int[] {1, 3});
        int[] expected = {1, 2, 3, 4, 7};
        assertThat(result, is(expected));
	}
	/**
     * Test4 intagration.
     */
    @Test
    public void whenCombiningArraysThenCombinedArray4() {
        CombinedArray solid = new CombinedArray();
        int[] result = solid.integration(new int[] {2, 4, 5}, new int[] {1, 3, 4});
        int[] expected = {1, 2, 3, 4, 4, 5};
        assertThat(result, is(expected));
	}
	/**
     * Test5 intagration.
     */
    @Test
    public void whenCombiningArraysThenCombinedArray5() {
        CombinedArray solid = new CombinedArray();
        int[] result = solid.integration(new int[0], new int[] {1, 3, 4});
        int[] expected = {1, 3, 4};
        assertThat(result, is(expected));
	}
	/**
     * Test6 intagration.
     */
    @Test
    public void whenCombiningArraysThenCombinedArray6() {
        CombinedArray solid = new CombinedArray();
        int[] result = solid.integration(new int[] {1, 3, 4}, new int[0]);
        int[] expected = {1, 3, 4};
        assertThat(result, is(expected));
	}
}