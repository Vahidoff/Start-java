/**
 * //TODO add comments.
 *
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
package ru.job4j.calculator;