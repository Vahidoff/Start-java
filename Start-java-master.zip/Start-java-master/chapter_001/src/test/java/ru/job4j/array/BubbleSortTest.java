package ru.job4j.array;

import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
/**
 * Test.
 *
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class BubbleSortTest {
	/**
     * Test1 sort.
     */
    @Test
    public void whenSortArrayWithTenElementsThenSortedArray() {
        BubbleSort solid = new BubbleSort();
        int[] result = solid.sort(new int[] {1, 5, 4, 2, 3, 1, 7, 8, 0, 5});
        int[] expected = {0, 1, 1, 2, 3, 4, 5, 5, 7, 8};
        assertThat(result, is(expected));
	}
	/**
     * Test1 sort.
     */
    @Test
    public void whenSortArrayWithEightElementsThenSortedArray() {
        BubbleSort solid = new BubbleSort();
        int[] result = solid.sort(new int[] {77, 3, -7, 10, -115, 32, 99, 32});
        int[] expected = {-115, -7, 3, 10, 32, 32, 77, 99};
        assertThat(result, is(expected));
	}
}