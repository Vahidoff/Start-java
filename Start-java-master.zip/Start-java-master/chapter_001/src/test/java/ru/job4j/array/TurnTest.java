package ru.job4j.array;

import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
/**
 * Test.
 *
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class TurnTest {
	/**
     * Test1 back.
     */
    @Test
    public void whenTurnArrayWithEvenAmountOfElementsThenTurnedArray() {
        Turn solid = new Turn();
        int[] result = solid.back(new int[] {1, 2, 3, 4, 5});
        int[] expected = {5, 4, 3, 2, 1};
        assertThat(result, is(expected));
	}
	/**
     * Test2 back.
     */
    @Test
    public void whenTurnArrayWithEvenFiftiesThenTurnedArray() {
        Turn solid = new Turn();
        int[] result = solid.back(new int[] {50, 51, 52, 53, 54, 55, 56, 57, 58, 59});
        int[] expected = {59, 58, 57, 56, 55, 54, 53, 52, 51, 50};
        assertThat(result, is(expected));
	}
 }