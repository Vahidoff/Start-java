package ru.job4j.condition;

import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * Test.
 *
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class PointTest {
	/**
     * Test1 condition.
	 * y(x) = a * x + b
	 * 7    = 3 * 2 + 1
     */
    @Test
	public void whenPointSevenAndTwoThenTrue() {
        Point dot = new Point(2, 7);
        boolean result = dot.is(3, 1);
        boolean expected = true;
        assertThat(result, is(expected));
    }
	/**
     * Test2 condition.
	 * y(x) = a * x + b
	 * 5    = 3 * 2 + 1
     */
    @Test
	public void whenPointFiveAndTwoThenFalse() {
        Point dot = new Point(2, 5);
        boolean result = dot.is(3, 1);
        boolean expected = false;
        assertThat(result, is(expected));
    }
	/**
     * Test3 condition.
	 * y(x) = a * x + b
	 * 3    = (-10) * 2 + 23
     */
    @Test
	public void whenPointTwoAndFreeThenTrue() {
        Point dot = new Point(2, 3);
        boolean result = dot.is(-10, 23);
        boolean expected = true;
        assertThat(result, is(expected));
    }
}