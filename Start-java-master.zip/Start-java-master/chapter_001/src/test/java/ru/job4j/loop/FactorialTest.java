package ru.job4j.loop;

import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
/**
 * Test.
 *
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class FactorialTest {
	/**
     * Test1 calc.
     */
    @Test
    public void whenCalculateFactorialForFiveThenOneHundreedTwenty() {
		Factorial numeric = new Factorial();
		int result = numeric.calc(5);
        int expected = 120;
        assertThat(result, is(expected));
		}
	/**
     * Test2 calc.
     */
    @Test
    public void whenCalculateFactorialForZeroThenOne() {
		Factorial numeric = new Factorial();
		int result = numeric.calc(0);
        int expected = 1;
        assertThat(result, is(expected));
	}
	/**
     * Test3 calc.
     */
    @Test
    public void whenCalculateFactorialForEightThenFortythousand() {
		Factorial numeric = new Factorial();
		int result = numeric.calc(8);
        int expected = 40320;
        assertThat(result, is(expected));
	}
}