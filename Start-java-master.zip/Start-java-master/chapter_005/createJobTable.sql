CREATE TABLE sqlvacancies (
  id          SERIAL PRIMARY KEY,
  description VARCHAR(200) NOT NULL,
  employer    VARCHAR(100) NOT NULL,
  date        TIMESTAMP
);