package ru.job4j.jdbc;

import org.junit.Test;

import java.io.FileNotFoundException;
import java.sql.SQLException;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * Test.
 * TableDB, CreateXML, ConvertingXML class
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class TableDBTest {
    private static final int AMOUNT = 1000;
    private static final int EXPECTED = AMOUNT * (AMOUNT + 1) / 2;
    /**
     * Test1.
     * class UnionXML.
     * create table "test" and filling the table.
     * getting the sun of all the numbers in the table
     */
    @Test
    public void whenDataBaseCreateThenTableTest() throws SQLException, FileNotFoundException {
        UnionXML tableDB = new UnionXML("jdbc:postgresql://localhost:5432/cars",
                "postgres", "AKey9Mute8", AMOUNT);

        int result = tableDB.start();

        System.out.format("result: %d \n", result);
        assertThat(result, is(EXPECTED));

    }
    /**
     * Test2.
     * class CreateXML
     * writeFileThird
     */
    @Test
    public void whenReadDataBaseThenFileThird() throws SQLException, FileNotFoundException {
        CreateXML create = new CreateXML("jdbc:postgresql://localhost:5432/cars",
                "postgres", "AKey9Mute8");

        create.writeFileThird();
    }
    /**
     * Test3.
     * class UnionSecond.
     * create table "test" and filling the table.
     * getting the sun of all the numbers in the table
     */
    @Test
    public void whenDataBaseCreateSecondThenSumTrue() throws SQLException, FileNotFoundException {
        UnionSecond tableDB = new UnionSecond("jdbc:postgresql://localhost:5432/cars",
                "postgres", "AKey9Mute8", AMOUNT);

        int result = tableDB.startSecond();

        System.out.format("result: %d \n", result);
        assertThat(result, is(EXPECTED));
    }
}

