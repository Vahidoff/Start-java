package ru.job4j.sqlru;

import org.junit.Test;

import java.io.FileNotFoundException;
import java.sql.SQLException;

/**
 * Test.
 * VacanciesSQLru, SqlVacancyDB, Vacancy classes
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class SQLruTest {
    /**
     * Test1.
     * create table "sqlvacancies" and filling the table.
     * getting the data from site "Sql.ru"
     */
    @Test
    public void whenDataBaseCreateThenTableFilling() throws SQLException, FileNotFoundException, InterruptedException {
        VacanciesSQLru vacancies = new VacanciesSQLru();
        vacancies.startSQLru();
    }
}
