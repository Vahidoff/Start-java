package ru.job4j.jdbc;

import org.postgresql.util.PSQLState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * CreateXML.
 * creation of a XML file based on a database
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class CreateXML {
    private static final Logger LOG = LoggerFactory.getLogger(PSQLState.class);
    /**
     * Database URL.
     */
    private final String url;
    private final String username;
    private final String password;

    private final File fileOne;

    public CreateXML(String url, String username, String password) {
        this.url = url;
        this.username = username;
        this.password = password;
        this.fileOne = new File("./1.xml");
    }
    void writeFile() throws FileNotFoundException, SQLException {

        Connection conn = DriverManager.getConnection(this.url, this.username, this.password);
        conn.setAutoCommit(false);
        Statement st = conn.createStatement();
        ResultSet rs = st.executeQuery(String.format("SELECT %s FROM %s", "field", "test"));

        StringBuilder xmlText = new StringBuilder();
        xmlText.append("<entries>").append(System.getProperty("line.separator"));

        try {
        while (rs.next()) {
            xmlText.append("    <entry>").
                    append(System.getProperty("line.separator")).
                    append("        <field>").append(rs.getInt(1)).append("</field>").
                    append(System.getProperty("line.separator")).
                    append("    </entry>").append(System.getProperty("line.separator"));
        }
        xmlText.append("</entries>");
        conn.rollback();

        PrintWriter input = new PrintWriter(this.fileOne);
        input.print(xmlText.toString());
        input.close();

        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        } finally {
            try {
                assert rs != null;
                rs.close();
            } catch (SQLException e) {
                LOG.error(e.getMessage(), e);
            }
            try {
                st.close();
            } catch (SQLException e) {
                LOG.error(e.getMessage(), e);
            }
            try {
                conn.close();
            } catch (SQLException e) {
                LOG.error(e.getMessage(), e);
            }
        }
    }

    void writeFileThird() throws FileNotFoundException, SQLException {

        Connection conn = DriverManager.getConnection(this.url, this.username, this.password);
        conn.setAutoCommit(false);
        Statement st = conn.createStatement();
        ResultSet rs = st.executeQuery(String.format("SELECT %s FROM %s", "field", "test"));
        Entries temp = new Entries();

        List<EntryXML> entries = new ArrayList<>();
        while (rs.next()) {
            entries.add(new EntryXML(rs.getInt(1)));
        }
        temp.setEntries(entries);
        conn.rollback();

        try {
            JAXBContext context = JAXBContext.newInstance(Entries.class);
            Marshaller marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

            marshaller.marshal(temp, new File("./3.xml"));
        } catch (JAXBException e) {
            e.printStackTrace();
        } finally {
        try {
            st.close();
            rs.close();
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
        try {
            conn.close();
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
    }

    }

}
