package ru.job4j.jdbc;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

/**
 * EntryXML.
 * for JAXB
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class EntryXML {

    private int id;
    /**
     * Constructor.
     * @param id
     */
    public EntryXML(int id) {
        this.id = id;
    }
    public void setId(int id) {
        this.id = id;
    }

    @XmlElement(name = "field")
    public int getId() {
        return id;
    }

}

/**
 * class Entries.
 * for JAXB
 */
@XmlRootElement(name = "entries")
class Entries {

    @XmlElement (name = "entry")
    private List<EntryXML> entries = new ArrayList<>();

    public void setEntries(List<EntryXML> entriesXML) {
        this.entries = entriesXML;
    }
}