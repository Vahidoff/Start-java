package ru.job4j.jdbc;

import org.postgresql.util.PSQLState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;

/**
 * TableDB.
 * database creation and filling
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class TableDB {

    private static final Logger LOG = LoggerFactory.getLogger(PSQLState.class);
    /**
     * Database URL.
     */
    private final String url;
    private final String username;
    private final String password;
    private int amount;

    public TableDB(String url, String username, String password, int amount) {
        this.url = url;
        this.username = username;
        this.password = password;
        this.amount = amount;
    }

    public void createTable() throws SQLException {
        Connection conn = DriverManager.getConnection(this.url, this.username, this.password);
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            rs = conn.getMetaData().getTables(
                    null, null, "test", null);
            if (rs.next()) {
                ps = conn.prepareStatement("TRUNCATE TABLE test");
                ps.executeUpdate();
            } else {
                ps = conn.prepareStatement("CREATE TABLE test (field INTEGER )");
                ps.execute();
            }

            this.fillingTable(conn);

        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        } finally {
            try {
                assert rs != null;
                rs.close();
            } catch (SQLException e) {
                LOG.error(e.getMessage(), e);
            }
            try {
                assert ps != null;
                ps.close();
            } catch (SQLException e) {
                LOG.error(e.getMessage(), e);
            }
            try {
                conn.close();
            } catch (SQLException e) {
                LOG.error(e.getMessage(), e);
            }
        }
    }

    private void fillingTable(Connection conn) throws SQLException {
        PreparedStatement ps = null;
        conn.setAutoCommit(false);
        try {
            ps = conn.prepareStatement("INSERT INTO test (field) VALUES (?)");
            for (int index = 1; index <= this.amount; index++) {
                ps.setInt(1, index);
                ps.addBatch();
            }
            ps.executeBatch();
            conn.commit();
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        } finally {
            if (ps != null) {
                try {
                    ps.close();
                } catch (SQLException e) {
                    LOG.error(e.getMessage(), e);
                }
            }
            System.out.println("table \"test\" is full");
        }
    }
}
