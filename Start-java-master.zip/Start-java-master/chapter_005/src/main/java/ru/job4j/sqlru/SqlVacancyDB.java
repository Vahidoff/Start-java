package ru.job4j.sqlru;

import org.postgresql.util.PSQLState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.Properties;
/**
 * SqlVacancyDB.
 * data processing for a database
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class SqlVacancyDB {
    /**
     * Logger for database errors.
     */
    private static final Logger LOG = LoggerFactory.getLogger(PSQLState.class);
    private Connection conn;
    private PreparedStatement ps;
    private ResultSet rs;

    public void connectDb() throws SQLException {
        final Properties properties = new Properties();
        try (InputStream in = getClass().getClassLoader().
                getResourceAsStream("connection.properties")) {
            properties.load(in);
        } catch (IOException e) {
            LOG.error(e.getMessage(), e);
        }
        try {
            this.conn = DriverManager.getConnection(properties.getProperty("url"),
                    properties.getProperty("user"), properties.getProperty("password"));
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
        this.createTable();
    }

    private void createTable() throws SQLException {
        ResultSet rs = null;
        try {
            rs = this.conn.getMetaData().
                    getTables(null, null, "sqlvacancies", null);
            if (!rs.next()) {
                this.readSQL("createJobTable.sql");
            }
        } catch (SQLException | IOException e) {
            LOG.error(e.getMessage(), e);
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    LOG.error(e.getMessage(), e);
                }
            }
        }
    }

    public void disconnectDb() {
        try {
            assert conn != null;
            this.conn.close();
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
        try {
            if (this.ps != null) {
                this.ps.close();
            }
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
        try {
            if (this.rs != null) {
                this.rs.close();
            }
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
    }

    protected Timestamp lateDate() {
        Timestamp lastVacancyDate = null;
        try {
            this.ps = this.conn.prepareStatement("SELECT MAX(date) FROM sqlvacancies;");
            this.rs = this.ps.executeQuery();
            if (this.rs != null) {
                while (this.rs.next()) {
                    lastVacancyDate = this.rs.getTimestamp("max");
                }
            }
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
        return lastVacancyDate;
    }

    protected void add(String description, String employer, Timestamp date) {
        try {
            this.ps = conn.prepareStatement("INSERT INTO sqlvacancies( description, employer, date) "
                    + "SELECT ?, ?, ? WHERE NOT EXISTS ("
                    + "SELECT employer FROM sqlvacancies WHERE employer = ?)");
            ps.setString(1, description);
            ps.setString(2, employer);
            ps.setTimestamp(3, date);
            ps.setString(4, employer);
            ps.executeUpdate();
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
    }

    private void readSQL(String fileName) throws IOException {
        String line;
        StringBuilder builder = new StringBuilder();
        FileReader reader = new FileReader(fileName);
        BufferedReader buffer = new BufferedReader(reader);

        while ((line = buffer.readLine()) != null) {
            builder.append(line);
        }
        buffer.close();

        String[] query = builder.toString().split(";");
        try {
            Statement st = this.conn.createStatement();
            for (String aQuery : query) {
                if (!aQuery.trim().equals("")) {
                    st.executeUpdate(aQuery);
                }
            }
            try {
                st.close();
            } catch (SQLException e) {
                LOG.error(e.getMessage(), e);
            }
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
    }

}
