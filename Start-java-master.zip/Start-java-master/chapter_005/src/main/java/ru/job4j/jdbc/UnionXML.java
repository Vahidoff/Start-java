package ru.job4j.jdbc;

import java.io.FileNotFoundException;
import java.sql.SQLException;

/**
 * UnionXML.
 * create table "test" and filling the table.
 * getting the sun of all the numbers in the created file
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class UnionXML {

    /**
     * Database URL.
     */
    private final String url;
    private final String username;
    private final String password;
    private int amount;

    public UnionXML(String url, String username, String password, int amount) {
        this.url = url;
        this.username = username;
        this.password = password;
        this.amount = amount;
    }

    protected int start() throws SQLException, FileNotFoundException {

        TableDB tableDB = new TableDB(this.url, this.username, this.password, this.amount);

        try {
            tableDB.createTable();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        CreateXML createXML = new CreateXML(this.url, this.username, this.password);
        createXML.writeFile();

        ConvertingXML convert = new ConvertingXML();
        convert.converting("./1.xml");
        convert.readFile();
        return convert.getSum();
    }
}
