package ru.job4j.sqlru;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.postgresql.util.PSQLState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Locale;
import java.util.Properties;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * VacanciesSQLru.
 * retrieving data from the site sql.ru and sending them to the database
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class VacanciesSQLru implements Runnable {
    /**
     * Logger for database errors.
     */
    private static final Logger LOG = LoggerFactory.getLogger(PSQLState.class);
    /**
     * Site Sql.ru.
     */
    private SqlVacancyDB sqlDB = new SqlVacancyDB();
    private final SimpleDateFormat format = new SimpleDateFormat(
            "d MMM yy, HH:mm", new Locale("ru", "RU"));

    @Override
    public void run() {
        System.out.println("the search for vacancies begins");
        try {
            this.readSQLru();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void readSQLru() throws SQLException {
        this.sqlDB.connectDb();
        Timestamp searchDate = this.sqlDB.lateDate();
        String sqlRu = "http://www.sql.ru/forum/job-offers";
        String currentPage = sqlRu;
        if (searchDate == null) {
            searchDate = this.thisYear();
        }
        try {
            int page = 1;
            boolean flag = true;
            String employer;
            String description;
            Timestamp date;
            do {
                if (page != 1) {
                    currentPage = sqlRu + "/" + page;
                }
                Document doc = Jsoup.connect(currentPage).get();
                Elements topics = doc.select("tr:has(.postslisttopic)");
                for (Element topic : topics) {
                    if (topic.text().toLowerCase().contains("java")
                            & !topic.text().toLowerCase().contains("script")
                            & !topic.text().toLowerCase().contains("закрыт")) {
                        Elements data = topic.select("td");
                        employer = data.get(2).text();
                        description = data.get(1).text();
                        date = parseDate(data.get(5).text());
                        if (date.before(searchDate)) {
                            flag = false;
                            break;
                        }
                        sqlDB.add(description, employer, date);
                    }
                }
                page++;
            } while (flag);
        } catch (IOException e) {
            LOG.error(e.getMessage(), e);
        } finally {
            this.sqlDB.disconnectDb();
        }
    }

    private Timestamp thisYear() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(LocalDate.now().getYear(), 0, 1, 0, 0, 0);
        return new Timestamp(calendar.getTimeInMillis());
    }

    private Timestamp parseDate(String date) {
        Calendar calendar = Calendar.getInstance();
        if (date.contains("сегодня")) {
            calendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(date.substring(9, 11)));
            calendar.set(Calendar.MINUTE, Integer.parseInt(date.substring(12, 14)));
        } else if (date.contains("вчера")) {
            calendar.add(Calendar.DATE, -1);
            calendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(date.substring(7, 9)));
            calendar.set(Calendar.MINUTE, Integer.parseInt(date.substring(10, 12)));
        } else {
            try {
                calendar.setTime(this.format.parse(date));
            } catch (ParseException e) {
                LOG.error(e.getMessage(), e);
            }
        }
        return new Timestamp(calendar.getTimeInMillis());
    }

    public void startSQLru() throws InterruptedException {
        int launchPeriod = 0;
        final Properties properties = new Properties();
        try (InputStream in = getClass().getClassLoader().
                getResourceAsStream("connection.properties")) {
            properties.load(in);
            launchPeriod = Integer.parseInt(properties.getProperty("launch_period"));

        } catch (IOException e) {
            e.printStackTrace();
        }
        ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();
        service.scheduleAtFixedRate(new VacanciesSQLru(),
                0, launchPeriod, TimeUnit.SECONDS);
        Thread.sleep(launchPeriod * 4000);
        service.shutdown();

    }
}
