package ru.job4j.synchronize;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
/**
 * ParallelSearch.
 * multithreaded search in the specified folder for certain files
 * with the specified text.
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class ParallelSearch {
    /**
     * The path to the folder from which to search.
     */
    private String root;
    /**
     * specified text.
     */
    private String text;
    /**
     * Extensions of files in which you need to do a search.
     */
    private List<String> extensions;
    /**
     * the result of the search.
     */
    private Set<String> result = new TreeSet<>();
    /**
     * constructor.
     * @param root -
     * @param text -
     * @param extension -
     */
    public ParallelSearch(String root, String text, List<String> extension) {
        this.root = root;
        this.text = text;
        this.extensions = extension;
    }
    /**
     * Search for files with a specific extension.
     * @return Set<String> result
     * @throws InterruptedException - thread interruption
     */
    Set<String> threadsStart() throws InterruptedException {
        List<File> listFiles = this.searchFiles();
        String temp;
        for (File file : listFiles) {
            temp = this.textSearchExtension(file);
            if (!temp.equals("This text is not found")) {
                this.result.add(temp);
            }
        }
        return this.result;
    }
    /**
     * multithreaded search for files.
     * @param file -
     * @return String resultSearch in TextSearch
     * @throws InterruptedException - thread interruption
     */
    private String textSearchExtension(File file) throws InterruptedException {
        TextSearch textSearch = new TextSearch(file, this.text);
        Thread thread = new Thread(textSearch);
        thread.start();
        while (thread.isAlive()) {
            thread.join();
        }
        return textSearch.getResultOneFile();
    }
    /**
     * search for files with a given extension.
     * @return - List<File>
     * @throws NullPointerException - file not find
     */
    private List<File> searchFiles() throws NullPointerException {
        List<File> listFiles = new ArrayList<>();
            File[] files = new File(this.root).listFiles();
            if (files != null) {
                for (File file : files) {
                    for (String st : this.extensions) {
                        if (file.toString().endsWith(st)) {
                            listFiles.add(file);
                            break;
                        }
                    }
                }
            }
        return listFiles;
    }

}
