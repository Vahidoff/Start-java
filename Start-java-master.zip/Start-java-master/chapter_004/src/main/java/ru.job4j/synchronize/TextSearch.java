package ru.job4j.synchronize;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 * TextSearch.
 * search in the specified folder for certain files with the specified text
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class TextSearch implements Runnable {
    /**
     * specified text.
     */
    private String text;
    /**
     * the file in which you need to do a search.
     */
    private File file;
    /**
     * the result of the search.
     */
    private String resultSearch;
    /**
     * constructor.
     * @param file -
     * @param text -
     */
    public TextSearch(File file, String text) {
        this.file = file;
        this.text = text;
    }
    /**
     * the search result in files with one extension.
     * @return String resultSearch
     */
    public String getResultOneFile() {
        return resultSearch;
    }
    /**
     * searching in the found file for a given text.
     * @return - Set<String> resultSearch
     * @throws FileNotFoundException - "file not find".
     */
    protected String readFile() throws FileNotFoundException {
        String result = "This text is not found";
            try (BufferedReader br = new BufferedReader(new FileReader(this.file))) {
                String line;
                while ((line = br.readLine()) != null) {
                    if (line.contains(this.text)) {
                        result = this.file.toString();
                        break;
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            System.out.format("Thread name is %s \n", Thread.currentThread().getName());
        this.resultSearch = result;
        return result;
    }

    @Override
    public void run() {
        try {
            this.readFile();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}



