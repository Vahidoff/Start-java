package ru.job4j.synchronize;
import net.jcip.annotations.GuardedBy;
import net.jcip.annotations.ThreadSafe;
import ru.job4j.list.DynamicArray;

import java.util.Iterator;
/**
 * DynamicArrayTSafe.
 * dynamic array-based list - thread safe
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 * @param <T>
 */
@ThreadSafe
public class DynamicArrayTSafe<T> implements Iterable {
    /**
     * single-thread main array list.
     */
    private final DynamicArray<T> deposit = new DynamicArray<>();
    /**
     * adding element.
     * @param t -
     */
    @GuardedBy("this.deposit")
    void addT(T t) {
        synchronized (this.deposit) {
            this.deposit.add(t);
        }
    }
    /**
     * getting the element by the index.
     * @param i - the index of the element
     * @return - the element of the main array list
     */
    @GuardedBy("this.deposit")
    protected T getT(int i) {
        synchronized (this.deposit) {
            return this.deposit.get(i);
        }
    }

    @Override
    public Iterator iterator() {
        synchronized (this.deposit) {
            return this.deposit.iterator();
        }
    }
}
