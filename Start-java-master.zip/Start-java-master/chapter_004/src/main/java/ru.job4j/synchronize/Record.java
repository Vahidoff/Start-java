package ru.job4j.synchronize;

import net.jcip.annotations.GuardedBy;
import net.jcip.annotations.ThreadSafe;

import java.util.ArrayList;
import java.util.List;

/**
 * Count.
 * multithreaded counter
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
@ThreadSafe
class Count {
    /**
     * counter reading.
     */
    private int meter = 0;
    /**
     * constructor.
     * @param meter -
     */
    Count(int meter) {
        this.meter = meter;
    }
    /**
     * @return - meter.
     */
    @GuardedBy("this")
    public int getMeter() {
        synchronized (this) {
            return meter;
        }
    }
    /**
     * increase the meter reading.
     * @param value - the magnitude of the increase.
     * @return - meter
     */
    @GuardedBy("this")
    int increment(int value) {
        synchronized (this) {
            return this.meter + value;
        }
    }
}
/**
 * Record.
 * recording changes to the counter
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Record extends Thread {
    /**
     * previous counter values.
     */
    private List<Count> listEarly;
    /**
     * new counter values.
     */
    private List<Count> listFresh;
    /**
     * total results of counters.
     */
    private final List<Count> result = new ArrayList<>();
    /**
     * constructor.
     * @param listEarly -
     * @param listFresh -
     */
    Record(List<Count> listEarly, List<Count> listFresh) {
        this.listEarly = listEarly;
        this.listFresh = listFresh;
    }
    /**
     * @return List<Count> result.
     */
    public List<Count> getResult() {
        return result;
    }
    @Override
    public void run() {
        for (int i = 0; i < listEarly.size(); i++) {
                result.add(sum(listEarly.get(i), listFresh.get(i)));
        }
    }
    /**
     * summing up the counter.
     * @param early - previous counter value.
     * @param fresh - new counter value.
     * @return - new Count
     */
    private Count sum(Count early, Count fresh) {
        return new Count(early.increment(fresh.getMeter()));
    }
}
