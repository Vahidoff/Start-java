package ru.job4j.synchronize;
import net.jcip.annotations.GuardedBy;
import net.jcip.annotations.ThreadSafe;
import ru.job4j.list.ConnectedList;

import java.util.Iterator;
/**
 * DynamicArrayTSafe.
 * dynamic array-based list - thread safe
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 * @param <T>
 */
@ThreadSafe
public class ConnectedListTSafe<T> implements Iterable {
    /**
     * single-thread main connected list.
     */
    private final ConnectedList<T> depot = new ConnectedList<>();
    /**
     * adding element.
     * @param t -
     */
    @GuardedBy("this.deposit")
    void addT(T t) {
        synchronized (this.depot) {
            this.depot.add(t);
        }
    }
    /**
     * getting the element by the index.
     * @param i - the index of the element
     * @return - the element of the main array list
     */
    @GuardedBy("this.deposit")
    protected T getT(int i) {
        synchronized (this.depot) {
            return this.depot.get(i);
        }
    }
    /**
     * deleting the first element of the deposit.
     */
    @GuardedBy("this.deposit")
    protected void deleteTFirst() {
        synchronized (this.depot) {
            this.depot.deleteFirst();
        }
    }
    /**
     * deleting the last element of the deposit.
     */
    @GuardedBy("this.deposit")
    protected void deleteTEnd() {
        synchronized (this.depot) {
            this.depot.deleteEnd();
        }
    }

    @Override
    public Iterator iterator() {
        return this.depot.iterator();
    }
}
