package ru.job4j.synchronize;
import net.jcip.annotations.GuardedBy;
import net.jcip.annotations.ThreadSafe;

import java.util.TreeMap;
/**
 * multithreading storage.
 * the deposit for UserT
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
@ThreadSafe
public class UserStoreT {
    /**
     * the deposit fo UserT.
     */
    private final TreeMap<Integer, UserT> deposit = new TreeMap<>();
    /**
     * adding UserT.
     * @param user -
     */
    @GuardedBy("this.deposit")
    protected void add(UserT user) {
        synchronized (this.deposit) {
            deposit.put(user.getId(), user);
        }
    }
    /**
     *renewal UserT.
     * @param user -
     */
    @GuardedBy("this.deposit")
    void update(UserT user) {
        synchronized (this.deposit) {
            deposit.remove(user.getId());
            deposit.put(user.getId(), user);
        }
    }
    /**
     * deleting UserT.
     * @param user -
     */
    @GuardedBy("this.deposit")
    void delete(UserT user) {
        synchronized (this.deposit)  {
            deposit.remove(user.getId());
        }
    }
    /**
     * getting UserT.
     * @param id -
     * @return deposit
     */
    @GuardedBy("this.deposit")
    UserT getUT(int id) {
        synchronized (this.deposit) {
            if (deposit.containsKey(id)) {
                return deposit.get(id);
            } else {
                return new UserT(id, -1);
            }
        }
    }
    /**
     * transfer.
     * @param fromId - donor UserT id
     * @param toId - recipient's UserT id
     * @param amount of transfer
     */
    @GuardedBy("UserT userFrom, UserT userTo")
    void transfer(int fromId, int toId, int amount) {
        UserT userFrom = getUT(fromId);
        synchronized (UserT.class) {
            UserT userTo = getUT(toId);
                if (userFrom.getAmount() != -1 & userTo.getAmount() != -1) {
                    userFrom.setAmount(userFrom.getAmount() - amount);
                    userTo.setAmount(userTo.getAmount() + amount);
            }
        }
    }
}
