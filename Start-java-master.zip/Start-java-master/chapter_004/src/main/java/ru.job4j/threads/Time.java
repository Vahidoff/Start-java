package ru.job4j.threads;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 * CharStop.
 * there are two threads
 * program for counting characters in the text
 * the execution time of the program is limited
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Time implements Runnable {
    /**
     * path of the file.
     */
    private String file;
    /**
     * number of symbol in the file.
     */
    private int symbol = 0;
    /**
     * operating time of the program.
     */
    private int second;
    /**
     * constructor.
     *
     * @param file   -
     * @param second -
     */
    Time(String file, int second) {
        this.file = file;
        this.second = second;
    }
    /**
     * @return symbol
     */
    public int getSymbol() {
        return symbol;
    }

    @Override
    public void run() {
        CountChar count = new CountChar(this.file);
        long start;
        boolean flag = true;

        start = System.nanoTime();
        do {
            long end = System.nanoTime();
            int time = (int) (end - start) / 100000;
            if (time > 70 * this.second || !count.getThread().isAlive()) {
                System.out.format("program execution time %d \n", time);
                count.getThread().interrupt();
                flag = false;
            }
        } while (flag);

        this.symbol = count.getSymbol();
        System.out.format("total number of counted symbol %d \n", this.symbol);
    }
}
/**
 * CountChar.
 * the class for counting characters in the text
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
class CountChar implements Runnable {


    /**
     * thread variable.
     */
    private Thread thread;
    /**
     * path of the file.
     */
    private String file;
    /**
     * number of symbol in the file.
     */
    private int symbol = 0;
    /**
     * constructor.
     * start the thread
     * @param file -
     */
    CountChar(String file) {
        this.file = file;
        this.thread = new Thread(this, "counting");
        thread.start();
    }
    /**
     * @return - symbol.
     */
    public int getSymbol() {
        return this.symbol;
    }
    /**
     * @return thread.
     */
    public Thread getThread() {
        return thread;
    }
    @Override
    public void run() {
        try {
            List<String> lines = readLne();
            for (String line : lines) {
                this.symbol += readSymbol(line);
                    if (this.thread.isInterrupted()) {
                        System.out.format("The program is interrupted \n");
                        break;
                    }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /**
     * reading lines from a file.
     *
     * @return ArrayList<String>
     * @throws IOException - "file not find".
     */
    private List<String> readLne() throws IOException {
        List<String> lines = new ArrayList<>();
        try {
            lines = Files.readAllLines(Paths.get(this.file), StandardCharsets.UTF_8);
        } catch (IOException e) {
            System.out.println("file not find");
        }
        return lines;
    }
    /**
     * counting the symbol in a line.
     *
     * @param line - from method "run"
     * @return the number of symbol in a line.
     */
    private int readSymbol(final String line) {
        int index = 0;

        for (int i = 0; i < line.length(); i++) {
            if (line.charAt(i) != ' ') {
                index++;
            }
        }
        return index;
    }
}
