package ru.job4j.threads;

/**
 * Problems.
 * demonstration of multithreading problem
 * Взависимости от времени задержки "delayTime" два потока могут успеть произвести
 * разные операции. Массив "data" не синхронизирован между нитями и может оказаться пустым
 * (при времени задержки 0) и тогда в цикле while
 * программа принудительно остановится, а массив успеет заполнится.
 * переменная "count" не синхронизированна и в потоках показывает разные значения.
 * В методе "second" ячейка 199 может не успеть поменять свое значение.
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Problems {
    /**
     * array int.
     */
    private int[] data;
    /**
     * current array index value.
     */
    private int count = 0;
    /**
     * delay time in the main threads.
     */
    private int delayTime;
    /**
     * constructor.
     * @param delayTime -
     */
    public Problems(int delayTime) {
        this.delayTime = delayTime;
    }
    /**
     * second threads.
     */
    private void second() {
        data = new int[200];
        for  (; this.count < 200; this.count++) {
            this.data[count] = count;
            System.out.format("%d ", count);
        }
        this.data[199] = 777;
    }
    /**
     * main threads.
     * @throws InterruptedException - thread interruption
     */
    public  void first() throws InterruptedException {
        new Thread(new Runnable() {
            public void run() {
                    second();
            }
        }).start();

        Thread.sleep(delayTime);

        while (this.data == null) {
            Thread.sleep(1000);
                System.out.format("\n The program is interrupted \n");
        }
        System.out.format(" \n data [199] = %d; last index = %d \n", this.data[199], this.count);
    }
}
