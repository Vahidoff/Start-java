package ru.job4j.bomberman;

import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

/**
 * BBoard.
 * game field
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class BBoard {
    /**
     * BMan coordinate recording.
     */
    private ConcurrentLinkedDeque<String> wayBMan = new ConcurrentLinkedDeque<>();
    /**
     * base array.
     */
    private final ReentrantLock[][] board;
    /**
     * if the flag is true then the game is over.
     */
    private boolean flag = false;
    /**
     * @return - flag.
     */
    public boolean isFlag() {
        return flag;
    }
    /**
     * constructor.
     * @param size - of base array
     */
    public BBoard(int size) {
        this.board = new ReentrantLock[size][size];
    }
    /**
     * @return this board.
     */
    public ReentrantLock[][] getBoard() {
        return board;
    }
    /**
     * setting the player on the field.
     * @param x - vertical.
     * @param y - horizontal.
     * @throws InterruptedException - thread interruption
     */
    protected void busy(int x, int y) throws InterruptedException {
        this.board[x][y] = new ReentrantLock();
        this.board[x][y].lock();
    }
    /**
     * attempt to make a new move.
     * write the path of the BMan in the queue "wayBMan"
     * comparison of the last coordinates of BMan with the following coordinates of monsters
     * it these coordinates match then the game is over
     * @param xBusy - current position
     * @param yBusy - current position
     * @param x     - new position
     * @param y     - new position
     * @return - the result of occupying a new position
     * @throws InterruptedException - thread interruption
     */
    protected boolean move(int xBusy, int yBusy, int x, int y) throws InterruptedException {
        boolean result = false;
            if (this.board[x][y] == null) {
                this.board[x][y] = new ReentrantLock();
            }
            if (!this.flag
                    & (!wayBMan.isEmpty() && !Thread.currentThread().getName().equals("BMan"))) {
                if (wayBMan.getLast().equals(x + " " + y)) {
                    this.flag = true;
                }
            }
            try {
                if (!this.flag & this.board[x][y].tryLock(500, TimeUnit.MILLISECONDS)) {
                    try {
                        this.board[x][y].lock();
                    } finally {
                        this.board[xBusy][yBusy] = new ReentrantLock();
                        if (Thread.currentThread().getName().equals("BMan")) {
                            wayBMan.addLast(x + " " + y);
                        }
                    }
                    result = true;
                }
            } catch (InterruptedException ie) {
                result = false;
            }
        return result;
    }
}
