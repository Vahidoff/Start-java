package ru.job4j.bomberman;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * BMan.
 * BMan that moves across the field from the class BBoard
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class BMan implements Runnable {
    /**
     * player's path.
     */
    private Deque<String> way = new ArrayDeque<>();
    /**
     * vertical.
     */
    private int x;
    /**
     * horizontal.
     */
    private int y;
    /**
     * next step.
     */
    private int nextX, nextY;
    /**
     * amount of step.
     */
    private static final int NUMBER_OF_MOVES = 2000;
    /**
     * game field.
     */
    private final BBoard bBoard;
    /**
     * getting the next step.
     */
    private BMove nextStep;
    /**
     * @return - way.
     */
    public Deque<String> getWay() {
        return way;
    }
    /**
     * constructor.
     * @param bBoard -
     * @param x -
     * @param y -
     * @throws InterruptedException - thread interruption
     */
    public BMan(BBoard bBoard, int x, int y) throws InterruptedException {
        this.bBoard = bBoard;
        this.x = x;
        this.y = y;
        this.bBoard.busy(x, y);
        this.nextStep = new BMove(bBoard);
    }
    /**
     * random move.
     */
    private void randomMove() {
        int[] step;
        try {
            do {
                step = this.nextStep.nextMove(this.x, this.y);
                this.nextX = step[0];
                this.nextY = step[1];
            } while (!this.bBoard.isFlag()
                    & !this.bBoard.move(this.x, this.y, step[0], step[1]));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        for (int i = 0; i < NUMBER_OF_MOVES; i++) {
            if (this.bBoard.isFlag()) {
                System.out.format("the game over for, thread name: %s \n",
                        Thread.currentThread().getName());
                break;
            }
            this.randomMove();
            this.x = this.nextX;
            this.y = this.nextY;
            way.addLast(this.x + " " + this.y);
        }
        if (!this.bBoard.isFlag()) {
            System.out.format("BMan won!!! \n");
        }
    }

}
