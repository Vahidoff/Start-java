package ru.job4j.bomberman;

import java.util.Random;
/**
 * BMove.
 * emulation of players movement
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class BMove {
    /**
     * game field.
     */
    private final BBoard bBoard;
    /**
     * constructor.
     * @param bBoard -
     */
    public BMove(BBoard bBoard) {
        this.bBoard = bBoard;
    }
    /**
     * next step.
     */
    private int nextX = 0, nextY = 0;
    /**
     * go up.
     * @param x - current position
     * @param y - current position
     * @return boolean result
     */
    private boolean moveUp(int x, int y) {
        if (x < this.bBoard.getBoard().length - 1) {
            this.nextX = x + 1;
            this.nextY = y;
            return true;
        } else {
            return false;
        }
    }
    /**
     * go left.
     * @param x - current position
     * @param y - current position
     * @return boolean result
     */
    private boolean moveLeft(int x, int y) {
        if (y > 0) {
            this.nextY = y - 1;
            this.nextX = x;
            return true;
        } else {
            return false;
        }
    }
    /**
     * go right.
     * @param x - current position
     * @param y - current position
     * @return boolean result
     */
    private boolean moveRight(int x, int y) {
        if (y < this.bBoard.getBoard()[x].length - 1) {
            this.nextY = y + 1;
            this.nextX = x;
            return true;
        } else {
            return false;
        }
    }
    /**
     * go down.
     * @param x - current position
     * @param y - current position
     * @return boolean result
     */
    private boolean moveDown(int x, int y) {
        if (x > 0) {
            this.nextX = x - 1;
            this.nextY = y;
            return true;
        } else {
            return false;
        }
    }
    /**
     * next step on the board.
     * @param x - current position
     * @param y - current position
     * @return  - new position
     */
    protected int[] nextMove(int x, int y) {
        Random rnd = new Random(System.currentTimeMillis());
        boolean flag = true;
        while (flag) {
            int number = rnd.nextInt(4);
            if (number == 0) {
                flag = !this.moveLeft(x, y);
            }
            if (number == 1) {
                flag = !this.moveUp(x, y);
            }
            if (number == 2) {
                flag = !this.moveDown(x, y);
            }
            if (number == 3) {
                flag = !this.moveRight(x, y);
            }
        }
        return new int[]{this.nextX, this.nextY};
    }

}
