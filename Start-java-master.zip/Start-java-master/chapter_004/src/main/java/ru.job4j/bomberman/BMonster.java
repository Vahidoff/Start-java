package ru.job4j.bomberman;

import java.util.ArrayDeque;
import java.util.Deque;
/**
 * BMonster.
 * Launching a thread for each monster
 * that moves across the field from the class BBoard
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class BMonster {
    /**
     * threads array.
     */
    private BMonsterOne[] monster;
    /**
     * number of monsters.
     */
    private int amount;
    /**
     * threads for monsters.
     */
    private Thread[] threads;
    /**
     * game field.
     */
    private final BBoard bBoard;
    /**
     * @return - BMonsterOne[] monster.
     */
    public BMonsterOne[] getMonster() {
        return monster;
    }
    /**
     * constructor.
     * @param bBoard -
     * @param amount -
     */
    public BMonster(BBoard bBoard, int amount) {
        this.amount = amount;
        this.bBoard = bBoard;
    }
    /**
     * launching a thread for each monster.
     * @throws InterruptedException - thread interruption
     */
    public void startMonster() throws InterruptedException {
        this.monster  = new BMonsterOne[amount];
        threads = new Thread[this.amount];
        for (int i = 0; i < amount; i++) {
            monster[i] = new BMonsterOne((i * 3), bBoard.getBoard().length - (i * 2 + 1));
            threads[i] = new Thread(monster[i]);
            threads[i].start();
        }
        for (Thread temp : threads) {
            temp.join();
        }

    }
    /**
     * BMonsterOne.
     * Monster that moves across the field from the class BBoard
     * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
     * @version $Id$
     * @since 0.1
     */
    class BMonsterOne extends Thread  {
        /**
         * player's path.
         */
        private Deque<String> way = new ArrayDeque<>();
        /**
         * vertical.
         */
        private int x;
        /**
         * horizontal.
         */
        private int y;
        /**
         * next step.
         */
        private int nextX, nextY;
        /**
         * amount of step.
         */
        private static final int NUMBER_OF_MOVES = 2000;
        /**
         * getting the next step.
         */
        private BMove nextStep;
        /**
         * @return - way.
         */
        public Deque<String> getWay() {
            return way;
        }
        /**
         * constructor.
         * @param x      -
         * @param y      -
         * @throws InterruptedException - thread interruption
         */
        BMonsterOne(int x, int y) throws InterruptedException {
            this.x = x;
            this.y = y;
            bBoard.busy(x, y);
            this.nextStep = new BMove(bBoard);
        }
        /**
         * random move.
         */
        private void randomMove() {
            int[] step;
            try {
                do {
                    step = this.nextStep.nextMove(this.x, this.y);
                    this.nextX = step[0];
                    this.nextY = step[1];
                } while (!bBoard.isFlag() & !bBoard.move(this.x, this.y, this.nextX, this.nextY));
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        @Override
        public void run() {
            for (int i = 0; i < NUMBER_OF_MOVES; i++) {
                if (bBoard.isFlag()) {
                    System.out.format("the game over for Monster, thread name: %s \n",
                            Thread.currentThread().getName());
                    break;
                }
                this.randomMove();
                this.x = this.nextX;
                this.y = this.nextY;
                way.addLast(this.x + " " + this.y);
            }
        }
    }
}
