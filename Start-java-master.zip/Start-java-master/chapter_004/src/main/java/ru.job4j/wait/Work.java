package ru.job4j.wait;

import java.util.LinkedList;
import java.util.concurrent.Executor;
/**
 * Work.
 * thread queue
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Work implements Executor {
    /**
     * amount thread.
     */
    private final int amountThreads;
    /**
     * threads array.
     */
    private final PoolWorker[] threads;
    /**
     * the queue for tasks.
     */
    private final LinkedList<Runnable> queue;
    /**
     * constructor.
     * starts threads by number of cores
     */
    public Work() {
        this.amountThreads = Runtime.getRuntime().availableProcessors();
        queue = new LinkedList<>();
        threads = new PoolWorker[amountThreads];

        for (int i = 0; i < amountThreads; i++) {
            threads[i] = new PoolWorker();
            threads[i].start();
        }
        System.out.format("number of running threads: %d \n", this.amountThreads);
    }
    /**
     * adding task to the queue.
     * @param r - task
     */
    public void execute(Runnable r) {
        synchronized (queue) {
            queue.addLast(r);
            queue.notify();
        }
    }
    /**
     * PoolWorker.
     * launching tasks
     * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
     * @version $Id$
     * @since 0.1
     */
    private class PoolWorker extends Thread {
        /**
         * launching tasks from the queue.
         */
        public void run() {
            Runnable r;

            while (true) {
                synchronized (queue) {
                    while (queue.isEmpty()) {
                        try {
                            queue.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    r = queue.removeFirst();
                }
                r.run();
            }
        }
    }
}
