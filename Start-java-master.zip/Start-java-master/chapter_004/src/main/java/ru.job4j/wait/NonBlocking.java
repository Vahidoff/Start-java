package ru.job4j.wait;

import java.util.concurrent.ConcurrentHashMap;
/**
 * NonBlocking.
 * multi-threaded storage with the version control system
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class NonBlocking {
    /**
     * basic storage.
     * key - String
     * value - UserW
     */
    private ConcurrentHashMap<String, UserW> storage = new ConcurrentHashMap<>();
    /**
     * adding element.
     * @param id - key
     * @param newUser -UserW
     */
    public void add(String id, UserW newUser) {
        this.storage.put(id, newUser);
    }
    /**
     * update value.
     * @param id - key
     * @param user - change
     * @throws Exception - the conflict of the version
     */
    public void update(String id, UserW user) throws Exception {
        this.storage.computeIfPresent(id, (k, v) -> {
            if (v.getVersion() == user.getVersion()) {
                this.storage.replace(k, user);
                user.updateVersion();
            } else {
                throw new OptimisticException("the conflict of the version");
            }
            return user;
        });
    }
    /**
     * deleting.
     * @param id - key
     */
    public void delete(String id) {
        this.storage.remove(id);
    }
    /**
     * getting UserW.
     * @param key -
     * @return - UserW
     */
    public UserW get(String  key) {
        if (this.storage.containsKey(key)) {
            return this.storage.get(key);
        }
        return null;
    }
}
