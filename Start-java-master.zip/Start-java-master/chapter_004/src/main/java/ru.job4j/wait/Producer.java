package ru.job4j.wait;

import java.util.Random;
/**
 * Producer.
 * the class that queues data (to DepositWait)
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Producer implements Runnable {
    /**
     * DepositWait - the queue of data.
     */
    private final DepositWait output;
    /**
     * the total quantity of data.
     */
    private final int count;
    /**
     * the arbitrary data set.
     */
    private static final Random RN = new Random();
    /**
     * constructor.
     * @param output -
     * @param count -
     */
    public Producer(DepositWait output, int count) {
        this.output = output;
        this.count = count;
    }
    /**
     * write data to the queue.
     */
    @Override
    public void run() {
            for (int i = 0; i < count; ++i) {
                output.putNotify(String.valueOf(System.currentTimeMillis() + RN.nextInt()));
            }
        System.out.println("Producer thread finished");
    }
}
