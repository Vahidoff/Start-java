package ru.job4j.wait;
/**
 * OptimisticException.
 * definition of the conflict of the version for the class UserW
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class OptimisticException extends RuntimeException {
    /**
     * constructor.
     * @param s -
     */
    public OptimisticException(String s) {
        super(s);
    }
}
