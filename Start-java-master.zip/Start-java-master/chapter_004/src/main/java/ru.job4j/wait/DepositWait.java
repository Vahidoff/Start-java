package ru.job4j.wait;

import java.util.ArrayDeque;
import java.util.Deque;
/**
 * DepositWait.
 * data transfer class from manufacturer to customer
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class DepositWait {
    /**
     * data buffer in the queue.
     */
    private final int buffer = 5;
    /**
     * the current value of the queue buffer.
     */
    private int index = -1;
    /**
     * the sequence number of data.
     */
    private int amount = 1;
    /**
     * temporary storage place.
     */
    private final Deque<String> deposit = new ArrayDeque<>();
    /**
     * getting data from the queue.
     * @return Deque<String> deposit - element
     */
    public String getWait() {

        synchronized (this.deposit) {
            try {
                if (this.deposit.size() == 0) {
                    this.deposit.wait();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return this.deposit.poll();
        }
    }
    /**
     * write data to the queue.
     * @param s - data
     */
    public void putNotify(String s) {

        synchronized (this.deposit) {
            this.deposit.add(s + " " + this.amount++);
            if (this.index++ >= buffer) {
                this.deposit.notify();
                this.index = 0;
            }
        }
    }
}
