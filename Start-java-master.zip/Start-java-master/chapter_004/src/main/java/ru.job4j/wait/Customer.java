package ru.job4j.wait;

import java.util.LinkedList;
import java.util.List;
/**
 * Customer.
 * the class gets data from the DepositWait
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Customer implements Runnable {
    /**
     * DepositWait - the queue of data.
     */
    private final DepositWait deposit;
    /**
     * the total quantity of data.
     */
    private final int count;
    /**
     * customer data storage.
     */
    private List<String> bag = new LinkedList<>();
    /**
     * constructor.
     * @param deposit -
     * @param count -
     */
    public Customer(DepositWait deposit, int count) {
        this.deposit = deposit;
        this.count = count;
    }
    /**
     * @return - bag.
     */
    public List<String> getBag() {
        return bag;
    }
    /**
     * getting data from the queue.
     */
    @Override
    public void run() {
        String temp;
        while (true) {
            if (this.bag.size() <= this.count) {
                temp = deposit.getWait();
                this.bag.add(temp);
            } else {
                break;
            }
        }
    }

}
