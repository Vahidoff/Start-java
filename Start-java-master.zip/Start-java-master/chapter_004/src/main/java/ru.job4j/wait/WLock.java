package ru.job4j.wait;
/**
 * WLock.
 * realization methods "lock" and "unlock" using the methods "wait" and "notify"
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class WLock {
    /**
     * Flag of lock state.
     */
    private boolean blocker = false;
    /**
     * @return - blocker.
     */
    public boolean isBlocker() {
        return this.blocker;
    }
    /**
     * realization methods "lock".
     */
    public synchronized void wLock() {
        while (blocker) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        this.blocker = true;
    }
    /**
     * realization method "unlock" using the methods "wait" and "notify".
     */
    public synchronized void wUnlock() {
        while (!blocker) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        this.blocker = false;
        notify();
    }
}
