package ru.job4j.wait;

/**
 * UserW.
 * thread queue
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class UserW {
    /**
     * revision version.
     */
    private int version;
    /**
     * name.
     */
    private String name;
    /**
     * constructor.
     * @param name -
     */
    public UserW(String name) {
        this.version = 0;
        this.name = name;
    }
    /**
     * @return version.
     */
    public int getVersion() {
        return version;
    }
    /**
     * version setting.
     * @param version -
     */
    public void setVersion(int version) {
        this.version = version;
    }
    /**
     * @return name.
     */
    String getName() {
        return this.name;
    }
    /**
     * name setting.
     * @param name -
     */
    void setName(String name) {
        this.name = name;
    }
    /**
     * version change.
     */
    void updateVersion() {
        this.version++;
    }
}
