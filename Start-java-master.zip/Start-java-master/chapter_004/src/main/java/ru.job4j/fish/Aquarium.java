package ru.job4j.fish;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Aquarium.
 * Displaying messages about the status of the aquarium
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Aquarium extends Thread {
    /**
     * amount of the messages.
     */
    private final int amount;
    /**
     * fish serial number.
     */
    protected int count = 1;
    /**
     * storage of all fish.
     */
    private List<Fish> schoolFish = new CopyOnWriteArrayList<>();
    /**
     * reports of the birth of fish.
     */
    private ConcurrentLinkedQueue<String> bornDeque = new ConcurrentLinkedQueue<>();
    /**
     * reports of the ending of fish.
     */
    private ConcurrentLinkedQueue<String> endQueue = new ConcurrentLinkedQueue<>();
    /**
     * reports of the meeting of fish.
     */
    private ConcurrentLinkedQueue<String> meetQueue = new ConcurrentLinkedQueue<>();
    /**
     * reports of the aquarium status of fish.
     */
    private ConcurrentLinkedQueue<String> statusQueue = new ConcurrentLinkedQueue<>();
    /**
     * constructor.
     * the initial launch of two fish
     * @param amount -
     */
    public Aquarium(int amount) {
        this.amount = amount;
        Fish fishOne = new Fish(setCount(), System.currentTimeMillis(), setLifetime(), setSex());
        this.schoolFish.add(fishOne);
        Fish fishTwo = new Fish(setCount(), System.currentTimeMillis(), setLifetime(), setSex());
        this.schoolFish.add(fishTwo);
    }
    /**
     * the consecutive messages output.
     */
    public void run() {
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        while (!statusQueue.isEmpty()) {
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.print(bornDeque.poll());
            System.out.print(endQueue.poll());
            System.out.print(meetQueue.poll());
            System.out.println(statusQueue.poll());
            System.out.println();
        }
    }
    /**
     * generation of the reports on the birth of fish.
     */
    class LifeFish implements Runnable {
        /**
         * messages starting output.
         * @throws InterruptedException - thread interruption
         */
        private void life() throws InterruptedException {
            Thread.sleep(200);
                Fish fish = new Fish(setCount(), System.currentTimeMillis(), setLifetime(), setSex());
                schoolFish.add(fish);
                bornDeque.offer(String.format("Fish number %d was born \n", fish.count));
        }

        @Override
        public void run() {
            for (int i = 0; i < amount; i++) {
                try {
                    this.life();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    /**
     * generation of the reports on the ending of fish.
     */
    class EndingFish  implements Runnable {
        /**
         * search for fish with expired.
         */
        private void endFish() throws InterruptedException {
            boolean flag = true;
            Thread.sleep(200);
                for (int i = 0; i < schoolFish.size(); i++) {
                Fish temp = schoolFish.get(i);
                long buffer = temp.lifetime * 1000;
                if ((buffer - (System.currentTimeMillis() - temp.born)) < 0) {
                    endQueue.offer(String.format("Fish number %d finished its journey. \n", temp.count));
                    schoolFish.remove(i);
                    flag = false;
                    break;
                }
            }
            if (flag) {
                endQueue.offer("All fish are alive \n");
            }
        }
        @Override
        public void run() {
            for (int i = 0; i < amount; i++) {
                    try {
                        this.endFish();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
            }
        }
    }
    /**
     * @return - search for random fish number.
     */
    private int randomIndex() {
        Random rnd = new Random(System.currentTimeMillis());
        return rnd.nextInt(this.schoolFish.size());
    }
    /**
     * generation of the reports on the meeting of fish.
     */
    class Appointment implements Runnable {
        /**
         * search for two fish for a meeting.
         * if a pair of fish same sex, then there is a meeting between them
         * if a fish of different sex, then a born a new fish
         */
        void meeting() throws InterruptedException {
            Thread.sleep(200);
            boolean flag = true;
            if (schoolFish.size() < 4) {
                meetQueue.offer("There is no one to meet");
                flag = false;
            }
            int indexOne = randomIndex();
            Fish fishOne = schoolFish.get(indexOne);
            while (flag) {
                int indexTwo = randomIndex();
                Fish fishTwo = schoolFish.get(indexTwo);
                if (fishOne.sex != fishTwo.sex) {
                    Fish temp =
                            new Fish(setCount(), System.currentTimeMillis(), setLifetime(), setSex());
                    schoolFish.add(temp);
                    continue;
                }
                if (fishOne.count != fishTwo.count) {
                    meetQueue.offer(String.format("Fish number %d met with fish number %d \n",
                            fishOne.count, fishTwo.count));
                    flag = false;
                }
            }
        }
        @Override
        public void run() {
            for (int i = 0; i < amount; i++) {
                try {
                        this.meeting();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    /**
     * generation of the reports on the aquarium status of fish.
     */
    class StatusFish implements Runnable {
        /**
         * output message about the status of the aquarium in the current time.
         */
        private void statusFish() throws InterruptedException {
            Thread.sleep(200);
            Date dateNow = new Date();
            SimpleDateFormat formatForDateNow =
                    new SimpleDateFormat("E yy.MM.dd 'и время' hh:mm:ss a zzz");
            statusQueue.offer("the population of the aquarium at the moment "
                    + formatForDateNow.format(dateNow) + " is "
                    + schoolFish.size() + " fishes");
        }
        @Override
        public void run() {
            for (int i = 0; i < amount; i++) {
                try {
                        this.statusFish();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * @return - assigning a ordinal number to a fish.
     */
    private int setCount() {
        return this.count++;
    }
    /**
     * @return - setting a lifetime of a fish in seconds.
     */
    private int setLifetime() {
        Random rnd = new Random(System.currentTimeMillis());
        return 1 + rnd.nextInt(10);
    }
    /**
     * @return - setting sex of a fish.
     */
    private Fish.SOF setSex() {
        if (this.count % 2 == 0) {
            return Fish.SOF.FEMALE;
        } else {
            return Fish.SOF.MALE;
        }
    }
}
