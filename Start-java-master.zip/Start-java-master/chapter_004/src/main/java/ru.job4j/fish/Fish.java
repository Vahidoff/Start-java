package ru.job4j.fish;

/**
 * Fish.
 * emulation of fish properties.
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Fish implements Comparable<Fish> {
    /**
     * fish serial number.
     */
    protected int count = 0;
    /**
     * fish birth time - current time.
     */
    protected long born;
    /**
     * a lifetime of a fish in seconds.
     */
    protected int lifetime;
    /**
     * sex of a fish.
     */
    protected SOF sex;
    /**
     * sex of fish
     */
    enum SOF { FEMALE, MALE
    }
    /**
     * constructor.
     * @param count -
     * @param born -
     * @param lifetime -
     * @param sex -
     */
    protected Fish(int count, long born, int lifetime, SOF sex) {
        this.count = count;
        this.born = born;
        this.lifetime = lifetime;
        this.sex = sex;
    }
    @Override
    public int compareTo(Fish fish) {
        if (this.lifetime == fish.lifetime) {
            return 0;
        } else {
            return this.lifetime < fish.lifetime ? -1 : 1;
        }
    }
    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj == null || obj.getClass() != this.getClass()) {
            return false;
        }
        Fish fish = (Fish) obj;
        return this.count == fish.count && this.born == fish.born
                && this.lifetime == fish.lifetime;
    }
    @Override
    public int hashCode() {
        return this.count * 37 + (int) (this.born >>> 32);
    }

}
