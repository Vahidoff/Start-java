package ru.job4j.fish;
import org.junit.Test;

/**
 * Test.
 * Aquarium class
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class AquariumTest {
    /**
     * Test1.
     * running five threads.
     */
    @Test
    public void whenAquariumMultiThreadStringOut() throws InterruptedException {
        Aquarium aquarium = new Aquarium(100);
        Aquarium.Appointment appointment = aquarium.new Appointment();
        Aquarium.EndingFish endingFish = aquarium.new EndingFish();
        Aquarium.StatusFish statusFish = aquarium.new StatusFish();
        Aquarium.LifeFish lifeFish = aquarium.new LifeFish();

        Thread threadAppointment = new Thread(appointment);
        Thread ending = new Thread(endingFish);
        Thread status = new Thread(statusFish);
        Thread life = new Thread(lifeFish);

        life.start();
        threadAppointment.start();
        ending.start();
        status.start();
        aquarium.start();

        life.join();
        threadAppointment.join();
        ending.join();
        status.join();
        aquarium.join();
    }
}
