package ru.job4j.bomberman;
import org.junit.Test;

import java.util.concurrent.locks.ReentrantLock;

/**
 * Test.
 * Test class BMan, BBoard
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class BManTest {
    /**
     * Test1.
     * check the movement of BMan on the BBoard field.
     * @throws InterruptedException - thread interruption
     */
    @Test
    public void whenBManMoveThenBBoardRun() throws InterruptedException {
        BBoard board = new BBoard(20);
        board.getBoard()[0][0] = new ReentrantLock();
        board.getBoard()[0][0].lock();
        board.getBoard()[19][19] = new ReentrantLock();
        board.getBoard()[19][19].lock();
        board.getBoard()[0][9] = new ReentrantLock();
        board.getBoard()[0][9].lock();
        board.getBoard()[19][0] = new ReentrantLock();
        board.getBoard()[19][0].lock();
        BMan man = new BMan(board, 5, 5);

        Thread thread = new Thread(man);
        thread.start();
        thread.join();

        for (int i = 0; i < 20; i++) {
            System.out.format("BMan way: %s \n",
                    man.getWay().pollLast());
        }
    }
    /**
     * Test2.
     * Test for BMan, BBoard, BMove, BMonster.
     * check the movement of BMan and Monsters on the BBoard field in different threads.
     * @throws InterruptedException - thread interruption
     */
    @Test
    public void whenBMonsterBManMoveThenBBoardRun() throws InterruptedException {
        BBoard board = new BBoard(30);
        board.getBoard()[0][10] = new ReentrantLock();
        board.getBoard()[0][10].lock();
        board.getBoard()[2][10] = new ReentrantLock();
        board.getBoard()[2][10].lock();
        board.getBoard()[19][10] = new ReentrantLock();
        board.getBoard()[19][10].lock();
        board.getBoard()[17][10] = new ReentrantLock();
        board.getBoard()[17][10].lock();

        BMonster monsters = new BMonster(board, 3);
        BMan man = new BMan(board, 5, 5);

        Thread threadBMan = new Thread(man);
        threadBMan.setName("BMan");
        threadBMan.start();
        monsters.startMonster();
        threadBMan.join();

        System.out.format("number of BMan moves: %d, number of monsters moves: %d, %d, %d \n",
                man.getWay().size(), monsters.getMonster()[0].getWay().size(),
                monsters.getMonster()[1].getWay().size(),
                monsters.getMonster()[2].getWay().size());

        for (int i = 0; i < 20; i++) {
            System.out.format("BMan: %s, Monsters: %s, %s, %s \n",
                    man.getWay().pollLast(), monsters.getMonster()[0].getWay().pollLast(),
                    monsters.getMonster()[1].getWay().pollLast(),
                    monsters.getMonster()[2].getWay().pollLast());
        }
    }
}
