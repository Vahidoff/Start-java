package ru.job4j.synchronize;
import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
/**
 * Test.
 * UserStoreT
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class UserStoreTTest {
    /**
     * Test1.
     * There two threads.
     * depending of the distributing of threads, the test
     * dots not always coverage
     * @throws InterruptedException - thread interruption
     */
    @Test
    public void whenUserTAddUpdateDeleteThenContains() throws InterruptedException {
        final UserStoreT storeOne = new UserStoreT();
        final UserStoreT storeTwo = new UserStoreT();

        for (int i = 1; i < 21; i++) {
            storeOne.add(new UserT(i, 100));
        }
        for (int i = 1; i < 21; i++) {
            storeTwo.add(new UserT(i, 200));
        }
        Thread threadOne = new Thread(new Runnable() {

            @Override
            public void run() {
                storeOne.delete(storeOne.getUT(3));
                storeOne.getUT(4).setAmount(777);
                storeOne.update(storeOne.getUT(4));

                storeTwo.delete(storeTwo.getUT(2));
                storeTwo.getUT(4).setAmount(555);
                storeTwo.update(storeTwo.getUT(4));
            }
        });
        threadOne.start();

        Thread threadTwo = new Thread(new Runnable() {
            @Override
            public void run() {
                storeOne.transfer(5, 6, 50);
                storeOne.transfer(3, 6, 50);

                storeTwo.transfer(5, 6, 20);
                storeTwo.transfer(2, 4, 20);
            }
        });
        threadTwo.start();

        threadOne.join();
        threadTwo.join();

        StringBuilder resultOne = new StringBuilder();
        for (int i = 1; i < 8; i++) {
            int temp = storeOne.getUT(i).getAmount();
            System.out.format(" user id %d user amount %d  \n", storeOne.getUT(i).getId(), temp);
            resultOne.append(temp).append(" ");
        }

        StringBuilder resultTwo = new StringBuilder();
        System.out.println("storeTwo");
        for (int i = 1; i < 8; i++) {
            int temp = storeTwo.getUT(i).getAmount();
            System.out.format(" user id %d user amount %d  \n",
                    storeTwo.getUT(i).getId(), temp);
            resultTwo.append(temp).append(" ");
        }

        assertThat(resultOne.toString(), is("100 100 -1 777 50 150 100 "));
        assertThat(resultTwo.toString(), is("200 -1 200 555 180 220 200 "));
    }

}
