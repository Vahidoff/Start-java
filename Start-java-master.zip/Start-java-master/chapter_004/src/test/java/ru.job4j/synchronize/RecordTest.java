package ru.job4j.synchronize;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
/**
 * Test.
 * Record
 * multithreaded counter
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class RecordTest {
    /**
     * Test 1.
     * there two threads
     * @throws InterruptedException - thread interruption
     */
    @Test
    public void whenReadSmallTextShouldGettingNumberSymbol() throws InterruptedException {
        List<Count> listEarly = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            listEarly.add(new Count(1));
        }
        List<Count> listFresh = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            listFresh.add(new Count(5));
        }
        List<Count> listThird = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            listThird.add(new Count(7));
        }

        Record recordOne = new Record(listEarly, listFresh);
        Record recordTwo = new Record(listEarly, listThird);
        recordOne.start();
        recordTwo.start();
        recordOne.join();
        recordTwo.join();

        for (Count count : recordOne.getResult()) {
            System.out.format(" recordOne meter %d; ", count.getMeter());
        }
        System.out.format("\n \n");
        for (Count count : recordTwo.getResult()) {
            System.out.format(" recordTwo meter %d; ", count.getMeter());
        }
    }
}
