package ru.job4j.synchronize;

import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * Test.
 * ParallelSearch
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class ParallelSearchTest {
    /**
     * getting folder paths.
     */
    private static class DepositFolder {
        /**
         * test folder.
         * https://yadi.sk/d/iqha1T2W3MmCVN
         */
        private final String folderOne = "D:\\Users\\Arbuz333\\Temp Java";
        /**
         * the file with word "Clinton".
         */
        private final File fileEight =
                new File("D:\\Users\\Arbuz333\\Temp Java\\ParallelEight.txt");
        /**
         * the file without word "Clinton".
         */
        private final File fileSix =
                new File("D:\\Users\\Arbuz333\\Temp Java\\ParallelSix.txt");
    }
    /**
     * Test 1.
     * readFile in TextSearch.
     * single-threaded search
     * @throws IOException          - "file not find".
     * @throws InterruptedException - thread interruption
     */
    @Test
    public void whenReadFolderShouldGetPath() throws IOException, InterruptedException {
        DepositFolder folder = new DepositFolder();
        TextSearch search = new TextSearch(folder.fileEight, "Clinton");
        TextSearch searchTwo = new TextSearch(folder.fileSix, "Clinton");

        String result = search.readFile();
        String resultNot = searchTwo.readFile();
        System.out.println(result);
        System.out.println(resultNot);

        String expected = folder.fileEight.toString();

        assertThat(result, is(expected));
        assertThat(resultNot, is("This text is not found"));
    }
    /**
     * Test 2.
     * threadsStart in ParallelSearch.
     * multithreaded search
     * @throws IOException          - "file not find".
     * @throws InterruptedException - thread interruption
     */
    @Test
    public void whenReadFolderListShouldGetPath() throws IOException, InterruptedException {
        DepositFolder folder = new DepositFolder();
        List<String> extensions = new ArrayList<>();
        extensions.add(".txt");
        extensions.add(".xml");
        extensions.add(".dwg");
        ParallelSearch parallel = new ParallelSearch(folder.folderOne, "Clinton", extensions);

        Set<String> result = parallel.threadsStart();
        System.out.println(result);

        Set<String> resultFiles = new TreeSet<>();
        for (String files : result) {
            resultFiles.add(new File(files).getName());
        }

        Set<String> expected = new TreeSet<>();
        String[] files = {"ParallelEight.txt", "ParallelEleven.dwg", "ParallelFive.xml",
                "ParallelFour.txt", "ParallelNine.xml", "ParallelOne.xml", "ParallelThirteen.dwg",
                "WordsSpaces.txt"};
        expected.addAll(Arrays.asList(files));

        assertThat(resultFiles, is(expected));
    }
}
