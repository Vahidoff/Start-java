package ru.job4j.synchronize;
import org.junit.Test;

import java.util.Iterator;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
/**
 * Test.
 * ConnectedListTSafe
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class ConnectedListTSafeTest {
    /**
     * new ConnectedListTSafe.
     */
    private ConnectedListTSafe<Integer> dynamic = new ConnectedListTSafe<>();
    /**
     * the original elements toString.
     */
    private StringBuilder result = new StringBuilder();
    /**
     * the sum of all the elements.
     */
    private int sum = 0;
    /**
     * multithreaded writing of elements.
     * @throws InterruptedException - thread interruption
     */
    private void startTest() throws InterruptedException {
        Thread threadOne = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 10; i++) {
                    dynamic.addT(i + 200);
                }
            }
        });
        Thread threadTwo = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 10; i++) {
                    dynamic.addT(i + 500);
                }
            }
        });
        threadTwo.start();
        threadOne.start();
        threadOne.join();
        threadTwo.join();
    }
    /**
     * Test1.
     * There two threads.
     * multithreading reading end change elements
     * folding all the elements
     * @throws InterruptedException - thread interruption
     */
    @Test
    public void whenDynamicArrayTSafeAddThenIteratorTrue() throws InterruptedException {
        StringBuilder threadRead = new StringBuilder();
        startTest();

        Thread resultOne = new Thread(new Runnable() {
            @Override
            public void run() {
                dynamic.deleteTFirst();
                dynamic.deleteTEnd();
                for (int i = 0; i < 16; i++) {
                    threadRead.append(dynamic.getT(i)).append(" ");
                }
            }
        });
        Thread resultTwo = new Thread(new Runnable() {
            @Override
            public void run() {
                dynamic.deleteTEnd();
                dynamic.deleteTFirst();
                for (int i = 0; i < 16; i++) {
                    threadRead.append(dynamic.getT(i)).append(" ");
                }
            }
        });
        resultOne.start();
        resultTwo.start();
        resultOne.join();
        resultTwo.join();

        Iterator it = dynamic.iterator();
        while (it.hasNext()) {
            int temp = (Integer) it.next();
            result.append(temp).append(" ");
            sum += temp;
        }

        System.out.format("thread read = %s \n", threadRead.toString());
        System.out.format("the original sixteen elements - %s", result.toString());
        assertThat(sum, is(5672));
    }
}
