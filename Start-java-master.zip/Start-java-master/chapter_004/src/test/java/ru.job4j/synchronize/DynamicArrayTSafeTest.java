package ru.job4j.synchronize;
import org.junit.Test;

import java.util.Iterator;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
/**
 * Test.
 * DynamicArrayTSafe
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class DynamicArrayTSafeTest {
    /**
     * new DynamicArrayTSafe.
     */
    private DynamicArrayTSafe<Integer> dynamic = new DynamicArrayTSafe<>();
    /**
     * the original twenty elements toString.
     */
    private StringBuilder result = new StringBuilder();
    /**
     * the sum of all the elements.
     */
    private int sum = 0;
    /**
     * multithreaded writing of elements..
     * @throws InterruptedException - thread interruption
     */
    private void startTest() throws InterruptedException {
        Thread threadOne = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 10; i++) {
                    dynamic.addT(i + 100);
                }
            }
        });
        Thread threadTwo = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 10; i++) {
                    dynamic.addT(i + 500);
                }
            }
        });
        threadTwo.start();
        threadOne.start();
        threadOne.join();
        threadTwo.join();
    }
    /**
     * Test1.
     * There two threads.
     * multithreading reading
     * folding all the elements
     * @throws InterruptedException - thread interruption
     */
    @Test
    public void whenDynamicArrayTSafeAddThenIteratorTrue() throws InterruptedException {
        StringBuilder threadRead = new StringBuilder();
        startTest();

        Thread resultOne = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 20; i++) {
                    threadRead.append(dynamic.getT(i)).append(" ");
                }

            }
        });

        Thread resultTwo = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 20; i++) {
                    threadRead.append(dynamic.getT(i)).append(" ");
                }

            }
        });
        resultOne.start();
        resultTwo.start();
        resultOne.join();
        resultTwo.join();

        Iterator it = dynamic.iterator();
        while (it.hasNext()) {
            int temp = (Integer) it.next();
            result.append(temp).append(" ");
            sum += temp;
        }

        System.out.format("thread read = %s \n", threadRead.toString());
        System.out.format("the original twenty elements - %s", result.toString());
        assertThat(sum, is(6090));
    }
}
