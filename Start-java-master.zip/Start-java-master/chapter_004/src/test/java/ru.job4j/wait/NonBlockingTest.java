package ru.job4j.wait;

import org.junit.Test;
/**
 * Test.
 * NonBlocking
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class NonBlockingTest {
    /**
     * Test1.
     * two threads that update one element
     * @throws InterruptedException - thread interruption
     */
    @Test
    public void whenThreadsAddingThenContents() throws InterruptedException {
        NonBlocking nonB = new NonBlocking();
        UserW temp = new UserW("Junior");
        nonB.add(((Integer) (3700)).toString(), temp);

        Thread threadOne = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 100; i++) {
                    temp.setName("Senior");
                    try {
                        nonB.update(((Integer) (3700)).toString(), temp);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        Thread threadTwo = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 100; i++) {
                    temp.setName("Middle");
                    try {
                        nonB.update(((Integer) (3700)).toString(), temp);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        threadTwo.start();
        threadOne.start();
        threadTwo.join();
        threadOne.join();

        System.out.format("storage element 3700 name: %s: ; and version %d .\n",
                nonB.get(((Integer) (3700)).toString()).getName(),
                nonB.get(((Integer) (3700)).toString()).getVersion());
    }
    /**
     * Test2.
     * verifying yje version conflict
     * @throws Exception - the conflict of the version
     */
    @Test
    public void whenAddingDifferentVersionThenException() throws Exception {
        NonBlocking nonB = new NonBlocking();
        UserW user = new UserW("One");
        nonB.add(((Integer) (37)).toString(), user);
        user.setName("Two");
        nonB.update(((Integer) (37)).toString(), user);

        UserW userTwo = new UserW("Three");
        try {
            nonB.update(((Integer) (37)).toString(), userTwo);
        } catch (OptimisticException oe) {
            System.out.format("%s \n", "Version conflict in this Test2.");
        }

        System.out.format("element 37 version: %d ; and element userTwo version: %d .\n",
                nonB.get(((Integer) (37)).toString()).getVersion(),
                userTwo.getVersion());

    }
}
