package ru.job4j.wait;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * Test.
 * class Work, task queue testing
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class WorkTest {
    /**
     * computational load.
     */
    private class Counter {
        /**
         * does not carry semantic load.
         * @param a -
         * @return Double
         */
        private Double count(double a) {
            for (int i = 0; i < 1000000; i++) {
                a = a + Math.tan(a);
            }
            return a;
        }
    }
    /**
     * Test1.
     * @throws InterruptedException - thread interruption
     * @throws  ExecutionException - RuntimeException
     */
    @Test
    public void whenPoolThreadThenAllThreadsWork() throws InterruptedException, ExecutionException {
        Counter counter = new Counter();
        Work work = new Work();
        List<Future<Double>> futures = new ArrayList<>();

        for (int i = 0; i < 40; i++) {
            final int j = i;
            futures.add(CompletableFuture.supplyAsync(() -> counter.count(j),
                    work
            ));
        }

        double value = 0;
        for (Future<Double> future : futures) {
            value += future.get();
        }
        System.out.format(" value : %f", value);

        assertThat((int) value, is(-102351136));
    }
}
