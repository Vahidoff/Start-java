package ru.job4j.wait;
import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
/**
 * Test.
 * Producer and Customer
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class CustomerTest {
    /**
     * the total quantity of data.
     * the data only output for five elements
     */
    private final int count = 20;
    /**
     * Test1.
     * @throws InterruptedException - thread interruption
     */
    @Test
    public void whenProducerAddingThenCustomerPutting() throws InterruptedException {
        DepositWait deposit = new DepositWait();
        Thread producer = new Thread(new Producer(deposit, this.count));
        Customer people = new Customer(deposit, this.count);
        Thread customer = new Thread(people);

        producer.start();
        customer.start();
        producer.join();

        System.out.println(people.getBag());
        assertThat(people.getBag().size(), is(this.count));
    }

}
