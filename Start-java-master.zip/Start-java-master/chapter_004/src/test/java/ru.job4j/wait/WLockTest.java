package ru.job4j.wait;

import org.junit.Test;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Lock;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
/**
 * Test.
 * checking resource protection methods from the class "WLock"
 * and from the class "Lock"
 * the results of both calculation must be the same
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class WLockTest {
    /**
     * computational load.
     */
    private class WCounter {
        /**
         * result.
         */
        private double sum = 0;
        /**
         * does not carry semantic load.
         */
        private void count() {
            int i = 0;
            for (int j = 1; j < 40; j++) {
                for (; i < 100000; i++) {
                    synchronized (this) {
                        this.sum += Math.atan(j);
                    }
                }
            }
        }
    }
    /**
     * use resource protection in a multithreaded program.
     * using "lock" and "unlock" methods from java.util.concurrent.locks.Lock.
     */
    public class LockTrue implements Runnable {
        /**
         * resource.
         */
        private WCounter resource;
        /**
         * blocking.
         */
        private Lock lock;
        /**
         * constructor.
         * @param wc - computational load
         */
        public LockTrue(WCounter wc) {
            this.resource = wc;
            this.lock = new ReentrantLock();
        }
        /**
         * resource use.
         */
        @Override
        public void run() {
            try {
                if (lock.tryLock(10, TimeUnit.SECONDS)) {
                    resource.count();
                    System.out.format("thread name %s \n", Thread.currentThread().getName());
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            } finally {
                lock.unlock();
            }
        }
    }
    /**
     * use resource protection in a multithreaded program.
     * using "wLock" and "wUnlock" methods WLock class
     */
    public class LockTry implements Runnable {
        /**
         * resource.
         */
        private WCounter resource;
        /**
         * blocking.
         */
        private WLock lock;
        /**
         * constructor.
         * @param wc - computational load
         */
        public LockTry(WCounter wc) {
            this.resource = wc;
            this.lock = new WLock();
        }
        /**
         * resource use.
         */
        @Override
        public void run() {
            try {
                this.lock.wLock();
                if (this.lock.isBlocker()) {
                    this.resource.count();
                    System.out.format("thread name %s \n", Thread.currentThread().getName());
                }
            } finally {
                this.lock.wUnlock();
            }
        }
    }
    /**
     * the result of the first test.
     */
    private double sumTest1 = 0;
    /**
     * Test1.
     * LockTrue
     * @throws InterruptedException - thread interruption
     */
    @Test
    public void whenLockTrueThenThreadsSafe() throws InterruptedException {

        WCounter load = new WCounter();
        LockTrue lockTrue = new LockTrue(load);
        LockTrue lockTwo = new LockTrue(load);
        LockTrue lockThree = new LockTrue(load);

        Thread threadOne = new Thread(lockTrue);
        Thread threadTwo = new Thread(lockTwo);
        Thread threadThree = new Thread(lockThree);
        threadOne.start();
        threadThree.start();
        threadTwo.start();

        threadOne.join();
        threadThree.join();
        threadTwo.join();

        System.out.format("lockTrue sum: %f \n", lockTrue.resource.sum);
        System.out.format("lockTwo sum: %f \n", lockTwo.resource.sum);
        System.out.format("lockThree sum: %f \n", lockThree.resource.sum);

        this.sumTest1 = lockTrue.resource.sum + lockTwo.resource.sum + lockThree.resource.sum;
    }
    /**
     * Test2.
     * LockTry
     * @throws InterruptedException - thread interruption
     */
    @Test
    public void whenLockTryThenThreadsSafe() throws InterruptedException {
        WCounter load = new WCounter();
        LockTry lockTry = new LockTry(load);
        LockTry lockTwo = new LockTry(load);
        LockTry lockThree = new LockTry(load);

        Thread threadOne = new Thread(lockTry);
        Thread threadTwo = new Thread(lockThree);
        Thread threadThree = new Thread(lockTwo);
        threadOne.start();
        threadThree.start();
        threadTwo.start();

        threadOne.join();
        threadThree.join();
        threadTwo.join();

        System.out.format("lockTry sum: %f \n", lockTry.resource.sum);
        System.out.format("lockTwo sum: %f \n", lockTwo.resource.sum);
        System.out.format("lockThree sum: %f \n", lockThree.resource.sum);

        this.whenLockTrueThenThreadsSafe();
        assertThat(lockTry.resource.sum + lockTwo.resource.sum
                + lockThree.resource.sum, is(this.sumTest1));
    }
}
