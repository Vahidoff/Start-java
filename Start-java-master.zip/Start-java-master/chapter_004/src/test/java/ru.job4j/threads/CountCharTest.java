package ru.job4j.threads;
import org.junit.Test;

import java.io.IOException;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * Test.
 * ProcessingOrders
 *
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class CountCharTest {
    /**
     * getting file paths.
     */
    private class DepositFile {
        /**
         * small test file.
         * https://yadi.sk/i/YGAXo0v_3N9YsW
         */
        private final String fileSmall = "D:\\Users\\Arbuz333\\Temp Java\\WordsSpacesSmall.txt";
        /**
         * large test file.
         * https://yadi.sk/i/8c4jbHZS3NJYew
         */
        private final String fileLarge = "D:\\Users\\Arbuz333\\Temp Java\\WordsSpaces.txt";
    }
    /**
     * Test 1.
     * small file
     * run.
     * @throws IOException - "file not find".
     * @throws InterruptedException - thread interruption
     */
    @Test
    public void whenReadSmallTextShouldGettingNumberSymbol()
            throws IOException, InterruptedException {
        DepositFile deposit = new DepositFile();
        Time time = new Time(deposit.fileSmall, 2);

        time.run();

        assertThat(time.getSymbol(), is(108));
    }
    /**
     * Test 2.
     * large file
     * run.
     * @throws IOException - "file not find".
     * @throws InterruptedException - thread interruption
     */
    @Test
    public void whenReadLargeTextShouldGettingNumberSymbol()
            throws IOException, InterruptedException {
        DepositFile deposit = new DepositFile();
        Time time = new Time(deposit.fileLarge, 2);

        time.run();
    }
}
