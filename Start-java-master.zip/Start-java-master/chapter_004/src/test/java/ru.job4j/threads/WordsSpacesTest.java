package ru.job4j.threads;
import org.junit.Test;

import java.io.IOException;
/**
 * Test.
 * ProcessingOrders
 *
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class WordsSpacesTest {
    /**
     * getting file paths.
     */
    private class DepositFile {
        /**
         * small test file.
         * https://yadi.sk/i/YGAXo0v_3N9YsW
         */
        private final String fileSmall = "D:\\Users\\Arbuz333\\Temp Java\\WordsSpacesSmall.txt";
        /**
         * large test file.
         * https://yadi.sk/i/R6oAU7BB3N9Ypq
         */
        private final String fileLarge = "D:\\Users\\Arbuz333\\Temp Java\\WordsSpaces.txt";
    }
    /**
     * Test1.
     * file
     * numberSpaces and run.
     * @throws IOException - "file not find".
     * @throws InterruptedException - thread interruption
     */
    @Test
    public void whenReadSmallTextShouldGettingNumberWordsSpaces()
            throws IOException, InterruptedException {

        DepositFile deposit = new DepositFile();
        Spaces spaces = new Spaces(deposit.fileSmall);

        spaces.numberSpaces();
    }
    /**
     * Test2.
     * fileLarge
     * numberSpaces and run.
     * @throws IOException - "file not find".
     * @throws InterruptedException - thread interruption
     */
    @Test
    public void whenReadLargeTextShouldGettingNumberWordsSpaces()
            throws IOException, InterruptedException {

        DepositFile deposit = new DepositFile();
        Spaces spaces = new Spaces(deposit.fileLarge);

        spaces.numberSpaces();
    }
}
