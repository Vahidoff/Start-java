package ru.job4j.threads;
import org.junit.Test;

/**
 * Test.
 * Problems
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class ProblemsTest {
    /**
     * delay time in the main threads.
     */
   private final int delayTime = 12;
    /**
     * Test 1.
     * @throws InterruptedException - thread interruption
     */
    @Test
    public void whenReadSmallTextShouldGettingNumberSymbol()
            throws InterruptedException {
        Problems problems = new Problems(delayTime);
        problems.first();
    }
}
