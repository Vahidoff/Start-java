Web interface for working with the database
in index.jsp file.