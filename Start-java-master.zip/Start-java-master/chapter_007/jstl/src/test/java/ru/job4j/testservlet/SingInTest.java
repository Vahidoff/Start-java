package ru.job4j.testservlet;


import org.junit.Before;
import org.junit.Test;
import ru.job4j.testservlet.control.SingInController;
import ru.job4j.testservlet.roles.RolesDeposit;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Random;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

/**
 * SingInTest.
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class SingInTest {

    private static String login;
    private static String password;
    private static final String ERRORPARAM = "-11";
    private static final String EXPECTEDURL = "/WEB-INF/views/LoginView.jsp";
    private static final String CITY = "City";
    private static final RequestDispatcher DISPATCHER = mock(RequestDispatcher.class);
    private final SingInController sing = new SingInController();

    private static String resultURI = null;

    private final HttpServletRequest request = mock(HttpServletRequest.class);
    private final HttpServletResponse response = mock(HttpServletResponse.class);

    private String temp() {
        Random rnd = new Random(System.currentTimeMillis());
        return String.valueOf(System.currentTimeMillis() + rnd.nextInt()).substring(0, 6);
    }

    @Before
    public void init() {

        try {
            try {
                RolesDeposit.SingletonEnum.INSTANCE.getInstance().addRole("testRole");
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    private void createUser() {
        login = this.temp();
        String email = this.temp() + "@mail.com";
        password = this.temp();
        Deque<String> buffer = new ArrayDeque<>();
        buffer.push(CITY);
        buffer.push(CITY);
        buffer.push(password);
        buffer.push(email);
        buffer.push(login);
        buffer.push(login);
        try {
            try {
                UsersDeposit.SingletonEnum.INSTANCE.getInstance().addUserCS(
                        new Timestamp(1000), buffer, "testRole");
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Test (expected = RuntimeException.class)
    public void whenRightLoginAndPasswordThenServletCallsRedirectMethod()
            throws ServletException, IOException {
        this.createUser();
        HttpServletResponse response = mock(HttpServletResponse.class);
        when(request.getParameter("login")).thenReturn(login);
        when(request.getParameter("password")).thenReturn(password);

        sing.doPost(this.request, this.response);
        doThrow(RuntimeException.class).when(response).sendRedirect(any(String.class));
    }

    @Test
    public void whenWrongLoginAndPasswordThenServletCallsDispatcher() throws ServletException, IOException {

        when(request.getParameter("login")).thenReturn(ERRORPARAM);
        when(request.getParameter("password")).thenReturn(ERRORPARAM);

        doAnswer(invocation -> {
            Object[] arguments = invocation.getArguments();
            resultURI = null;
            if (arguments != null && arguments.length > 0 && arguments[0] != null) {
                resultURI = (String) arguments[0];
            }
            return DISPATCHER;
        }).when(request).getRequestDispatcher(EXPECTEDURL);
        sing.doPost(this.request, this.response);

        assertEquals(EXPECTEDURL, resultURI);
    }
}
