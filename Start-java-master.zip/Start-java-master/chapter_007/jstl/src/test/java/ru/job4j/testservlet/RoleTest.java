package ru.job4j.testservlet;

import org.junit.Test;
import ru.job4j.testservlet.roles.CreateRoleServlet;
import ru.job4j.testservlet.roles.DeleteRoleServlet;
import ru.job4j.testservlet.roles.RolesDeposit;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Random;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * RoleTest.
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class RoleTest {

    private String getSomeRole() {
        Random rnd = new Random(System.currentTimeMillis());
        return String.valueOf(System.currentTimeMillis() + rnd.nextInt()).substring(0, 6);
    }


    /**
     * Test1. Add a role.
     */
    @Test
    public void whenAddNewRoleThenContains() throws ServletException, IOException {
        CreateRoleServlet servlet = new CreateRoleServlet();
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        String role = this.getSomeRole();
        when(request.getParameter("name")).thenReturn(role);

        servlet.doPost(request, response);

        List<String> roles = RolesDeposit.SingletonEnum.INSTANCE.getInstance().getAllRole();
        System.out.println(roles);

        assertThat(roles.contains(role), is(true));
    }

    /**
     * Test2. Deleting a role.
     */
    @Test
    public void whenDeleteRoleThenNotContains() throws ServletException, IOException {
        DeleteRoleServlet servlet = new DeleteRoleServlet();
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);

        Random rnd = new Random(System.currentTimeMillis());
        List<String> roles = RolesDeposit.SingletonEnum.INSTANCE.getInstance().getAllRole();
        int number = rnd.nextInt(roles.size());
        String someRole = roles.get(number);

        when(request.getParameter("name")).thenReturn(someRole);
        servlet.doGet(request, response);
        List<String> result = RolesDeposit.SingletonEnum.INSTANCE.getInstance().getAllRole();


        System.out.println(roles);
        System.out.println(someRole);

        assertThat(roles.contains(result), is(false));
    }
}