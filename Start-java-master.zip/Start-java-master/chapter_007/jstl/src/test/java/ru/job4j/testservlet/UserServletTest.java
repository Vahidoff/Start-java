package ru.job4j.testservlet;

import org.junit.Before;
import org.junit.Test;
import ru.job4j.testservlet.roles.RolesDeposit;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import java.util.Random;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * UserServletTest.
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class UserServletTest {

    private static String login;
    private static String email;
    private static String password;
    private static final String ROLE = "testUser";
    private static final String UPDATE = "up";
    private static final String CITY = "City";
    private static final String LOGIN = "login";

    private String temp() {
        Random rnd = new Random(System.currentTimeMillis());
        return String.valueOf(System.currentTimeMillis() + rnd.nextInt()).substring(2, 8);
    }

    @Before
    public void init() {
        try {
            try {
                RolesDeposit.SingletonEnum.INSTANCE.getInstance().addRole(ROLE);
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        char[] buffer = new char[8];
        for (int i = 0; i < 8; i++) {
            Random r = new Random();
            buffer[i] = (char) (r.nextInt(26) + 'a');
        }
        login = new String(buffer);
        email = this.temp() + "@mail.com";
        password = this.temp() + login;
    }
    /**
     * When CreateServlet adds expected user then this user appears in database.
     */
    @Test
    public void whenServletAddsUserThenUserInDatabase()
            throws ServletException, IOException {

        CreateServlet controller = new CreateServlet();
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);

        when(request.getParameter("login")).thenReturn(login);
        when(request.getParameter("name")).thenReturn(login);
        when(request.getParameter("email")).thenReturn(email);
        when(request.getParameter("date")).
                thenReturn(String.valueOf(new Timestamp(System.currentTimeMillis())));
        when(request.getParameter("password")).thenReturn(password);
        when(request.getParameter("role")).thenReturn(ROLE);
        when(request.getParameter("country")).thenReturn(CITY);
        when(request.getParameter("city")).thenReturn(CITY);
        controller.doPost(request, response);

        UserCS user = null;
        try {
            user = UsersDeposit.SingletonEnum.INSTANCE.getInstance().getUserCS(login);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println(user);

        if (user != null) {
            assertThat(user.getPassword(), is(password));
            assertThat(user.getEmail(), is(email));
        } else {
            System.out.println("User is NULL");
        }
    }

    /**
     * When DeleteServlet deleting user then this user not in database.
     */
    @Test
    public void whenServletDeleteUserThenUserNotInDatabase()
            throws ServletException, IOException {

        DeleteServlet controller = new DeleteServlet();
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        Deque<String> buffer = new ArrayDeque<>();
        buffer.push(CITY);
        buffer.push(CITY);
        buffer.push(password);
        buffer.push(email);
        buffer.push(login);
        buffer.push(login);

        UserCS user = null;
        try {
            UsersDeposit.SingletonEnum.INSTANCE.getInstance().addUserCS(
                    new Timestamp(System.currentTimeMillis()), buffer, ROLE);
            user = UsersDeposit.SingletonEnum.INSTANCE.getInstance().getUserCS(login);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println(user);

        when(request.getParameter("login")).thenReturn(login);
        controller.doGet(request, response);

        List<UserCS> users = null;
        try {
            users = UsersDeposit.SingletonEnum.INSTANCE.getInstance().getAllUserCS();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (users != null) {
            assertThat(users.contains(user), is(false));
        } else {
            System.out.println("The user list is empty");
        }
    }

    /**
     * When UpdateServlet updating user then this update data in database.
     */
    @Test
    public void whenServletUpdateUserThenUserInDatabase()
            throws ServletException, IOException {

        UpdateServlet controller = new UpdateServlet();
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        Deque<String> buffer = new ArrayDeque<>();
        buffer.push(CITY);
        buffer.push(CITY);
        buffer.push(password);
        buffer.push(email);
        buffer.push(login);
        buffer.push(login);

        UserCS user = null;
        try {
            UsersDeposit.SingletonEnum.INSTANCE.getInstance().addUserCS(
                    new Timestamp(System.currentTimeMillis()), buffer, ROLE);
            user = UsersDeposit.SingletonEnum.INSTANCE.getInstance().getUserCS(login);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println(user);

        HttpSession session = mock(HttpSession.class);
        when(request.getSession()).thenReturn(session);
        when(session.getAttribute("role")).thenReturn(true);
        when(request.getParameter("login")).thenReturn(login);
        when(request.getParameter("name")).thenReturn(UPDATE + login);
        when(request.getParameter("email")).thenReturn(UPDATE + email);
        when(request.getParameter("role")).thenReturn(ROLE);
        when(request.getParameter("date")).thenReturn("1888-05-05 05:05:05.111");
        when(request.getParameter("password")).thenReturn(UPDATE + password);
        when(request.getParameter("country")).thenReturn(UPDATE);
        when(request.getParameter("city")).thenReturn(UPDATE);
        controller.doPost(request, response);

        UserCS userUpdate = null;
        try {
            userUpdate = UsersDeposit.SingletonEnum.INSTANCE.
                    getInstance().getUserCS(login);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println(userUpdate);

        if (userUpdate != null) {
            assertThat(userUpdate.getName().contains(UPDATE), is(true));
            assertThat(userUpdate.getPassword().contains(UPDATE), is(true));
        } else {
            System.out.println("The user is NULL");
        }
    }
}
