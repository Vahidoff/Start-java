CREATE TABLE city (
  id         SERIAL PRIMARY KEY,
  name       VARCHAR(255) NOT NULL UNIQUE,
  country_id INTEGER,
  CONSTRAINT fk FOREIGN KEY (country_id) REFERENCES country (id)
);