CREATE TABLE userjs (
  id       SERIAL PRIMARY KEY,
  name     VARCHAR(255) NOT NULL,
  login    VARCHAR(50)  NOT NULL UNIQUE,
  email    VARCHAR(50)  NOT NULL UNIQUE,
  date     TIMESTAMP,
  password VARCHAR(50) NOT NULL,
  role     VARCHAR(50),
  country     VARCHAR(100),
  city     VARCHAR(100)
);