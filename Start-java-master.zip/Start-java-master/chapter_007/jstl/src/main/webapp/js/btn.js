$(document).ready(function() {
    $('.btn-blob').click(function() {
        $(this).toggleClass('blob');
    });
});