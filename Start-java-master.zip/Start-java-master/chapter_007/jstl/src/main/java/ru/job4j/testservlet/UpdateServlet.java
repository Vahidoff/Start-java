package ru.job4j.testservlet;

import ru.job4j.testservlet.roles.RolesDeposit;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayDeque;
import java.util.Deque;

/**
 * UpdateServlet.
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class UpdateServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String login = request.getParameter("login");
        try {
            request.setAttribute("user", UsersDeposit.SingletonEnum.INSTANCE.
                    getInstance().getUserCS(login));
            request.setAttribute("roles", RolesDeposit.SingletonEnum.INSTANCE.
                    getInstance().getAllRole());
            request.setAttribute("countries", AddressDeposit.SingletonEnum.INSTANCE.
                    getInstance().getCountries());
            request.setAttribute("cities", AddressDeposit.SingletonEnum.INSTANCE.
                    getInstance().getCities());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        request.getRequestDispatcher("/WEB-INF/views/update.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        resp.setContentType("text/html");
        HttpSession session = req.getSession(false);
        String login;
        String role;
        if (!(boolean) req.getSession().getAttribute("role")) {
            login = (String) session.getAttribute("login");
            role = ((UserCS) session.getAttribute("user")).getRole();
        } else {
            login = req.getParameter("login");
            role = req.getParameter("role");
        }

        String name = req.getParameter("name");
        String email = req.getParameter("email");
        Timestamp date = Timestamp.valueOf(req.getParameter("date"));
        String password = req.getParameter("password");
        String country = req.getParameter("country");
        String city = req.getParameter("city");
        Deque<String> buffer = new ArrayDeque<>();
        buffer.push(city);
        buffer.push(country);
        buffer.push(role);
        buffer.push(password);
        buffer.push(email);
        buffer.push(name);
        try {
            if (UsersDeposit.SingletonEnum.INSTANCE.
                    getInstance().updateUserCS(date, buffer, login)) {
                resp.sendRedirect(String.format("%s/", req.getContextPath()));
            } else {
                PrintWriter writer = new PrintWriter(resp.getOutputStream());
                writer.append("An invalid Role was identified. Try again!");
                writer.append("<br/><br/><a <form><input type='button' value='Here all users' ");
                writer.append(String.format("onclick=\"window.location.href='%s/'\"/></form></a>",
                        req.getContextPath()));
                writer.flush();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}