package ru.job4j.testservlet.roles;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

public class RolesDeposit {
    private String tableName;
    private String tableNameUsers;
    private String administrator;
    private static final Logger LOG = LoggerFactory.getLogger(RolesDeposit.class);

    private PreparedStatement ps;
    private ResultSet rs;
    private Statement st;
    private static RolesDeposit instance;
    private DataSource data;

    private RolesDeposit() throws IOException, SQLException {
        this.getProperties();
        this.createTable();
    }

    public enum SingletonEnum {
        INSTANCE;

        public RolesDeposit getInstance() {
            if (instance == null) {
                try {
                    instance = new RolesDeposit();
                } catch (SQLException | IOException e) {
                    LOG.error(e.getMessage(), e);
                }
            }
            return instance;
        }
    }

    public boolean addRole(String roleName) throws SQLException, IOException {
        Connection conn = this.connectDb();
        boolean result = false;
        conn.setAutoCommit(false);
        String request = String.format("INSERT INTO %s (name) VALUES(?)", this.tableName);
        this.ps = conn.prepareStatement(request);
        try {
            this.ps.setString(1, roleName);
            result = this.ps.executeUpdate() > 0;
            conn.commit();
        } catch (SQLException e) {
            conn.rollback();
            LOG.error(e.getMessage(), e);
        }
        this.disconnectDb(conn);
        return result;
    }

    public List<String> getAllRole() {
        List<String> allRole = new ArrayList<>();
        Connection conn = this.connectDb();
        try {
            this.st = conn.createStatement();
            this.rs = this.st.executeQuery(String.format("SELECT name FROM %s", this.tableName));
            while (this.rs.next()) {
                allRole.add(rs.getString("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        this.disconnectDb(conn);
        if (allRole.size() == 0) {
            allRole.add(this.administrator);
        }
        return allRole;
    }

    public boolean deleteRole(String name) throws SQLException {
        Connection conn = this.connectDb();
        boolean result = false;
        conn.setAutoCommit(false);
        String request = String.format("DELETE FROM %s WHERE name = '%s'", this.tableName, name);
        this.st = conn.createStatement();
        try {
            result = this.st.executeUpdate(request) > 0;
            conn.commit();
        } catch (SQLException e) {
            conn.rollback();
            LOG.error(" the role has failed", e.getMessage());
        }
        if (result) {
            try {
                conn.setAutoCommit(false);
                request = String.format("UPDATE %s SET role = '' WHERE role = '%s'",
                        this.tableNameUsers, name);
                this.st.executeUpdate(request);
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                LOG.error("deleting the role from users table has failed", e.getMessage());
            }
        }
        this.disconnectDb(conn);
        return result;
    }

    private void getProperties() throws IOException {
        Properties properties = new Properties();
        try (InputStream in = this.getClass().getClassLoader().
                getResourceAsStream("connection.properties")) {
            properties.load(in);
            String url = properties.getProperty("url");
            String user = properties.getProperty("user");
            String password = properties.getProperty("password");
            this.tableName = properties.getProperty("tableRoles");
            this.tableNameUsers = properties.getProperty("tableName");
            this.administrator = properties.getProperty("administrator");
            String driverDB = properties.getProperty("driverDB");

            this.data = new DataSource();
            this.data.setDriverClassName(driverDB);
            this.data.setUsername(user);
            this.data.setPassword(password);
            this.data.setUrl(url);
            this.data.setMaxActive(100);
            this.data.setInitialSize(10);
            this.data.setRemoveAbandonedTimeout(60);
            this.data.setMinEvictableIdleTimeMillis(30000);
            this.data.setMinIdle(10);
            this.data.setJdbcInterceptors(
                    "org.apache.tomcat.jdbc.pool.interceptor.ConnectionState;"
                            + " org.apache.tomcat.jdbc.pool.interceptor.StatementFinalizer");
        } catch (IOException e) {
            LOG.error(e.getMessage(), e);
        }
    }

    private Connection connectDb() {
        Connection conn = null;
        try {
            conn = this.data.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }

    private void createTable() throws SQLException, IOException {
        Connection conn = this.connectDb();

        try {
            this.rs = conn.getMetaData().
                    getTables(null, null, this.tableName, null);
            if (!this.rs.next()) {
                this.st = conn.createStatement();
                try (InputStream in = this.getClass().getClassLoader().
                        getResourceAsStream("createTableRoles.sql")) {
                    Scanner sc = new Scanner(in);
                    String line;
                    StringBuilder command = new StringBuilder();
                    do {
                        line = sc.nextLine();
                        if (!line.endsWith(";")) {
                            command.append(" ").append(line);
                        } else {
                            command.append(line);
                            this.st.execute(command.toString());
                        }
                    } while (sc.hasNext());
                } catch (SQLException | IOException e) {
                    LOG.error(e.getMessage(), e);
                }
                this.addRole(this.administrator);
            }
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
        this.disconnectDb(conn);
    }

    private void disconnectDb(Connection conn) {
        try {
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
        try {
            if (this.ps != null) {
                this.ps.close();
            }
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
        try {
            if (this.st != null) {
                this.st.close();
            }
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
    }
}

