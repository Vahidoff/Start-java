package ru.job4j.testservlet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

/**
 * UsersDeposit.
 * point of entry
 * @version $Id$
 * @since 0.1
 */
public class TestServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String login = (String) request.getSession().getAttribute("login");
        try {
            request.setAttribute("users", UsersDeposit.SingletonEnum.INSTANCE.
                    getInstance().getAllUserCS());
            request.setAttribute("simpleUser", UsersDeposit.SingletonEnum.INSTANCE.
                    getInstance().getUserCS(login));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        request.getRequestDispatcher("/WEB-INF/views/index.jsp").forward(
                request, response);
    }
}
