package ru.job4j.testservlet.roles;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

/**
 * class DeleteRoleServlet - servlet удаления роли пользователя.
 */
public class DeleteRoleServlet extends HttpServlet {

    private static final Logger LOG = LoggerFactory.getLogger(DeleteRoleServlet.class);

    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        resp.setContentType("text/html");
        String role = req.getParameter("name");
        try {
            RolesDeposit.SingletonEnum.INSTANCE.getInstance().deleteRole(role);
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
        resp.sendRedirect(String.format("%s/getAllRole", req.getContextPath()));
    }
}
