package ru.job4j.testservlet.control;
import ru.job4j.testservlet.UsersDeposit;
import ru.job4j.testservlet.UserCS;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * class SingInController - servlet входа в систему.
 */
public class SingInController extends HttpServlet {

    private static final String TEMP = "-1";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/views/LoginView.jsp").forward(req, resp);
    }

    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String login = req.getParameter("login");
        String password = req.getParameter("password");
        UserCS user = UsersDeposit.SingletonEnum.INSTANCE.
                getInstance().isCredential(login, password);
        if (user != null && !user.getPassword().equals(TEMP)) {
            Boolean admin = UsersDeposit.SingletonEnum.INSTANCE.
                    getInstance().administratorCheck(user.getRole());
            HttpSession session = req.getSession();
                session.setAttribute("login", login);
                session.setAttribute("role", admin);
                session.setAttribute("user", user);
            resp.sendRedirect(String.format("%s/", req.getContextPath()));
        } else {
            req.setAttribute("error", "Not a valid combination of login and password");
            doGet(req, resp);
        }

    }
}
