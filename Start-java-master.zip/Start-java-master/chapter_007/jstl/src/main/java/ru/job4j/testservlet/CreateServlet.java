package ru.job4j.testservlet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayDeque;
import java.util.Deque;

/**
 * CreateServlet.
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class CreateServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            req.setAttribute("users", UsersDeposit.SingletonEnum.INSTANCE.
                    getInstance().getAllUserCS());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        req.getRequestDispatcher("/WEB-INF/views/index.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        resp.setContentType("text/html");

        String name = req.getParameter("name");
        String login = req.getParameter("login");
        String email = req.getParameter("email");
        String preDate = req.getParameter("date");
        Timestamp date = new Timestamp(100);
        if (preDate != null) {
             date = Timestamp.valueOf(preDate);
        }
        String password = req.getParameter("password");
        String role = req.getParameter("role");
        String country = req.getParameter("country");
        String city = req.getParameter("city");
        Deque<String> buffer = new ArrayDeque<>();
        buffer.push(city);
        buffer.push(country);
        buffer.push(password);
        buffer.push(email);
        buffer.push(login);
        buffer.push(name);
        try {
            if (UsersDeposit.SingletonEnum.INSTANCE.getInstance().addUserCS(date, buffer, role)) {
                resp.sendRedirect(String.format("%s/", req.getContextPath()));
            } else {
                PrintWriter writer = new PrintWriter(resp.getOutputStream());
                writer.append("Login already in use or an invalid Role was identified. Try again!");
                writer.append("<br/><a <form><input type='button' value='Here all users' ");
                writer.append(String.format("onclick=\"window.location.href='%s/'\"/></form></a>",
                        req.getContextPath()));
                writer.flush();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
