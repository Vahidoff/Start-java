package ru.job4j.testservlet.roles;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

public class CreateRoleServlet extends HttpServlet {

    private static final Logger LOG = LoggerFactory.getLogger(CreateRoleServlet.class);

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/views/AllRoles.jsp").forward(req, resp);
    }

    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        resp.setContentType("text/html");

        String role = req.getParameter("name");

        try {
            if (RolesDeposit.SingletonEnum.INSTANCE.getInstance().addRole(role)) {
                resp.sendRedirect(String.format("%s/getAllRole", req.getContextPath()));
            } else {
                PrintWriter writer = new PrintWriter(resp.getOutputStream());
                writer.append("This role has already been creating!");
                writer.append("<br/><br/><a <form><input type='button' value='Create new role' ");
                writer.append("onclick=\"window.location.href='getAllRole'\"/></form></a>");
                writer.append("<br/><br/><a <form><input type='button' value='Here all users' ");
                writer.append(String.format("onclick=\"window.location.href='%s/'\"/></form></a>",
                        req.getContextPath()));
                writer.flush();
            }
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
    }
}
