package ru.job4j.testservlet;

import net.jcip.annotations.ThreadSafe;
import org.apache.tomcat.jdbc.pool.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.job4j.testservlet.roles.RolesDeposit;

import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.*;

/**
 * UsersDeposit.
 * work in the PostgreSQL.
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
@ThreadSafe
public class UsersDeposit {

    private String tableName;
    private String administrator;
    private String adminPassword;
    private static final Logger LOG = LoggerFactory.getLogger(UsersDeposit.class);
    private static final String TEMP = "-1";

    private PreparedStatement ps;
    private ResultSet rs;
    private Statement st;
    private static UsersDeposit instance;
    private DataSource data;

    private UsersDeposit() throws IOException, SQLException {
        this.getProperties();
        this.createTable();
    }

    public enum SingletonEnum {
        INSTANCE;
        public UsersDeposit getInstance() {
            if (instance == null) {
                try {
                    instance = new UsersDeposit();
                } catch (SQLException | IOException e) {
                    LOG.error(e.getMessage(), e);
                }
            }
            return instance;
        }
    }

    public UserCS isCredential(String login, String password) {
        UserCS find = null;
        try {
            find = SingletonEnum.INSTANCE.getInstance().getUserCS(login);
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
        if (find != null & !find.getPassword().equals(password)) {
            find = null;
        }
        return find;
    }

    public boolean administratorCheck(String role) {
        boolean flag = false;
        if (role != null) {
            flag = role.equals(this.administrator);
        }
        return flag;
    }

    public UserCS getUserCS(String login) throws SQLException {
        Connection conn = this.connectDb();
        UserCS user = null;
        String request = String.format("SELECT name, email, date, password, role, country, "
                + "city FROM %s WHERE login = ?", this.tableName);
        this.ps = conn.prepareStatement(request);
        try {
            this.ps.setString(1, login);
            this.rs = this.ps.executeQuery();
            while (rs.next()) {
                user = new UserCS(rs.getString("name"),
                        login,
                        this.rs.getString("email"),
                        this.rs.getTimestamp("date")
                );
                user.setPassword(this.rs.getString("password"));
                user.setRole(this.rs.getString("role"));
                user.setCountry(this.rs.getString("country"));
                user.setCity(this.rs.getString("city"));
            }
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
        if (user == null) {
            user = new UserCS(TEMP, TEMP, TEMP, null);
            user.setPassword(TEMP);
        }
        this.disconnectDb(conn);
        return user;
    }

    public boolean updateUserCS(Timestamp date, Deque<String> buffer, String login)
            throws SQLException {
        Connection conn = this.connectDb();
        boolean result = false;
            UserCS user = getUserCS(login);
            conn.setAutoCommit(false);
            if (user != null) {
                String request = String.format("UPDATE %s SET name = '%s', email = '%s', "
                                + "date = '%s', password = '%s', role = '%s', country = '%s', "
                                + "city = '%s' WHERE login = '%s'", this.tableName, buffer.pollFirst(),
                        buffer.pollFirst(), date, buffer.pollFirst(), buffer.pollFirst(),
                        buffer.pollFirst(), buffer.pollFirst(), login);
                this.st = conn.createStatement();
                try {
                    result = this.st.executeUpdate(request) > 0;
                    conn.commit();
                } catch (SQLException e) {
                    conn.rollback();
                    LOG.error(e.getMessage());
                }
            }
            this.disconnectDb(conn);
        return result;
    }

    public boolean addUserCS(Timestamp date, Deque<String> buffer, String role)
            throws SQLException, IOException {
        boolean result = false;
        List<String> allRole = RolesDeposit.SingletonEnum.INSTANCE.getInstance().getAllRole();
        if (allRole.contains(role)) {
            Connection conn = this.connectDb();
            conn.setAutoCommit(false);
            String request = String.format("INSERT INTO %s (name, login, email, date, password, "
                    + "role, country, city) VALUES(?,?,?,?,?,?,?,?)", this.tableName);
            this.ps = conn.prepareStatement(request);
            try {
                this.ps.setString(1, buffer.pollFirst());
                this.ps.setString(2, buffer.pollFirst());
                this.ps.setString(3, buffer.pollFirst());
                this.ps.setTimestamp(4, date);
                this.ps.setString(5, buffer.pollFirst());
                this.ps.setString(6, role);
                this.ps.setString(7, buffer.pollFirst());
                this.ps.setString(8, buffer.pollFirst());
                result = this.ps.executeUpdate() > 0;
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                LOG.error(e.getMessage(), e);
            }
            this.disconnectDb(conn);
        }
        return result;
    }

    public boolean deleteUserCS(String login) throws SQLException {
        Connection conn = this.connectDb();
        boolean result = false;
        conn.setAutoCommit(false);
        String request = String.format("DELETE FROM %s WHERE login = '%s'", this.tableName, login);
        this.st = conn.createStatement();
        try {
            result = this.st.executeUpdate(request) > 0;
            conn.commit();
        } catch (SQLException e) {
            conn.rollback();
            LOG.error("Deleting has failed", e.getMessage(), e);
        }
        this.disconnectDb(conn);
        return result;
    }

    public List<String> getAllLogin() {
        List<String> allLogin = new ArrayList<>();
        Connection conn = this.connectDb();
        try {
            this.st = conn.createStatement();
            this.rs = this.st.executeQuery(String.format("SELECT login FROM %s", this.tableName));
            while (this.rs.next()) {
                allLogin.add(rs.getString("login"));
            }
        } catch (SQLException e) {
            LOG.error("Getting all login has failed", e.getMessage(), e);
        }
        this.disconnectDb(conn);
        return allLogin;
    }

    public List<UserCS> getAllUserCS() throws IOException, SQLException {
        List<UserCS> users = new ArrayList<>();
        List<String> login = this.getAllLogin();
        for (String temp : login) {
            try {
                users.add(this.getUserCS(temp));
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return users;
    }

    private void getProperties() throws IOException {
        Properties properties = new Properties();
        try (InputStream in = this.getClass().getClassLoader().
                getResourceAsStream("connection.properties")) {
            properties.load(in);
            String url = properties.getProperty("url");
            String user = properties.getProperty("user");
            String password = properties.getProperty("password");
            this.tableName = properties.getProperty("tableName");
            this.administrator = properties.getProperty("administrator");
            this.adminPassword = properties.getProperty("adminPassword");
            String driverDB = properties.getProperty("driverDB");

            this.data = new DataSource();
            this.data.setDriverClassName(driverDB);
            this.data.setUsername(user);
            this.data.setPassword(password);
            this.data.setUrl(url);
            this.data.setMaxActive(100);
            this.data.setInitialSize(10);
            this.data.setRemoveAbandonedTimeout(60);
            this.data.setMinEvictableIdleTimeMillis(30000);
            this.data.setMinIdle(10);
            this.data.setJdbcInterceptors(
                    "org.apache.tomcat.jdbc.pool.interceptor.ConnectionState;"
                            + " org.apache.tomcat.jdbc.pool.interceptor.StatementFinalizer");
        } catch (IOException e) {
            LOG.error(e.getMessage(), e);
        }
    }

    private Connection connectDb() {
        Connection conn = null;
        try {
            conn = this.data.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }

    private void createTable() throws SQLException, IOException {
        Connection conn = this.connectDb();

        try {
            this.rs = conn.getMetaData().
                    getTables(null, null, this.tableName, null);
            if (!this.rs.next()) {
                this.st = conn.createStatement();
                try (InputStream in = this.getClass().getClassLoader().
                        getResourceAsStream("createTableCS.sql")) {
                    Scanner sc = new Scanner(in);
                    String line;
                    StringBuilder builder = new StringBuilder();
                    while (sc.hasNext()) {
                        line = sc.nextLine();
                        if (!line.endsWith(";")) {
                            builder.append(" ").append(line);
                        } else {
                            builder.append(line);
                            this.st.execute(builder.toString());
                        }
                    }
                } catch (SQLException | IOException e) {
                    LOG.error(e.getMessage());
                }
                Deque<String> buffer = new ArrayDeque<>();
                buffer.push(TEMP);
                buffer.push(TEMP);
                buffer.push(this.adminPassword);
                buffer.push(TEMP);
                buffer.push(this.administrator);
                buffer.push(this.administrator);
                this.addUserCS(null, buffer, this.administrator);
            }
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
        this.disconnectDb(conn);
    }

    private void disconnectDb(Connection conn) {
        try {
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
        try {
            if (this.ps != null) {
                this.ps.close();
            }
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
        try {
            if (this.st != null) {
                this.st.close();
            }
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
    }
}
