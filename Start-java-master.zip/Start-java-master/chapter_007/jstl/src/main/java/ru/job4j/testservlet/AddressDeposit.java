package ru.job4j.testservlet;

import org.apache.tomcat.jdbc.pool.DataSource;

import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

public class AddressDeposit {

    private static AddressDeposit instanceCountry;
    private String tableCountry;
    private static final String COUNTRYSQL = "createTableCountry.sql";
    private static final String CITYSQL = "createTableCity.sql";
    private String tableCity;
    private static final String COUNTRY = "Valkyrie";
    private static final String CITY = "Town";

    private PreparedStatement ps;
    private ResultSet rs;
    private Statement st;
    private DataSource data;

    private AddressDeposit() {
        try {
            this.getProperties();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            this.createTableTwo();
        } catch (SQLException | IOException e) {
            e.printStackTrace();
        }
    }

    public enum SingletonEnum {
        INSTANCE;

        public AddressDeposit getInstance() {
            if (instanceCountry == null) {
                    instanceCountry = new AddressDeposit();
            }
            return instanceCountry;
        }
    }

    /**
     * Get countries.
     */
    public List<String> getCountries() {
        List<String> countries = new ArrayList<>();
        Connection con = this.connectDb();
        try {
            String sql = String.format("select name from %s", this.tableCountry);
            this .ps = con.prepareStatement(sql);
            this.rs = this.ps.executeQuery();
            while (this.rs.next()) {
                countries.add(this.rs.getString("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        this.disconnectDb(con);
        if (countries.isEmpty()) {
            countries.add(COUNTRY);
        }
        return countries;
    }
    /**
     * Get all cities.
     */
    public List<String> getCities() {
        List<String> cities = new ArrayList<>();
        Connection con = this.connectDb();
        try {
            String sql = String.format("select distinct name from %s", this.tableCity);
            this.ps = con.prepareStatement(sql);
            this.rs = this.ps.executeQuery();
            while (this.rs.next()) {
                cities.add(this.rs.getString("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        this.disconnectDb(con);
        if (cities.isEmpty()) {
            cities.add(CITY);
        }
        return cities;
    }

    private void createTableTwo() throws IOException, SQLException {
        this.createTable(this.tableCountry, COUNTRYSQL);
        this.createTable(this.tableCity, CITYSQL);
    }

    private void createTable(String tableName, String fileSQL) throws SQLException, IOException {
        Connection conn = this.connectDb();

        try {
            this.rs = conn.getMetaData().
                    getTables(null, null, tableName, null);
            if (!this.rs.next()) {
                this.st = conn.createStatement();
                try (InputStream in = this.getClass().getClassLoader().
                        getResourceAsStream(fileSQL)) {
                    Scanner sc = new Scanner(in);
                    String line;
                    StringBuilder command = new StringBuilder();
                    while (sc.hasNext()) {
                        line = sc.nextLine();
                        if (!line.endsWith(";")) {
                            command.append(" ").append(line);
                        } else {
                            command.append(line);
                            this.st.execute(command.toString());
                        }
                    }
                } catch (SQLException | IOException e) {
                    e.printStackTrace();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        this.disconnectDb(conn);
    }

    private void getProperties() throws IOException {
        Properties properties = new Properties();
        try (InputStream in = this.getClass().getClassLoader().
                getResourceAsStream("connection.properties")) {
            properties.load(in);
            String url = properties.getProperty("url");
            String user = properties.getProperty("user");
            String password = properties.getProperty("password");
            this.tableCountry = properties.getProperty("tableCountry");
            this.tableCity = properties.getProperty("tableCity");
            String driverDB = properties.getProperty("driverDB");

            this.data = new DataSource();
            this.data.setDriverClassName(driverDB);
            this.data.setUsername(user);
            this.data.setPassword(password);
            this.data.setUrl(url);
            this.data.setMaxActive(100);
            this.data.setInitialSize(10);
            this.data.setRemoveAbandonedTimeout(60);
            this.data.setMinEvictableIdleTimeMillis(30000);
            this.data.setMinIdle(10);
            this.data.setJdbcInterceptors(
                    "org.apache.tomcat.jdbc.pool.interceptor.ConnectionState;"
                            + " org.apache.tomcat.jdbc.pool.interceptor.StatementFinalizer");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Connection connectDb() {
        Connection conn = null;
        try {
            conn = this.data.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }

    private void disconnectDb(Connection conn) {
        try {
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            if (this.ps != null) {
                this.ps.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            if (this.st != null) {
                this.st.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
