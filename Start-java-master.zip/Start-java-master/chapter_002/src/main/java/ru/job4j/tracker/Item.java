package ru.job4j.tracker;
/**
 * Item.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Item {
    /**
     * class variable.
     */
    private String id;
    /**
     * class variable.
     */
    private String name;
    /**
     * class variable.
     */
    private String description;
    /**
     * class variable.
     */
    private long create;
    /**
     * class variable.
     */
    private String comment;
    /**
     * default constructor.
     */
    public Item() {
    }
    /**
     * Item constructor.
     * @param name -
     * @param description -
     * @param create -
     * @param comment -
     */
    public Item(String name, String description, long create, String comment) {
        this.name = name;
        this.description = description;
        this.create = create;
        this.comment = comment;
    }
    /**
     * @return name.
     */
    public String getName() {
        return this.name;
    }

    /**
     * setName.
     * @param name -
     */
    public void setName(String name) {
        this.name = name;
    }
    /**
     * @return description.
     */
    public String getDescription() {
        return this.description;
    }
    /**
     * setDescription.
     * @param description -
     */
    public void setDescription(String description) {
        this.description = description;
    }
    /**
     * @return create.
     */
    public long getCreate() {
        return this.create;
    }
    /**
     * setCreate.
     * @param create -
     */
    public void setCreate(long create) {
        this.create = create;
    }
    /**
     * @return comment.
     */
    public String getComment() {
        return this.comment;
    }
    /**
     * setComment.
     * @param comment -
     */
    public void setComment(String comment) {
        this.comment = comment;
    }
    /**
     * @return id.
     */
    public String getId() {
        return this.id;
    }
    /**
     * setId.
     * @param id -
     */
    public void setId(String id) {
        this.id = id;
    }
    /**
     * toString.
     * @return String item
     */
    @Override
    public String toString() {
        return this.id + " " + this.name + " " + this.description + " " + this.create + " " + this.comment;
    }
}
