package ru.job4j.checker;

/**
 * Figure.
 * abstract
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public abstract class Figure {
    /**
     * position of figure.
     */
    private Cell position;
    /**
     * name of figure.
     */
    private String name;
    /**
     * constructor Figure.
     * @param name - String
     * @param position - Cell
     */
    public Figure(String name, Cell position) {
        this.name = name;
        this.position = position;
    }
    /**
     * getPosition.
     * @return position of Figure
     */
    Cell getPosition() {
        return this.position;
    }
    /**
     * getName.
     * @return name of Figure
     */
    String getName() {
        return this.name;
    }
    /**
     * way.
     * abstract
     * @param dist - the goal for figures
     * @return Cell array of figure's way
     */
    public abstract Cell[] way(Cell dist);
    /**
     * clone - change the parameter position.
     * @param dist - new Cell
     * @return new figure on this dist
     */
    protected abstract Figure clone(Cell dist);
}