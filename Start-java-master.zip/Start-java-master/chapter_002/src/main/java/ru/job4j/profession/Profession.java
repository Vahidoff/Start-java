package ru.job4j.profession;
 /**
 * Profession.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Profession {
     /**
      * class variable.
      */
	private String name;
     /**
      * class variable.
      */
	private float age;
     /**
      * class variable.
      */
	private int experience;
     /**
      * class variable.
      */
	private String education;
     /**
      * class variable.
      */
	private String gender;
     /**
      * class variable.
      */
	private float revenue;
     /**
      * default constructor.
      */
     public Profession() {
     }
     /**
      *
      * @param name -
      * @param age -
      * @param experience -
      * @param education -
      * @param gender -
      * @param revenue -
      */
	public Profession(String name, float age, int experience, String education, String gender, float revenue) {
	    this.name = name;
	    this.age = age;
	    this.experience = experience;
	    this.education = education;
	    this.gender = gender;
	    this.revenue = revenue;
    }
	/**
	 * condition.
     * work's absence or status at work
	 * @param timesofDay - o'clock
	 * @return String
	 */
	public String condition(float timesofDay) {
		if (timesofDay >= 8.3f & timesofDay <= 17.3f) {
            return "working";
        }
		if (timesofDay < 8.3f & timesofDay >= 6f) {
			return "morning affairs";
		}
		if (timesofDay < 6f && timesofDay >= 23f) {
			return "sleeping";
		} else {
			return "evening affairs";
		}

	}
	/**
	 * climate.
	 * @param address - personal address
	 * @return int - outside temperature
	 */
	 public int climate(String address) {
	     if (address.equals("Moscow")) {
             return 20;
         }
	     if (address.equals("Murmansk")) {
             return 10;
         }
	     if (address.equals("Astrakhan")) {
             return 25;
         }
	     if (address.equals("Sochi")) {
             return 35;
         } else {
             return  22;
         }
	 }
     /**
      * hurt.
      * @param bodyTemperature - human's temperature
      * @return boolean
      */
     public boolean hurt(float bodyTemperature) {
         return  (bodyTemperature > 37f);
     }
     /**
      * purchases.
      * @param credit -
      * @param bankdeposit -
      * @return float
      */
     public float purchases(float credit, float bankdeposit) {
         return (this.revenue * 0.3f + credit * 0.5f + bankdeposit * 0.5f);
     }
     /**
      * gettotalinformation.
      * @return String
      */
     public String gettotalinformation() {
             return (this.name + " " + this.age + " years, " + this.experience + " years, " + this.education + " " + this.gender + " " + this.revenue);
     }
	 /**
	  * @return name.
	  */
	 public String getname() {
	     return this.name;
	 }
}