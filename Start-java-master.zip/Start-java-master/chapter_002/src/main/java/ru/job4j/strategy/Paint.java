package ru.job4j.strategy;

/**
 * Paint.
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Paint {
    /**
     * Context figure.
     */
    private Context figure;
    /**
     * figureSquare.
     * @return - String draw square
     */
    public String figureSquare() {
        this.figure = new Context(new Square());
        return figure.draw();
    }
    /**
     * figureTriangle.
     * @return - String draw triangle
     */
    public String figureTriangle() {
        this.figure = new Context(new Triangle());
        return figure.draw();
    }
}
