package ru.job4j.collections;

import java.util.Random;

/**
 * User.
 * id, name, city
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class User implements Comparable<User> {
    /**
     * age the user.
     */
    private int age;
    /**
     * id of User.
     */
    private int id;
    /**
     * name of User.
     */
    private String name;
    /**
     * city of User.
     */
    private String city;
    /**
     * Random RN.
     */
    private static final Random RN = new Random();
    /**
     * constructor User.
     * @param name -
     * @param city -
     * @param age -
     * generateId
     */
    public User(String name, String city, int age) {
        this.id = generateId();
        this.name = name;
        this.city = city;
        this.age = age;
    }
    /**
     * getIg.
     * @return id
     */
    public int getId() {
        return this.id;
    }
    /**
     * getName.
     * @return name
     */
    public String getName() {
        return this.name;
    }
    /**
     * getCity.
     * @return city
     */
    public String getCity() {
        return this.city;
    }
    /**
     * getAge.
     * @return ege
     */
    public int getAge() {
        return age;
    }
    /**
     * compareTO.
     * @param o Object
     * @return compare by age
     */
    @Override
    public int compareTo(User o) {
        if (this.age == o.age) {
            return 0;
        }
        return this.age < o.age ? -1 : 1;
    }
    /**
     * equals.
     * by id User
     * @param o - Object
     * @return boolean result of object comparison
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        User user = (User) o;
        return this.id == user.id;
    }
    /**
     * hashCode.
     * override
     * @return id
     */
    @Override
    public int hashCode() {
        return id;
    }
    /**
     * generateId.
     * @return id for User
     */
    private int generateId() {
        return (int) (System.currentTimeMillis() + RN.nextInt()) / 1000;
    }
}