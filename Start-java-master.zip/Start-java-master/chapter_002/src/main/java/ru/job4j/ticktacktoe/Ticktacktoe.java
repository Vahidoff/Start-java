package ru.job4j.ticktacktoe;
/**
 * Ticktacktoe.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Ticktacktoe {
    /**
     * the size of the field.
     */
    private final int size;
    /**
     * the value of the winning method.
     */
    private boolean flag;
    /**
     * field of Cage.
     */
    private Field field = new Field();
    /**
     * constructor.
     * @param size - of the field
     */
    public Ticktacktoe(int size) {
        this.size = size;
    }
    /**
     * get Field.
     * @return Field
     */
    public Field getField() {
        return this.field;
    }
    /**
     * win - it is won if three cells are arranged a row.
     * @param x - horizontal
     * @param y - vertical
     * @return - boolean result
     */

    public boolean win(int x, int y) {
        field.show(this.size);

        int buffer = x - 2;
        flag = line(x, y, buffer);
        if (!flag) {
            buffer = y - 2;
            flag = lineVertical(x, y, buffer);
        }
        if (!flag) {
            flag = diagonalLeft(x, y);
        }
        if (!flag) {
            flag = diagonalRight(x, y);
        }
        return flag;
    }
    /**
     * if the row is horizontal.
     * @param x -
     * @param y -
     * @param buffer - horizontal
     * @return boolean result
     */
    private boolean line(int x, int y, int buffer) {
        int index = 0;
        for (; buffer < x + 3; buffer++) {
            if (buffer < 0 | buffer > this.size - 1) {
                continue;
            }
            if (this.field.getCages(buffer, y).getTick() == this.field.getCages(x, y).getTick()) {
                index++;
            } else {
                index = 0;
            }
            if (index == 3) {
                flag = true;
                break;
            }
        }
        return flag;
    }
    /**
     * if the row is vertical.
     * @param x -
     * @param y -
     * @param buffer - vertical
     * @return boolean result
     */
    private boolean lineVertical(int x, int y, int buffer) {
        int index = 0;
        for (; buffer < y + 3; buffer++) {
            if (buffer < 0 | buffer >= this.size) {
                continue;
            }
            if (this.field.getCages(x, buffer).getTick() == this.field.getCages(x, y).getTick()) {
                index++;
            } else {
                index = 0;
            }
            if (index == 3) {
                flag = true;
                break;
            }
        }
        return flag;
    }
    /**
     * if the row from down left.
     * @param x -
     * @param y -
     * @return boolean result
     */
    private boolean diagonalLeft(int x, int y) {
        int index = 0;
        int a = x - 2;
        int b = y - 2;
        for (; a < x + 3; a++, b++) {
            if ((a < 0 | a >= this.size) | (b < 0 | b >= this.size)) {
                continue;
            }
            if (this.field.getCages(a, b).getTick() == this.field.getCages(x, y).getTick()) {
                index++;
            } else {
                index = 0;
            }
            if (index == 3) {
                flag = true;
                break;
            }
        }
        return flag;
    }
    /**
     * if the row from down right.
     * @param x -
     * @param y -
     * @return boolean result
     */
    private boolean diagonalRight(int x, int y) {
        int index = 0;
        int a = x + 2;
        int b = y - 2;
        for (; a < x + 3; a--, b++) {
            if ((a < 0 | a >= this.size) | (b < 0 | b >= this.size)) {
                continue;
            }
            if (this.field.getCages(a, b).getTick() == this.field.getCages(x, y).getTick()) {
                index++;
            } else {
                index = 0;
            }
            if (index == 3) {
                flag = true;
                break;
            }
        }
        return flag;
    }
}
