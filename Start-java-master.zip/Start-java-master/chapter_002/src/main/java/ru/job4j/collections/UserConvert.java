package ru.job4j.collections;

import java.util.HashMap;
import java.util.List;

/**
 * UserConvert.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class UserConvert {
    /**
     * process.
     * convert a list to HashMap.
     * @param list -
     * @return HashMap with key User.id
     */
    public HashMap<Integer, User> process(List<User> list) {
        HashMap<Integer, User> hmIU = new HashMap<>();

        for (User value : list) {
            hmIU.put(value.getId(), value);
        }
        return hmIU;
    }
}
