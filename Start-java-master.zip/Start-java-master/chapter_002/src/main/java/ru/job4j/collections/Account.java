package ru.job4j.collections;

/**
 * Account.
 * bank profile
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Account {
    /**
     * the amount of money on the account.
     */
    private double value;
    /**
     * account details.
     */
    private String requisites;
    /**
     * constructor.
     * @param value      - amount of money
     * @param requisites - unique bank account
     */
    Account(int value, String requisites) {
        this.value = value;
        this.requisites = requisites;
    }
    /**
     * getValue.
     * @return - value
     */
    public double getValue() {
        return value;
    }
    /**
     * setValue.
     * @param value -
     */
    public void setValue(double value) {
        this.value = value;
    }
    /**
     * getRequisites.
     * @return - requisites
     */
    public String getRequisites() {
        return requisites;
    }
    /**
     * Override equals.
     * @param o - object
     * @return boolean
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Account)) {
            return false;
        }
        Account account = (Account) o;
        return requisites.equals(account.requisites);
    }
    /**
     * Override hashCode.
     *
     * @return requisites.hashCode
     */
    @Override
    public int hashCode() {
        return requisites.hashCode();
    }
}
