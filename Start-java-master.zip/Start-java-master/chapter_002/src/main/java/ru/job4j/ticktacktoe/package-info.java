/**
 * Package for tick tack toe task.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
package ru.job4j.ticktacktoe;