package ru.job4j.tracker;

import java.sql.SQLException;
import java.util.ArrayList;

/**
 * EditItem.
 * inner class
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
class EditItem extends BaseAction {
    /**
     * constructor.
     *
     * @param actionName -
     * @param key        -
     */
    EditItem(String actionName, int key) {
        super(actionName, key);
    }
    /**
     * execute.
     * @param input   Input
     * @param tracker Tracker
     */
    public void execute(Input input, Tracker tracker) {
        System.out.print("Enter the ID of item;  ");
        Item item = tracker.findById(input.ask());
        System.out.print("Enter the name of item:  ");
        item.setName(input.ask());
        System.out.print("Enter the description of item;  ");
        item.setDescription(input.ask());
        System.out.print("Enter the create of item;  ");
        item.setCreate(Long.valueOf(input.ask()));
        System.out.print("Enter the comment of item;  ");
        item.setComment(input.ask());
        tracker.update(item);
    }
}
/**
 * FindByName.
 * inner class
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
class FindByName extends BaseAction {
    /**
     * constructor.
     * @param actionName -
     * @param key        -
     */
    FindByName(String actionName, int key) {
        super(actionName, key);
    }
    /**
     * execute.
     * all items of given name.
     * @param input   Input
     * @param tracker Tracker
     */
    public void execute(Input input, Tracker tracker) {
        System.out.print("Enter the name of item:  ");
        for (Item results : tracker.findByName(input.ask())) {
            if (results != null) {
                System.out.println(results.toString());
                System.out.println();
            }
        }
    }
}

/**
 * MenuTracker.
 * outer class
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class MenuTracker {
    /**
     * class variable input.
     */
    private Input input;
    /**
     * class variable tracker.
     */
    private Tracker tracker;
    /**
     * the class variable actions of array.
     */
    private ArrayList<BaseAction> actions = new ArrayList<>(7);
    /**
     * getActions.
     * @return actions
     */
    public ArrayList<BaseAction> getActions() {
        return this.actions;
    }
    /**
     * menu's choice.
     */
    private static final int ZERO = 0, ONE = 1, TWO = 2, THREE = 3, FOUR = 4, FIVE = 5, SIX = 6;
    /**
     * class constructor.
     * @param input   Input
     * @param tracker Tracker
     */
    public MenuTracker(Input input, Tracker tracker) {
        this.input = input;
        this.tracker = tracker;
    }
    /**
     * fillActions.
     * execution of menu number
     */
    public void fillActions() {
        this.actions.add(ZERO, this.new AddItem("Adding a new item", ZERO));
        this.actions.add(ONE, new MenuTracker.ShowItems("Show all items", ONE));
        this.actions.add(TWO, new EditItem("The item edit", TWO));
        this.actions.add(THREE, this.new DeleteItem("Delete item", THREE));
        this.actions.add(FOUR, new MenuTracker.FindById("Find item by Id", FOUR));
        this.actions.add(FIVE, new FindByName("All items with given name", FIVE));
        this.actions.add(SIX, this.new ExitProgram("Exit Program", SIX));
    }
    /**
     * select.
     * @param key - select the key
     */
    public void select(int key) throws SQLException {
        this.actions.get(key).execute(this.input, this.tracker);
    }
    /**
     * show.
     * show the menu
     */
    public void show() {
        for (UserAction action : this.actions) {
            System.out.println(action.info());
        }
    }
    /**
     * AddItem.
     * nested class
     * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
     * @version $Id$
     * @since 0.1
     */
    public class AddItem extends BaseAction {
        /**
         * constructor.
         * @param actionName -
         * @param key        -
         */
        AddItem(String actionName, int key) {
            super(actionName, key);
        }
        /**
         * Item variable.
         */
        private String name, description, comment;
        /**
         * Item variable.
         */
        private long create;
        /**
         * execute.
         * @param input   Input
         * @param tracker Tracker
         */
        public void execute(Input input, Tracker tracker) throws SQLException {
            System.out.print("1. Enter the name of item:  ");
            System.out.println();
            name = input.ask();
            System.out.print("2. Enter the description of item;  ");
            System.out.println();
            description = input.ask();
            System.out.print("3. Enter the create of item;  ");
            System.out.println();
            create = Long.valueOf(input.ask());
            System.out.print("4. Enter the comment of item;  ");
            System.out.println();
            comment = input.ask();
            System.out.println();
            Item item = new Item(name, description, create, comment);
            tracker.add(item);
        }
    }
    /**
     * ShowItems.
     * nested static class
     * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
     * @version $Id$
     * @since 0.1
     */
    public static class ShowItems extends BaseAction {
        /**
         * constructor.
         * @param actionName -
         * @param key        -
         */
        ShowItems(String actionName, int key) {
            super(actionName, key);
        }
        /**
         * execute.
         * @param input   Input
         * @param tracker Tracker
         */
        public void execute(Input input, Tracker tracker) {
            for (Item results : tracker.findAll()) {
                if (results != null) {
                    System.out.println(results.toString());
                    System.out.println();
                }
            }
        }
    }
    /**
     * DeleteItem.
     * nested class
     * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
     * @version $Id$
     * @since 0.1
     */
    public class DeleteItem extends BaseAction {
        /**
         * constructor.
         * @param actionName -
         * @param key        -
         */
        DeleteItem(String actionName, int key) {
            super(actionName, key);
        }
        /**
         * execute.
         * @param input   Input
         * @param tracker Tracker
         */
        public void execute(Input input, Tracker tracker) {
            System.out.print("Enter the ID of item;  ");
            Item item = tracker.findById(input.ask());
            tracker.delete(item);
        }
    }
    /**
     * FindById.
     * nested static class
     * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
     * @version $Id$
     * @since 0.1
     */
    public static class FindById extends BaseAction {
        /**
         * constructor.
         * @param actionName -
         * @param key        -
         */
        FindById(String actionName, int key) {
            super(actionName, key);
        }
        /**
         * execute.
         * @param input   Input
         * @param tracker Tracker
         */
        public void execute(Input input, Tracker tracker) {
            System.out.print("Enter the ID of item;  ");
            Item item = tracker.findById(input.ask());
            System.out.println(item.toString());
            System.out.println();
        }
    }
    /**
     * ExitProgram.
     * nested class
     * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
     * @version $Id$
     * @since 0.1
     */
    public class ExitProgram extends BaseAction {
        /**
         * constructor.
         * @param actionName -
         * @param key        -
         */
        ExitProgram(String actionName, int key) {
            super(actionName, key);
        }
        /**
         * execute.
         * @param input   Input
         * @param tracker Tracker
         */
        public void execute(Input input, Tracker tracker) {
        }
    }
}
