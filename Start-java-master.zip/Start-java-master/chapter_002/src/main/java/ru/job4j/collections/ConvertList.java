package ru.job4j.collections;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

/**
 * ConvertList.
 * converting a two-dimensional array to ArrayList and vice versa
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class ConvertList {
    /**
     * toList.
     * filling a list with a two-dimensional array
     * @param array - two-dimensional
     * @return list
     */
    public ArrayList<Integer> toList(int[][] array) {
        ArrayList<Integer> ali = new ArrayList<>();

        for (int[] value : array) {
            for (int term : value) {
                ali.add(term);
            }
        }
        return ali;
    }
    /**
     * toArray.
     * division a list into a dimensional array
     * with a given number of rows
     * @param list -
     * @param rows -
     * @return two-dimensional array
     */
    public int[][] toArray(ArrayList<Integer> list, int rows) {
        int[][] result = new int[rows][rows];
        int i = 0;
        int j = 0;
        int index = 0;

        for (int value : list) {
            result [i][j++] = value;
            index++;
            if (j == rows) {
                j = 0;
                i++;
            }
        }
        if (index < list.size()) {
            for (; index < list.size(); index++) {
                result [i][j++] = 0;
                if (j == rows) {
                    j = 0;
                    i++;
                }

            }
        }
        return  result;
    }
    /**
     * convert.
     * getting a list from the array list
     * @param list of int arrays
     * @return - common list
     */
    public HashSet<Integer> convert(ArrayList<int[]> list) {
        HashSet<Integer> hsi = new HashSet<>();

        Iterator<int[]> itr = list.iterator();
        while (itr.hasNext()) {
            for (int value : itr.next()) {
                hsi.add(value);
            }
        }
        return hsi;
    }
}
