package ru.job4j.subdivisions;

import java.util.Comparator;
import java.util.List;

/**
 * SortedUnits.
 * sorting out business units
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class SortedUnits {
    /**
     * sortingUnits.
     * @param list - an arbitrary list of units
     * @return sorted in the direct order the list of divisions
     */
    List<String> sortingUnits(List<String> list) {
        list.sort(new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                int result = 0;
                int index = o1.length() <= o2.length() ? o1.length() : o2.length();
                for (int j = 1; j < index; j++) {
                    result = Character.compare(o1.charAt(j), (o2.charAt(j)));
                    if (result > 0) {
                        break;
                    }
                }
                if (result == 0) {
                    result = o1.compareTo(o2);
                }
                return result;
            }
        });
        return list;
    }
    /**
     * sortingUnitsRevers.
     * @param list - an arbitrary list of units
     * @return sorted this list in the reverse order
     */
    List<String> sortingUnitsRevers(List<String> list) {
        list.sort(new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                int result = 0;
                int index = o1.length() <= o2.length() ? o1.length() : o2.length();
                for (int j = 1; j < index; j++) {
                    result = -1 * Character.compare(o1.charAt(j), (o2.charAt(j)));
                    if (result != 0) {
                        break;
                    } else {
                        result = o1.length() < o2.length() ? -1 : 1;
                        break;
                    }
                }
                return result;
            }
        });
        return list;
    }
}
