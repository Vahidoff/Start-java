package ru.job4j.tracker;

import java.util.Scanner;
/**
 * ConsoleInput.
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class ConsoleInput implements Input {
    /**
     * scanner.
     */
    private Scanner scanner = new Scanner(System.in);
    /**
     * ask.
     * @return - answer
     */
    public String ask() {
        return scanner.next();
    }
    /**
     * ask.
     * @param range - the range of menu
     * @return key or exception
     */
    public int ask(int[] range) {
        int key = Integer.valueOf(this.ask());
        boolean exist = false;
        for (int value : range) {
            if (value == key) {
                exist = true;
                break;
            }
        }
        if (exist) {
            return key;
        } else {
            throw new MenuOutException("Out of menu range");
        }
    }
}