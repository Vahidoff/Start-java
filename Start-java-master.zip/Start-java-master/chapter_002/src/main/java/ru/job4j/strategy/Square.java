package ru.job4j.strategy;

/**
 * Square.
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Square implements Shape {
    /**
     * h - height.
     */
    private static final int H = 3;
    /**
     * pic.
     * @return String quadrate.
     */
    @Override
    public String pic() {
        StringBuilder quadrate = new StringBuilder();
        for (int index = 0; index < H + 2; index++) {
            for (int beam = 0; beam < H + 2; beam++) {
                if ((index == 0 | index == H + 1) | (beam == 0 | beam == H + 1)) {
                    quadrate.append('o');
                } else {
                    quadrate.append(' ');
                }
            }
            if (index == H + 1) {
                break;
            }
            quadrate.append(System.getProperty("line.separator"));
        }
        return quadrate.toString();
    }
}
