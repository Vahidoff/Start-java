package ru.job4j.profession;

/**
 * Doctor.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Doctor extends Profession {
    /**
     * special parameters.
     */
    private String specialization;
    /**
     * common parameters.
     * @param name           -
     * @param age            -
     * @param experience     -
     * @param education      -
     * @param gender         -
     * @param revenue        -
     * @param specialization -
     */
    public Doctor(String name, float age, int experience, String education, String gender, float revenue, String specialization) {
        super(name, age, experience, education, gender, revenue);
        this.specialization = specialization;
    }
    /**
     * gettotalinformation.
     * @return String
     */
    public String gettotalinformation() {
        String information = super.gettotalinformation();
        return (information + " " + this.specialization);
    }
    /**
     * admission.
     * @param patient -
     * @return String
     */
    public String admission(People patient) {
        return ("Dr. " + getname() + " is talking " + patient.getname());
    }
    /**
     * medical analysis.
     * @param patient -
     * @param result -
     * @return String
     */
    public String medicalanalysis(People patient, double result) {
        String diagnosis;
        if (result < 5.62d) {
            diagnosis = "wholesome";
        } else {
            diagnosis = "sick";
        }
        return ("Patient " + patient.getname() + " is " + diagnosis);
    }
}