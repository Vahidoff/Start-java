package ru.job4j.tracker;

/**
 * StubInput.
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class StubInput implements Input {
    /**
     * answers.
     */
    private String[] answers;
    /**
     * position.
     */
    private int position = 0;
    /**
     * constructor.
     * @param answers -
     */
    public StubInput(String[] answers) {
        this.answers = answers;
    }
    /**
     * ask.
     * @return - answers
     */
    public String  ask() {
         return answers[position++];
    }
    /**
     * ask.
     * @param range - the range of menu
     * @return - int answer
     */
    public int ask(int[] range) {
        return Integer.valueOf(answers[position++]);
    }
}
