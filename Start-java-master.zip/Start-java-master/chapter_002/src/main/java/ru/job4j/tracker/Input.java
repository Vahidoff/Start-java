package ru.job4j.tracker;

/**
 * Input.
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public interface Input {
    /**
     * ask.
     * @return -
     */
    String ask();
    /**
     * ask.
     * @param range - the range of menu
     * @return - int and exception
     */
    int ask(int[] range);
}
