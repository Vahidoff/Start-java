package ru.job4j.checker;

/**
 * ImpossibleMoveException.
 * extends RuntimeException
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class ImpossibleMoveException extends RuntimeException {
    /**
     * ImpossibleMoveException.
     * @param msq -
     */
    public ImpossibleMoveException(String msq) {
        super(msq);
    }
}
