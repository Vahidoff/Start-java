package ru.job4j.collections;

import java.util.Comparator;
import java.util.TreeSet;
import java.util.Set;
import java.util.List;

/**
 * SortUser.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
class SortUser {
    /**
     * sort.
     * sorting using "compareTo" method from User
     * @param list - List<User>
     * @return TreeSet
     */
    Set<User> sort(List<User> list) {
        return new TreeSet<>(list);
    }
    /**
     * sortNameLength.
     * sort by name length
     * @param list - User
     * @return sorted list
     */
    List<User> sortNameLength(List<User> list) {
         list.sort(new Comparator<User>() {
            @Override
            public int compare(User o1, User o2) {
                return Integer.compare(o1.getName().length(), o2.getName().length());
                }
         });
        return list;
    }
    /**
     * class CompNameAge.
     * comparator for sorting by name then by age
     */
    class CompNameAge implements Comparator<User> {
        @Override
        public int compare(User o1, User o2) {
            int k;
            k = o1.getName().compareTo(o2.getCity());
            if (k == 0) {
                k = Integer.compare(o1.getAge(), o2.getAge());
            }
            return k;
        }
    }
    /**
     * sortByAllFields.
     * sorting the list by name then by age
     * @param list -
     * @return - sorted list
     */
    TreeSet<User> sortByAllFields(List<User> list) {
        TreeSet<User> tsU = new TreeSet<>(new CompNameAge());
        tsU.addAll(list);
        return tsU;
    }
}
