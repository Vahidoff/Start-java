package ru.job4j.strategy;

/**
 * Shape.
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public interface Shape {
    /**
     * pic.
     * @return picture
     */
    String pic();
}
