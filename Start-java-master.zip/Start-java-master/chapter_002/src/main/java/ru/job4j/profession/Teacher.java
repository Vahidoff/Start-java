package ru.job4j.profession;

/**
 * Teacher.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Teacher extends Profession {
    /**
     * special parameters.
     */
    private String specialization;
    /**
     * common parameters.
     *
     * @param name           -
     * @param age            -
     * @param experience     -
     * @param education      -
     * @param gender         -
     * @param revenue        -
     * @param specialization -
     */
    public Teacher(String name, float age, int experience, String education, String gender, float revenue, String specialization) {
        super(name, age, experience, education, gender, revenue);
        this.specialization = specialization;
    }
    /**
     * gettotalinformation.
     * @return String
     */
    public String gettotalinformation() {
        String information = super.gettotalinformation();
        return (information + " " + this.specialization);
    }
    /**
     * teaching.
     * @param children -
     * @return String
     */
    public String teaching(People children) {
        return ("Teacher " + getname() + " teaches pupil " + children.getname());
    }
}