package ru.job4j.collections;


import java.util.Collection;
import java.util.ArrayList;
import java.util.TreeSet;
import java.util.LinkedList;
import java.util.Random;

/**
 * Productivity.
 * the productivity of the different lists
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Productivity {
    /**
     * Random RN.
     */
    private static final Random RN = new Random();
    /**
     * buffer array of strings.
     */
    private String[] buffer = new String[500];
    /**
     * deposit of array of strings.
     * @param amount - the size of array of strings
     * @return buffer array
     */
    private String[] deposit(int amount) {
        for (int i = 0; i < amount; i++) {
            buffer[i] = String.valueOf(System.currentTimeMillis() + RN.nextInt()).substring(0, 5);
        }
        return this.buffer;
    }
    /**
     * addition to a list.
     * @param a1 - list
     * @param amount - size of list
     * @return - time of addition
     */
    private long addition(Collection<String> a1, int amount) {
        long start, end;
        start = System.nanoTime();
        for (int i = 0; i < amount; i++) {
            a1.add(buffer[i]);
        }
        end = System.nanoTime();
        return end - start;
    }
    /**
     * deleting from the list.
     * @param a1 - list
     * @param amount - size of list
     * @return - time of deleting
     */
    private long deleting(Collection<String> a1, int amount) {
        long start, end;
        start = System.nanoTime();
        for (int i = 0; i < amount / 2; i++) {
            a1.remove(buffer[i]);
        }
        end = System.nanoTime();
        return end - start;
    }

    /**
     * main.
     * @param args -
     */
    public static void main(String[] args) {
        Productivity time = new Productivity();
        time.deposit(100);
        long result;
        LinkedList<String> lkl = new LinkedList<>();
        ArrayList<String> al = new ArrayList<>();
        TreeSet<String> ts = new TreeSet<>();

        result = time.addition(lkl, 100);
        System.out.format("  addition method execution time for LinkedList %d", result);
        result = time.deleting(lkl, 100);
        System.out.format("  deleting method execution time for LinkedList %d", result);
        System.out.println();

        result = time.addition(al, 100);
        System.out.format("  addition method execution time for ArrayList %d", result);
        result = time.deleting(al, 100);
        System.out.format("  deleting method execution time for ArrayList %d", result);
        System.out.println();

        result = time.addition(ts, 100);
        System.out.format("  addition method execution time for TreeSet %d", result);
        result = time.deleting(ts, 100);
        System.out.format("  deleting method execution time for TreeSet %d", result);
        System.out.println();
    }
}
