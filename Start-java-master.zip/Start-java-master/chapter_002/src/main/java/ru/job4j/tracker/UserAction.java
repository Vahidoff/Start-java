package ru.job4j.tracker;

import java.sql.SQLException;

/**
 * UserAction.
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public interface UserAction {
    /**
     * key.
     * @return key of the operation
     */
     int key();
    /**
     * execute.
     * @param input Input
     * @param tracker Tracker
     */
     void execute(Input input, Tracker tracker) throws SQLException;
    /**
     * onfo.
     * @return String of the operation
     */
     String info();
}
