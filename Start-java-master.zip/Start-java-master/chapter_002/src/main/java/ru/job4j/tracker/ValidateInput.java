package ru.job4j.tracker;

/**
 * ValidateInput.
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class ValidateInput extends ConsoleInput {
    /**
     * ask.
     * @param range - the range of menu
     * @return key or exception
     */
    public int ask(int[] range) {
        boolean invalid = true;
        int value = -1;
        do {
            try {
                value = super.ask(range);
                invalid = false;
            } catch (MenuOutException moe) {
                System.out.println("please select key from menu.");
            } catch (NumberFormatException nfe) {
                System.out.println("Please enter validate date again.");
            }
        } while (invalid);
        return value;
    }
}
