package ru.job4j.checker;

/**
 * Board.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Board {
    /**
     * array Figure.
     */
    private Figure[] figures = new Figure[32];
    /**
     * boolean flag for move.
     */
    private boolean flag = true;
    /**
     * index of figures array for move.
     */
    private int index = 0;
    /**
     * setFigures.
     * @param figure -
     * @param i - number of figure's array
     */
    public void setFigures(Figure figure, int i) {
        figures[i] = figure;
    }
    /**
     * getFigures.
     * @param i - number of figure's array
     * @return figures[i]
     */
    public Figure getFigures(int i) {
        return figures[i];
    }
    /**
     * findByCell.
     * @param cell - Cell
     * @return the figure that stands on this cell
     */
    public Figure findByCell(Cell cell) {
        Figure result = new Elephant("notFigure",  new Cell(50, 'n'));
                for (Figure value : figures) {
                    if (value == null) {
                        this.index++;
                        continue;
                    }
                    if (cell.getContour() == value.getPosition().getContour() && cell.getHeight() == value.getPosition().getHeight()) {
                        result = value;
                        break;
                    }
        }
        return result;
    }
    /**
     * move.
     * @param source - position of figures
     * @param dist - the goal for figures
     * @return - flag
     */
    public boolean move(Cell source, Cell dist) {
        Figure buffer = findByCell(source);
        System.out.println(buffer.getPosition().getHeight());
        if (buffer.getPosition().getHeight() == 50) {
            this.flag = false;
            throw new FigureNotFoundException("Figure not found ");
        }
        if (this.flag) {
            Cell[] route = buffer.way(dist);
            for (Figure value : figures) {
                for (Cell cell: route) {
                    if (value != null) {
                        if (value.getPosition().getHeight() == cell.getHeight() && value.getPosition().getContour() == cell.getContour()) {
                            this.flag = false;
                            throw new OccupiedWayException("The way is occupied another figure");
                        }
                    }
                }
            }
        }
        if (this.flag) {
            figures[this.index] = buffer.clone(dist);
        }
        return this.flag;
    }
}