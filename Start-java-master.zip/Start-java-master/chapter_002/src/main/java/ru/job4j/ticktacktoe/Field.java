package ru.job4j.ticktacktoe;
/**
 * Field.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Field {
    /**
     * array of cells.
     */
    private Cage[][] cages = new Cage[20][20];
    /**
     * getCages.
     * @param x - horizontal
     * @param y - vertical
     * @return cages array element
     */
    public Cage getCages(int x, int y) {
        return this.cages[x][y];
    }
    /**
     * show field.
      * @param size - field size
     */
    protected void show(int size) {
        for (int vertical = 0; vertical < size; vertical++) {
            for (int horizontal = 0; horizontal < size; horizontal++) {
                System.out.print(cages[horizontal][vertical]);
            }
            System.out.println();
        }
        System.out.println();
    }
    /**
     * add cell.
     * @param cage - cell
     * @param x - horizontal
     * @param y - vertical
     */
    protected void add(Cage cage, int x, int y) {
        this.cages[x][y] = cage;
    }
}
