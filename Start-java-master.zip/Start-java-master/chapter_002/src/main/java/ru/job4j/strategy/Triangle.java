package ru.job4j.strategy;

/**
 * Triangle.
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Triangle implements Shape {
    /**
     * h - height.
     */
    private static final int H = 4;
    /**
     * pic.
     * @return String triangle.
     */
    @Override
    public String pic() {
        StringBuilder delta = new StringBuilder();
        for (int index = 1; index <= H; index++) {
            for (int beam = 1; beam <= (2 * H - 1); beam++) {
                if ((H - index) < beam & beam < (H + index)) {
                    delta.append('x');
                } else {
                    delta.append(' ');
                }
            }
            if (H == index) {
                break;
            }
            delta.append(System.getProperty("line.separator"));
        }
        return delta.toString();
    }
}
