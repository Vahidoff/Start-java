package ru.job4j.strategy;

/**
 * Context.
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Context {
    /**
     * Shape shape.
     */
    private Shape shape;
    /**
     * constructor.
     * @param shape -
     */
    public Context(Shape shape) {
        this.shape = shape;
    }
    /**
     * draw.
     * @return String figure
     */
    public String draw() {
        return shape.pic();
    }
}
