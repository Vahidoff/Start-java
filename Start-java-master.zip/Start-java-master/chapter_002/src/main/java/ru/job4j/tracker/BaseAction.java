package ru.job4j.tracker;

import java.sql.SQLException;

/**
 * BaseAction.
 * abstract implements UserAction.
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
abstract class BaseAction implements UserAction {
    /**
     * actionName - class field.
     */
    private String actionName;
    /**
     * key class field.
     */
    private int key;
    /**
     * constructor.
     * @param actionName -
     * @param key -
     */
    BaseAction(String actionName, int key) {
        this.actionName = actionName;
        this.key = key;
    }
    /**
     * key.
     * @return key
     */
    public int key() {
        return this.key;
    }
    /**
     * execute abstract.
     * @param input Input
     * @param tracker Tracker
     */
    public abstract void execute(Input input, Tracker tracker) throws SQLException;
    /**
     * info.
     * @return String of the operation
     */
    public String info() {
        return String.format("%s. %s", this.key, this.actionName);
    }

}
