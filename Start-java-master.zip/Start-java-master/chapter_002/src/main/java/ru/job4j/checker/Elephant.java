package ru.job4j.checker;

/**
 * Elephant.
 * extends Figure
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Elephant extends Figure {
    /**
     * constructor Elephant.
     * @param name String
     * @param position Cell
     */
    public Elephant(String name, Cell position) {
        super(name, position);
    }
    /**
     * boolean flag for way.
     */
    private boolean flag = false;
    /**
     * int index for way.
     */
    private int index;
    /**
     * way.
     * @param dist - the goal for figures
     * @return Cell array of figure's way
     * first, we test the way from the down left to the top right
     * second, we test the way from the down right to the top left
     * in the third, we clear array from null elements
     */
    public Cell[] way(Cell dist) {
        Cell[][] line;
        Cell[] result;
        if ((dist.getHeight() < getPosition().getHeight() && dist.getContour() < getPosition().getContour()) | ((dist.getHeight() > getPosition().getHeight() && dist.getContour() > getPosition().getContour()))) {
            line = bufferDownLeft(dist);
        } else {
            line = bufferDownRight(dist);
        }
        if (this.flag) {
            result = ridCellArrayZero(line, index);
        } else {
            throw new ImpossibleMoveException("THe figure can't go to this goal");
        }
        return result;
    }
    /**
     * clone.
     * @param dist -
     * @return new elephant on this dist
     */
    protected Figure clone(Cell dist) {
        return new Elephant(getName(), dist);
    }
    /**
     * bufferDownLeft.
     * @param dist -
     * @return - Two-dimensional array with null elements
     * first, we test the way from the down left to the top right
     */
    private Cell[][] bufferDownLeft(Cell dist) {
        Cell[][] line = new Cell[8][8];

        char y = (char) (getPosition().getContour() - 7);
        for (int i = getPosition().getHeight() - 7; i < 9 && y <= 'h'; i++, y++) {
            if (i == dist.getHeight() && y == dist.getContour()) {
                index = getPosition().getHeight() - i;
                this.flag = true;
                if (index > 0) {
                    y = dist.getContour();
                    for (int beam = dist.getHeight() - 1; beam < getPosition().getHeight() - 1; beam++, y++) {
                        line[beam][beam] = new Cell(beam + 1, y);
                    }
                } else {
                    y = dist.getContour();
                    for (int beam =  dist.getHeight() - 1; beam >= getPosition().getHeight(); beam--, y--) {
                        line[beam][beam] = new Cell(beam + 1, y);
                    }
                }
            }
        }
        return line;
    }
    /**
     * bufferDownRight.
     * @param dist -
     * @return - Two-dimensional array with null elements
     * second, we test the way from the down right to the top left
     */
    private Cell[][] bufferDownRight(Cell dist) {
        Cell[][] line = new Cell[8][8];

        char y = (char) (getPosition().getContour() + 7);
        for (int i = getPosition().getHeight() - 7; i < 9 && y >= 'a'; i++, y--) {
            if (i == dist.getHeight() && y == dist.getContour()) {
                index = getPosition().getHeight() - i;
                this.flag = true;
                if (index > 0) {
                    y = dist.getContour();
                    for (int beam = dist.getHeight() - 1; beam < getPosition().getHeight() - 1; beam++, y--) {
                        line[beam][beam] = new Cell(beam + 1, y);
                    }
                } else {
                    y = dist.getContour();
                    for (int beam =  dist.getHeight() - 1; beam > getPosition().getHeight() - 1; beam--, y++) {
                        line[beam][beam] = new Cell(beam + 1, y);
                    }
                }
            }
        }
        return line;
    }
    /**
     * ridCellArrayZero.
     * @param line - Two-dimensional array with null elements
     * @param index - the size of a one-dimensional array
     * @return one dimensional array without null elements
     */
    private Cell[] ridCellArrayZero(Cell[][] line, int index) {
        Cell[] buffer = new Cell[Math.abs(index)];
        int beam = 0;
        for (Cell[] cells : line) {
            for (Cell cl : cells) {
                if (cl != null) {
                    buffer[beam++] = cl;
                }
            }
        }
        return buffer;
    }
}