package ru.job4j.tracker;

import java.sql.SQLException;

/**
 * StartUi.
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class StartUi {
    /**
     * ConsoleInput.
     */
    private Input input;
    /**
     * Tracker.
     */
    private Tracker tracker;
    /**
     * menu's choice.
     */
    private static final int SIX = 6;
    /**
     * menu's exit.
     */
    private boolean exit;
    /**
     * constructor.
     * @param input - ConsoleInput
     * @param tracker - Tracker
     */
    public StartUi(Input input, Tracker tracker) {
        this.input = input;
        this.tracker = tracker;
    }
    /**
     * init.
     */
    public void init() throws SQLException {
        MenuTracker menu = new MenuTracker(this.input, this.tracker);
        menu.fillActions();
        int[] ranges = new int[menu.getActions().size()];
        for (int i = 0; i < ranges.length; i++) {
            ranges[i] = i;
        }
        do {
            menu.show();
            System.out.println("Select number");
            int key = this.input.ask(ranges);
            menu.select(key);
            if (key == SIX) {
                exit = true;
            }
        } while (!exit);
    }
    /**
     * Main.
     * @param args -
     */
    public static void main(String[] args) throws SQLException {
        Input input = new ValidateInput();
        Tracker tracker = new Tracker();
        new StartUi(input, tracker).init();
    }
}