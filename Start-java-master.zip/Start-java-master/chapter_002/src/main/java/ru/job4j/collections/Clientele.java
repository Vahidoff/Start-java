package ru.job4j.collections;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Objects;

/**
 * Clientele.
 * bank profiles in MapList
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Clientele {
    /**
     * bank clients in HashMap.
     */
    private Map<User, List<Account>> clients = new HashMap<>();
    /**
     * getClients.
     * @return - clients
     */
    public Map<User, List<Account>> getClients() {
        return clients;
    }
    /**
     * addUser.
     * adding to clients
     * @param user - User
     */
    public void addUser(User user) {
        List<Account> la = new ArrayList<>();
        la.add(new Account(0, "default"));
        clients.put(user, la);
    }
    /**
     * deleteUser.
     * @param user User
     */
    public void deleteUser(User user) {
        clients.remove(user);
    }
    /**
     * addAccountToUser.
     * @param user -
     * @param account - bank requisite
     */
    public void addAccountToUser(User user, Account account) {
        if (Objects.equals(clients.get(user).get(0).getRequisites(), "default")) {
            clients.get(user).clear();
        }
        clients.get(user).add(account);
    }
    /**
     * deleteAccountFromUser.
     * deleting one Account of user
     * @param user -
     * @param account - bank requisite
     */
    public void deleteAccountFromUser(User user, Account account) {
        clients.get(user).remove(account);
        if (clients.get(user).isEmpty()) {
            clients.get(user).add(new Account(0, "default"));
        }
    }
    /**
     * getUserAccounts.
     * getting all user's Accounts
     * @param user -
     * @return - List<Account>
     */
    public List<Account> getUserAccounts(User user) {
        return clients.get(user);
    }
    /**
     * transferMoney.
     * @param srcUser - transferring user
     * @param srcAccount - transferring Account
     * @param dstUser - accepting user
     * @param dstAccount - accepting Account
     * @param amount - transfer
     * @return - boolean result
     */
    public boolean transferMoney(User srcUser, Account srcAccount, User dstUser, Account dstAccount, double amount) {
        if (srcAccount == null || srcAccount.getValue() < amount || !clients.get(srcUser).contains(srcAccount)
                || !clients.get(dstUser).contains(dstAccount)) {
            return false;
        } else {
            srcAccount.setValue(srcAccount.getValue() - amount);
            dstAccount.setValue(dstAccount.getValue() + amount);
            return true;
        }
    }
}
