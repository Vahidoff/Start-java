package ru.job4j.ticktacktoe;
/**
 * Cage.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Cage {
    /**
     * cell value.
     */
    private int tick;
    /**
     * cell filling options.
     */
    private static final int ZERO = 0, CROSS = 1;
    /**
     * Cage.
     * @param tick - cell element
     */
    protected Cage(int tick) {
        this.tick = tick;
    }
    /**
     * getTick.
     * @return value of cell
     */
    public int getTick() {
        return this.tick;
    }
    @Override
    public String toString() {
        if (this.tick == ZERO) {
            return " " + 'O';
        } else {
            return " " + 'X';
        }
    }

}
