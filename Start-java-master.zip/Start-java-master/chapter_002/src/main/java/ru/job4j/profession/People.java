package ru.job4j.profession;

/**
 * People.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class People {
    /**
     * @param name -
     */
    private String name;
    /**
     * @param name -
     */
    public People(String name) {
        this.name = name;
    }

    /**
     * get name.
     * @return String
     */
    public String getname() {
        return this.name;
    }
}