package ru.job4j.checker;

/**
 * OccupiedWayException.
 * extends RuntimeException
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class OccupiedWayException extends RuntimeException {
    /**
     * @param msq -
     */
    public OccupiedWayException(String msq) {
        super(msq);
    }
}
