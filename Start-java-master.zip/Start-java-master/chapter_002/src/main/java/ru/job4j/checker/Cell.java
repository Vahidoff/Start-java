package ru.job4j.checker;

/**
 * Cell.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Cell {
    /**
     * vertical of the chessboard.
     */
    private int height;
    /**
     * horizontal of the chess board.
     */
    private char contour;
    /**
     * constructor Cell.
     * @param height -
     * @param contour -
     */
    public Cell(int height, char contour) {
        this.height = height;
        this.contour = contour;
    }
    /**
     * getHeight.
     * @return height
     */
    public int getHeight() {
        return this.height;
    }
    /**
     * getContour.
     * @return contour
     */
    public char getContour() {
        return this.contour;
    }
    /**
     * toString.
     * @return String of Cell
     */
    public String toString() {
        return " " + this.getHeight() + this.getContour();
    }
    /**
     * show.
     * @param array - array of Cell
     * @return String of Cell array
     */
    public String show(Cell[] array) {
        StringBuilder buffer = new StringBuilder();
        for (Cell value : array) {
            buffer.append(value.toString());
        }
        return buffer.toString();
    }

}