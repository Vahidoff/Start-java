package ru.job4j.checker;

/**
 * FigureNotFoundException.
 * extends RuntimeException
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class FigureNotFoundException extends RuntimeException {
    /**
     * ImpossibleMoveException.
     * @param msq -
     */
    public FigureNotFoundException(String msq) {
        super(msq);
    }
}
