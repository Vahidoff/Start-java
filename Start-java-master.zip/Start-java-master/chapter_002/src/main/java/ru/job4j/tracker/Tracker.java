package ru.job4j.tracker;

import org.postgresql.util.PSQLState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Random;

/**
 * Tracker.
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Tracker {

    private static final Logger LOG = LoggerFactory.getLogger(PSQLState.class);
    private Connection conn;
    private PreparedStatement ps;
    private ResultSet rs;
    /**
     * class variable position.
     */
    private int position = 0;
    /**
     * class Random variable.
     */
    private static final Random RN = new Random();

    public void connectDb() {
        final Properties properties = new Properties();
        try (InputStream in = getClass().getClassLoader().
                getResourceAsStream("connection.properties")) {
            properties.load(in);
        } catch (IOException e) {
            LOG.error(e.getMessage(), e);
        }
        try {
            this.conn = DriverManager.getConnection(properties.getProperty("url"),
                    properties.getProperty("user"), properties.getProperty("password"));
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
    }

    public void disconnectDb() {
        try {
            assert conn != null;
            this.conn.close();
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
        try {
            if (this.ps != null) {
                this.ps.close();
            }
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
        try {
            if (this.rs != null) {
                this.rs.close();
            }
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
    }

    private void createTable() throws SQLException {
        ResultSet rs = null;
        try {
            rs = this.conn.getMetaData().
                    getTables(null, null, "items", null);
            if (rs.next()) {
                this.readSQL("clearItemTable.sql");
            } else {
                this.readSQL("createItemTable.sql");
            }
        } catch (SQLException | IOException e) {
            LOG.error(e.getMessage(), e);
        } finally {
           if (rs != null) {
               rs.close();
           }
        }
    }
    private void readSQL(String fileName) throws IOException {
        String line;
        StringBuilder builder = new StringBuilder();
        FileReader fr = new FileReader(fileName);
        BufferedReader br = new BufferedReader(fr);

        while ((line = br.readLine()) != null) {
            builder.append(line);
        }
        br.close();

        String[] query = builder.toString().split(";");
        try {
            Statement st = this.conn.createStatement();
            for (int i = 0; i < query.length; i++) {
                if (!query[i].trim().equals("")) {
                    st.executeUpdate(query[i]);
                }
            }
            st.close();
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
    }
    /**
     * add.
     * @param item -
     * @return Item item.
     */
    public Item add(Item item) throws SQLException {
        if (this.position == 0) {
            this.createTable();
        }
        item.setId(this.generateId());
        try {
            this.ps = this.conn.prepareStatement("INSERT INTO items"
                    + "(id_item, name, description, create_long, comment) "
                    + "VALUES (?, ?, ?, ?, ?)");
            this.ps.setString(1, item.getId());
            this.ps.setString(2, item.getName());
            this.ps.setString(3, item.getDescription());
            this.ps.setLong(4, item.getCreate());
            this.ps.setString(5, item.getComment());
            ps.executeUpdate();
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
        this.position++;
        return item;
    }
    /**
     * generateId.
     * @return String
     */
    private String generateId() {
        return String.valueOf(System.currentTimeMillis() + RN.nextInt()).substring(0, 5);
    }
    /**
     * update.
     * @param item -
     */
    public void update(Item item) {
        try {
            this.ps = this.conn.prepareStatement("UPDATE items SET name = ?, description = ?,"
                    + "create_long = ?, comment = ? WHERE id_item = ?");
            this.ps.setString(1, item.getName());
            this.ps.setString(2, item.getDescription());
            this.ps.setLong(3, item.getCreate());
            this.ps.setString(3, item.getComment());
            this.ps.setString(3, item.getId());
            this.ps.executeUpdate();
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
    }

    /**
     * delete.
     * @param item -
     */
    public void delete(Item item) {
        try {
            this.ps = this.conn.prepareStatement("DELETE FROM items WHERE id_item = ?");
            this.ps.setString(1, item.getId());
            this.ps.executeUpdate();
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
    }
    /**
     * findById.
     * @param id -
     * @return Item result
     */
    public Item findById(String id) {
        Item result = null;
        try {
            this.ps = this.conn.prepareStatement("SELECT * FROM items WHERE id_item = ?");
            this.ps.setString(1, id);
            this.rs = this.ps.executeQuery();
            while (rs.next()) {
                result = new Item(this.rs.getString("name"),
                        this.rs.getString("description"),
                        this.rs.getLong("create_long"),
                        this.rs.getString("comment"));
                result.setId(this.rs.getString("id_item"));
            }
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
        return result;
    }
    /**
     * findByName.
     * @param key - name
     * @return Item result[]
     */
    public Item[] findByName(String key) {
        List<Item> result = new ArrayList<>();
        Item item;
        try {
            this.ps = this.conn.prepareStatement("SELECT * FROM items WHERE name = ?");
            this.ps.setString(1, key);
            this.rs = this.ps.executeQuery();
            while (rs.next()) {
                item = new Item(rs.getString("name"),
                        rs.getString("description"),
                        rs.getLong("create_long"),
                        rs.getString("comment"));
                item.setId(rs.getString("id_item"));
                result.add(item);
            }
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
        return result.toArray(new Item[result.size()]);
    }
    /**
     * findAll.
     * @return Item[] result
     */
    public Item[] findAll() {
        List<Item> result = new ArrayList<>();
        try {
            this.ps = this.conn.prepareStatement("SELECT * FROM items");
            this.rs = ps.executeQuery();
            while (rs.next()) {
                Item item = new Item(rs.getString("name"),
                        rs.getString("description"),
                        rs.getLong("create_long"),
                        rs.getString("comment"));
                item.setId(rs.getString("id_item"));
                result.add(item);
            }
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
        return result.toArray(new Item[result.size()]);
    }
}