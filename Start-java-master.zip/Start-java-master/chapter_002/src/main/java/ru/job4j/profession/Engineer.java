package ru.job4j.profession;

/**
 * Engineer.
 *
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Engineer extends Profession {
    /**
     * special parameters.
     */
    private String specialization;
    /**
     * common parameters.
     *
     * @param name           -
     * @param age            -
     * @param experience     -
     * @param education      -
     * @param gender         -
     * @param revenue        -
     * @param specialization -
     */
    public Engineer(String name, float age, int experience, String education, String gender, float revenue, String specialization) {
        super(name, age, experience, education, gender, revenue);
        this.specialization = specialization;
    }
    /**
     * gettotalinformation.
     * @return String
     */
    public String gettotalinformation() {
        String information = super.gettotalinformation();
        return (information + " " + this.specialization);
    }
    /**
     * check of work.
     * true if within the range.
     * @param length -
     * @param width -
     * @param height -
     * @return boolean
     */
    public boolean checkofwork(int length, int width, int height) {
        return  ((length < 253 & length > 247) & ((width < 123 & width > 117) & (height < 91 & height > 85)));
    }
    /**
     * staffcontrol.
     * @param worker -
     * @param workload -
     * @return String
     */
    public String staffcontrol(People worker, int workload) {
        String result;
        if (workload > 200) {
            result = "good";
        } else {
            result = "bad";
        }
        return (worker.getname() + "'s work is " + result);
    }
}