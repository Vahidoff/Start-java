package ru.job4j.subdivisions;
import org.junit.Test;

import java.util.LinkedList;
import java.util.List;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * Test.
 * SortedUnits
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class SortedUnitsTest {
    /**
     * Test1 sortingUnits.
     */
    @Test
    public void whenAddListUnitsThenSorting() {
        SortedUnits solid = new SortedUnits();
        List<String> list = new LinkedList<>();
        list.add("K1/SK1/SSK2");
        list.add("K1/SK2");
        list.add("K2/SK2");
        list.add("K2/SK1/SSK2");
        list.add("K1");
        list.add("K2/SK1");
        list.add("K2/SK1/SSK1");
        list.add("K2");
        list.add("K1/SK1/SSK1");
        list.add("K1/SK1");


        String[] units = new String[10];
        solid.sortingUnits(list).toArray(units);
        assertThat(units[0], is("K1"));
        assertThat(units[1], is("K1/SK1"));
        assertThat(units[2], is("K1/SK1/SSK1"));
        assertThat(units[3], is("K1/SK1/SSK2"));
        assertThat(units[4], is("K1/SK2"));
        assertThat(units[5], is("K2"));
        assertThat(units[6], is("K2/SK1"));
        assertThat(units[7], is("K2/SK1/SSK1"));
        assertThat(units[8], is("K2/SK1/SSK2"));
        assertThat(units[9], is("K2/SK2"));
    }
    /**
     * Test1 sortingUnitsRevers.
     */
    @Test
    public void whenAddListUnitsThenSortingRevers() {
        SortedUnits solid = new SortedUnits();
        List<String> list = new LinkedList<>();
        list.add("K1/SK1/SSK2");
        list.add("K2/SK2");
        list.add("K1/SK2");
        list.add("K2/SK1/SSK2");
        list.add("K1");
        list.add("K2/SK1");
        list.add("K2/SK1/SSK1");
        list.add("K2");
        list.add("K1/SK1/SSK1");
        list.add("K1/SK1");

        String[] units = new String[10];
        solid.sortingUnitsRevers(list).toArray(units);
        assertThat(units[0], is("K2"));
        assertThat(units[1], is("K2/SK2"));
        assertThat(units[2], is("K2/SK1"));
        assertThat(units[3], is("K2/SK1/SSK2"));
        assertThat(units[4], is("K2/SK1/SSK1"));
        assertThat(units[5], is("K1"));
        assertThat(units[6], is("K1/SK2"));
        assertThat(units[7], is("K1/SK1"));
        assertThat(units[8], is("K1/SK1/SSK2"));
        assertThat(units[9], is("K1/SK1/SSK1"));
    }
}
