package ru.job4j.collections;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
/**
 * AccountTest.
 * Account and Clientele
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class ClienteleTest {
    /**
     * Test1 deleteUser.
     */
    @Test
    public void whenDeleteUserMapListThenNull() {
        User bob = new User("Bob", "Copenhagen", 22);
        User cat = new User("Cat", "Carthage", 38);
        User rob = new User("Rob", "London", 19);
        User jon = new User("Jon", "London", 27);
        Clientele solid = new Clientele();
        solid.addUser(bob);
        solid.addUser(cat);
        solid.addUser(rob);
        solid.addUser(jon);

        assertThat(solid.getClients().containsKey(rob), is(true));
        solid.deleteUser(rob);
        assertNull("This reference is null", solid.getClients().get(rob));
    }
    /**
     * Test2 deleteAccountFromUser.
     */
    @Test
    public void whenDeleteAccountUserMapListThenNull() {
        User bob = new User("Bob", "Copenhagen", 22);
        User cat = new User("Cat", "Carthage", 38);
        Clientele solid = new Clientele();
        solid.addUser(bob);
        solid.addUser(cat);
        Account bobAcc1 = new Account(100, "Bob 123 07. 08. 2017");
        Account bobAcc2 = new Account(500, "Bob 1234 08. 08. 2017");
        solid.addAccountToUser(bob, bobAcc2);
        solid.addAccountToUser(bob, bobAcc1);

        assertThat(solid.getClients().get(bob).contains(bobAcc2), is(true));
        assertThat(solid.getClients().get(bob).contains(bobAcc1), is(true));

        solid.deleteAccountFromUser(bob, bobAcc2);

        assertThat(solid.getClients().get(bob).contains(bobAcc2), is(false));
    }
    /**
     * Test3 transferMoney.
     */
    @Test
    public void whenTransferMoneyMapListThenTrue() {
        User bob = new User("Bob", "Copenhagen", 22);
        User cat = new User("Cat", "Carthage", 38);
        User rob = new User("Rob", "London", 19);
        Clientele solid = new Clientele();
        solid.addUser(bob);
        solid.addUser(cat);
        solid.addUser(rob);
        Account bobAcc1 = new Account(100, "Bob 123 07. 08. 2017");
        Account bobAcc2 = new Account(500, "Bob 1234 08. 08. 2017");
        Account catAcc1 = new Account(50, "Cat 12345 06. 02. 2017");
        Account catAcc2 = new Account(750, "Cat 123456 14. 03. 2017");
        solid.addAccountToUser(bob, bobAcc2);
        solid.addAccountToUser(bob, bobAcc1);
        solid.addAccountToUser(cat, catAcc1);
        solid.addAccountToUser(cat, catAcc2);

        solid.transferMoney(bob, bobAcc2, cat, catAcc1, 300d);

        assertThat(solid.transferMoney(bob, bobAcc2, cat, catAcc1, 300d), is(false));
        assertThat(solid.transferMoney(rob, catAcc2, cat, catAcc1, 300d), is(false));

        assertThat(solid.getClients().get(cat).get(0).getValue(), is(350d));
        assertThat(bobAcc2.getValue(), is(200d));
    }
    /**
     * Test4 getUserAccounts.
     */
    @Test
    public void whenAddUerMapListThenAllAccounts() {
        User bob = new User("Bob", "Copenhagen", 22);
        Clientele solid = new Clientele();
        solid.addUser(bob);
        Account bobAcc1 = new Account(100, "Bob 123 07. 08. 2017");
        Account bobAcc2 = new Account(500, "Bob 1234 08. 08. 2017");
        Account bobAcc3 = new Account(50, "Bob 123467 18. 06. 2017");
        solid.addAccountToUser(bob, bobAcc2);
        solid.addAccountToUser(bob, bobAcc1);
        solid.addAccountToUser(bob, bobAcc3);

        ArrayList<Account> expected = new ArrayList<>();
        expected.addAll(Arrays.asList(bobAcc2, bobAcc1, bobAcc3));

        assertThat(solid.getUserAccounts(bob), is(expected));
    }
}
