package ru.job4j.collections;

import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

/**
 * Test.
 * UserConvert and SortUser
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class UserConvertTest {
    /**
     * Test1 process.
     */
    @Test
    public void whenAddListUserThenHashMapIU() {
        UserConvert solid = new  UserConvert();
        List<User> list = new LinkedList<>();
        HashMap<Integer, User> hmIU;

        User bob = new User("Bob", "Copenhagen", 22);
        User cat = new User("Cat", "Carthage", 38);
        User rob = new User("Rob", "London", 19);
        list.add(bob);
        list.add(cat);
        list.add(rob);
        hmIU = solid.process(list);

        assertThat(hmIU.get(cat.getId()).getName(), is("Cat"));
        assertThat(hmIU.get(rob.getId()).getCity(), is("London"));
        assertThat(hmIU.get(bob.getId()), is(bob));
    }
    /**
     * Test1 sort SortUser.
     */
    @Test
    public void whenAddListUserThenTreeSetSortAge() {
        SortUser solid = new SortUser();
        List<User> list = new LinkedList<>();

        User bob = new User("Bob", "Copenhagen", 22);
        User cat = new User("Cat", "Carthage", 38);
        User rob = new User("Rob", "London", 19);
        User jon = new User("Jon", "London", 27);
        list.add(bob);
        list.add(cat);
        list.add(rob);
        list.add(bob);
        list.add(jon);

        User[] users = new User[5];
        solid.sort(list).toArray(users);
        assertThat(users[0].getAge(), is(19));
        assertThat(users[1].getAge(), is(22));
        assertThat(users[2].getAge(), is(27));
        assertThat(users[3].getAge(), is(38));
        assertNull("This reference is null", users[4]);
    }
    /**
     * Test3 sortNameLength SortUser.
     */
    @Test
    public void whenAddListUserThenSortNameLength() {
        SortUser solid = new SortUser();
        List<User> list = new ArrayList<>();

        User bob = new User("Bob", "Copenhagen", 22);
        User caty = new User("Caty", "Carthage", 38);
        User robinson = new User("Robinson", "London", 19);
        User jonson = new User("Jonson", "London", 27);
        list.add(caty);
        list.add(bob);
        list.add(robinson);
        list.add(jonson);

        solid.sortNameLength(list);
        assertThat(list.get(0).getName(), is("Bob"));
        assertThat(list.get(1).getName(), is("Caty"));
        assertThat(list.get(2).getName(), is("Jonson"));
        assertThat(list.get(3).getName(), is("Robinson"));
    }
    /**
     * Test4 sortByAllFields SortUser.
     */
    @Test
    public void whenAddListUserThenSortNameAge() {
        SortUser solid = new SortUser();
        List<User> list = new ArrayList<>();

        User bob = new User("Bob", "Copenhagen", 22);
        User boby = new User("Bob", "Carthage", 38);
        User robinson = new User("Robinson", "London", 19);
        User roby = new User("Robinson", "London", 44);
        User jonson = new User("Jonson", "London", 27);
        list.add(boby);
        list.add(bob);
        list.add(robinson);
        list.add(roby);
        list.add(jonson);

        User[] users = new User[5];
        solid.sortByAllFields(list).toArray(users);
        assertThat(users[0], is(bob));
        assertThat(users[1], is(boby));
        assertThat(users[2], is(jonson));
        assertThat(users[3], is(robinson));
        assertThat(users[4], is(roby));
    }
}