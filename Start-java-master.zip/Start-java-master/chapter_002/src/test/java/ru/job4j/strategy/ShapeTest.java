package ru.job4j.strategy;

import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
/**
 * Test.
 *
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class ShapeTest {
    /**
     * Test1 triangle.
     */
    @Test
    public void whenPaintTriangleThenStringTriangle() {
        Paint paint = new Paint();
        String result = paint.figureTriangle();
        String expected = String.format("   x   %s  xxx  %<s xxxxx %<sxxxxxxx", System.getProperty("line.separator"));
        assertThat(result, is(expected));
    }
    /**
     * Test1 square.
     */
    @Test
    public void whenPaintSquareThenStringSquare() {
        Paint paint = new Paint();
        String result = paint.figureSquare();
        String expected = String.format("ooooo%so   o%<so   o%<so   o%<sooooo", System.getProperty("line.separator"));
        assertThat(result, is(expected));
    }
}
