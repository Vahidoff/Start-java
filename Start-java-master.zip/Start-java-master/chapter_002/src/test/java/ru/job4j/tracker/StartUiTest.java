package ru.job4j.tracker;

import org.junit.Test;

import java.sql.SQLException;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
/**
 * Test.
 *
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class StartUiTest {
    /**
     * Test1 0. Add new Item.
     */
    @Test
    public void whenUserAddItemThenTrackerHasNewItemWithSameName() throws SQLException {
        Tracker tracker = new Tracker(); // создаём Tracker
        tracker.connectDb();
        Input input = new StubInput(new String[] {"0", "middle", "successful", "123", "improved", "1", "6"});   //создаём StubInput с последовательностью действий
        new StartUi(input, tracker).init();   //   создаём StartUI и вызываем метод init()
        assertThat(tracker.findAll()[0].getName(), is("middle")); // проверяем, что нулевой элемент массива в трекере содержит имя, введённое при эмуляции.
        tracker.disconnectDb();
    }
    /**
     * Test2 1. Show all items.
     */
    @Test
    public void whenUpdateThenTrackerHasUpdatedValue() throws SQLException {
        Tracker tracker = new Tracker();        //Напрямую добавляем заявку
        tracker.connectDb();
        Item item = tracker.add(new Item("middle", "thriving", 13245L, "repaired"));
        Item claim = tracker.add(new Item("senior", "successful", 123456L, "outdated"));
        Item bid = tracker.add(new Item("junior", "beautiful", 1234567L, "excellent"));
        Input input = new StubInput(new String[]{"1", "6"});
        // создаём StartUI и вызываем метод init()
        new StartUi(input, tracker).init();
        // проверяем, что нулевой элемент массива в трекере содержит имя, введённое при эмуляции.
        assertThat(tracker.findAll()[2].getName(), is("junior"));
        tracker.disconnectDb();
    }
    /**
     * Test3 2. Edit item.
     */
    @Test
    public void whenUpdateItemThenTrackerHasUpdatedItem() throws SQLException {
        Tracker tracker = new Tracker();
        tracker.connectDb();
        Item item = tracker.add(new Item("middle", "thriving", 13245L, "repaired"));
        Item claim = tracker.add(new Item("senior", "successful", 123456L, "outdated"));
        Item bid = tracker.add(new Item("junior", "beautiful", 1234567L, "excellent"));
        Input input = new StubInput(new String[]{"2", claim.getId(), "little", "failure", "12345", "broken", "1", "6"});
        new StartUi(input, tracker).init();
        assertThat(tracker.findAll()[1].getName(), is("senior"));
        tracker.disconnectDb();
    }
    /**
     * Test4 3. Delete item.
     */
    @Test
    public void whenEnterItemThenTrackerDeleteItem() throws SQLException {
        Tracker tracker = new Tracker();
        tracker.connectDb();
        Item item = tracker.add(new Item("middle", "thriving", 13245L, "repaired"));
        Item claim = tracker.add(new Item("senior", "successful", 123456L, "outdated"));
        Item bid = tracker.add(new Item("junior", "beautiful", 1234567L, "excellent"));
        Input input = new StubInput(new String[]{"3", claim.getId(), "1", "6"});
        new StartUi(input, tracker).init();
        assertNull("This reference is null", tracker.findById(claim.getId()));
        tracker.disconnectDb();
    }
    /**
     * Test5 4. Find item by Id.
     */
    @Test
    public void whenEnterIdItemThenTrackerFindItem() throws SQLException {
        Tracker tracker = new Tracker();
        tracker.connectDb();
        Item item = tracker.add(new Item("middle", "thriving", 13245L, "repaired"));
        Item claim = tracker.add(new Item("senior", "successful", 123456L, "outdated"));
        Item bid = tracker.add(new Item("junior", "beautiful", 1234567L, "excellent"));
        Input input = new StubInput(new String[]{"4", claim.getId(), "6"});
        new StartUi(input, tracker).init();
        assertThat(tracker.findById(claim.getId()).getName(), is("senior"));
        tracker.disconnectDb();
    }
}
