package ru.job4j.profession;

import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
/**
 * Test.
 *
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class ProfessionTest {
	/**
     * Test1 condition.
     */
    @Test
    public void whenTimesofDay13ThenStringWorking() {
        Profession builder = new Engineer("Michael", 55, 15, "master", "man", 14.3f, "wood constructions");
        String result = builder.condition(13.3f);
        String expected = "working";
        assertThat(result, is(expected));
	}
    /**
     * Test2 climate.
     */
    @Test
    public void whenAstrakhanThenInt15() {
        Profession builder = new Engineer("Michael", 55, 15, "master", "man", 14.3f, "wood constructions");
        int result = builder.climate("Astrakhan");
        int expected = 25;
        assertThat(result, is(expected));
    }
    /**
     * Test3 hurt.
     */
    @Test
    public void whenBodyTemperatureThenTrue() {
        Profession builder = new Engineer("Michael", 55, 15, "master", "man", 14.3f, "wood constructions");
        boolean result = builder.hurt(40.7f);
        boolean expected = true;
        assertThat(result, is(expected));
    }
    /**
     * Test4 purchases.
     */
    @Test
    public void whenPurchasesThenFloat() {
        Profession builder = new Engineer("Michael", 55, 15, "master", "man", 14000.3f, "wood constructions");
        float result = builder.purchases(4000.7f, 15000f);
        float expected = 13700.44f;
        assertThat(result, is(expected));
    }
    /**
     * Test5 gettotalinformation.
     */
    @Test
    public void whenAllParametersThenString() {
        Profession builder = new Engineer("Michael", 55, 15, "master", "man", 14000.3f, "wood constructions");
        String result = builder.gettotalinformation();
        String expected = "Michael 55.0 years, 15 years, master man 14000.3 wood constructions";
        assertThat(result, is(expected));
    }
    /**
     * Test6 checkofwork.
     */
    @Test
    public void whenCheckofWorkThenTrue() {
        Engineer builder = new Engineer("Michael", 55, 15, "master", "man", 14000.3f, "wood constructions");
        boolean result = builder.checkofwork(250, 120, 88);
        boolean expected = true;
        assertThat(result, is(expected));
    }
    /**
     * Test7 staff control.
     */
    @Test
    public void whenStaffControlThenString() {
        Engineer builder = new Engineer("Michael", 55, 15, "master", "man", 14000.3f, "wood constructions");
        People worker = new People("Bob");
        String result = builder.staffcontrol(worker, 210);
        String expected = "Bob's work is good";
        assertThat(result, is(expected));
    }
    /**
     * Test8 teaching.
     */
    @Test
    public void whenTeachingThenString() {
        Teacher chemist = new Teacher("Lora", 35, 7, "master", "woman", 8000.3f, "chemistry");
        People children = new People("Jordge");
        String result = chemist.teaching(children);
        String expected = "Teacher Lora teaches pupil Jordge";
        assertThat(result, is(expected));
    }
    /**
     * Test9 admission.
     */
    @Test
    public void whenAdmissionThenString() {
        Doctor dentist = new Doctor("Elon", 45, 16, "doctor", "man", 28000.3f, "stomatology");
        People patient = new People("Nike");
        String result = dentist.admission(patient);
        String expected = "Dr. Elon is talking Nike";
        assertThat(result, is(expected));
    }
    /**
     * Test10 medical analysis.
     */
    @Test
    public void whenMedicalAnalysisThenString() {
        Doctor pediatrician = new Doctor("Bill", 54, 25, "doctor", "man", 25000.3f, "pediatrics");
        People patient = new People("Tom");
        String result = pediatrician.medicalanalysis(patient, 5.7d);
        String expected = "Patient Tom is sick";
        assertThat(result, is(expected));
    }
    /**
     * Test11 medical gettotalinformation.
     */
    @Test
    public void whenGetTotalInformationThenStringDoctor() {
        Doctor pediatrician = new Doctor("Bill", 54, 25, "doctor", "man", 25000.3f, "pediatrics");
        String result = pediatrician.gettotalinformation();
        String expected = "Bill 54.0 years, 25 years, doctor man 25000.3 pediatrics";
        assertThat(result, is(expected));
    }
 }