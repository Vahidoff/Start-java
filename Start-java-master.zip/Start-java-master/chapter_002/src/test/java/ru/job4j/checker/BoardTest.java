package ru.job4j.checker;

import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
/**
 * Test.
 *
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class BoardTest {
    /**
     * Test1 move.
     * go to the top right.
     */
    @Test
    public void whenAddSourceAndRightDistTopRightThenTrue() {
        Board board = new Board();
        Cell cell1A = new Cell(1, 'a');
        Cell cell6F = new Cell(6, 'F');
        Cell cell3B = new Cell(3, 'b');
        Cell cell2A = new Cell(2, 'a');
        Cell cell7F = new Cell(7, 'f');
        Figure elephant = new Elephant("white elephant", cell2A);
        board.setFigures(elephant, 0);
        Figure whitePawn = new Elephant("white pawn", cell1A);
        board.setFigures(whitePawn, 1);
        assertThat(board.move(cell2A, cell7F), is(true));
    }
    /**
     * Test2 way Elephant.
     */
    @Test
    public void whenAddSourceAndRightDistTopRightThenTrueArray() {
        Board board = new Board();
        Cell cell2A = new Cell(2, 'a');
        Cell cell7F = new Cell(7, 'f');
        Figure elephant = new Elephant("white elephant", cell2A);
        board.setFigures(elephant, 0);
        Cell[] wayResult = board.getFigures(0).way(cell7F);
        assertThat(wayResult[0].show(wayResult), is(" 3b 4c 5d 6e 7f"));
    }
    /**
     * Test3 move.
     * go down to the left
     */
    @Test
    public void whenAddSourceAndRightDistDownLeftThenPositionDist() {
        Board board = new Board();
        Cell cell4G = new Cell(4, 'g');
        Cell cell1D = new Cell(1, 'd');
        Cell cell1A = new Cell(1, 'a');
        Cell cell8H = new Cell(8, 'h');
        Figure elephant = new Elephant("white elephant", cell8H);
        board.setFigures(elephant, 0);
        board.move(cell8H, cell1A);
        assertThat(board.getFigures(0).getPosition(), is(cell1A));
    }
    /**
     * Test4 way elephant.
     */
    @Test
    public void whenAddSourceAndRightDistDownLeftThenTrueArray() {
        Board board = new Board();
        Cell cell4G = new Cell(4, 'g');
        Cell cell1D = new Cell(1, 'd');
        Figure elephant = new Elephant("white elephant", cell4G);
        board.setFigures(elephant, 0);
        Cell[] wayResult = board.getFigures(0).way(cell1D);
        assertThat(wayResult[0].show(wayResult), is(" 1d 2e 3f"));
    }
    /**
     * Test5 move.
     * do down to the right
     */
    @Test
    public void whenAddSourceAndRightDistDownRightThenTrue() {
        Board board = new Board();
        Cell cell8A = new Cell(8, 'a');
        Cell cell1H = new Cell(1, 'h');
        Cell cell8B = new Cell(8, 'b');
        Cell cell3G = new Cell(3, 'g');
        Figure elephant = new Elephant("white elephant", cell8B);
        board.setFigures(elephant, 0);
        assertThat(board.move(cell8B, cell3G), is(true));
    }
    /**
     * Test6 way elephant.
     */
    @Test
    public void whenAddSourceAndRightDistDownRightThenTrueArray() {
        Board board = new Board();
        Cell cell8B = new Cell(8, 'b');
        Cell cell3G = new Cell(3, 'g');
        Figure elephant = new Elephant("white elephant", cell8B);
        board.setFigures(elephant, 0);
        Cell[] wayResult = board.getFigures(0).way(cell3G);
        assertThat(wayResult[0].show(wayResult), is(" 3g 4f 5e 6d 7c"));
    }
    /**
     * Test7 move.
     * go top to the left
     */
    @Test
    public void whenAddSourceAndRightDistTopLeftThenPositionDist() {
        Board board = new Board();
        Cell cell7H = new Cell(7, 'h');
        Cell cell8G = new Cell(8, 'g');
        Cell cell1H = new Cell(1, 'h');
        Cell cell8A = new Cell(8, 'a');
        Figure elephant = new Elephant("white elephant", cell1H);
        board.setFigures(elephant, 0);
        board.move(cell1H, cell8A);
        assertThat(board.getFigures(0).getPosition().toString(), is(" 8a"));
    }
    /**
     * Test8 way Elephant.
     */
    @Test
    public void whenAddSourceAndRightDistTopLeftThenTrueArray() {
        Board board = new Board();
        Cell cell7H = new Cell(7, 'h');
        Cell cell2G = new Cell(2, 'g');
        Cell cell1H = new Cell(1, 'h');
        Cell cell8A = new Cell(8, 'a');
        Figure elephant = new Elephant("white elephant", cell1H);
        board.setFigures(elephant, 0);
        Cell[] wayResult = board.getFigures(0).way(cell8A);
        assertThat(wayResult[0].show(wayResult), is(" 2g 3f 4e 5d 6c 7b 8a"));
    }
    /**
     * Test9 clone.
     */
    @Test
    public void whenAddSourceAndRightDistTopRightThenNewDist() {
        Board board = new Board();
        Cell cell2A = new Cell(2, 'a');
        Cell cell7F = new Cell(7, 'f');
        Figure elephant = new Elephant("white elephant", cell2A);
        board.setFigures(elephant, 0);
        board.move(cell2A, cell7F);
        assertThat(board.findByCell(cell7F).getName(), is("white elephant"));
    }
}