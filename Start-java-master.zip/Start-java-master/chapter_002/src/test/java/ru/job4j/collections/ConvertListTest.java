package ru.job4j.collections;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
/**
 * Test.
 *
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class ConvertListTest {
    /**
     * Test1 toArray.
     */
    @Test
    public void whenAddArrayListThenArrayRows3() {
        ConvertList solid = new ConvertList();
        int[][] result = solid.toArray(solid.toList(new int[][] {{1, 2, 3}, {4, 5, 6}, {7, }}), 3);
        int[][] expected = new int[][] {{1, 2, 3}, {4, 5, 6}, {7, 0, 0}};
        assertThat(result, is(expected));
    }
    /**
     * Test2 toArray.
     */
    @Test
    public void whenAddArrayListThenArrayRows4() {
        ConvertList solid = new ConvertList();
        int[][] result = solid.toArray(solid.toList(new int[][] {{1, 2, 3}, {4, 5, 6}, {7, }}), 4);
        int[][] expected = new int[][] {{1, 2, 3, 4}, {5, 6, 7, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}};
        assertThat(result, is(expected));
    }
    /**
     * Test3 convert.
     */
    @Test
    public void whenAddListArraysThenCommonList() {
        ConvertList solid = new ConvertList();
        ArrayList<int[]> ari = new ArrayList<>();
        ari.add(new int[] {1, 2});
        ari.add(new int[] {3, 4, 5, 6});
        HashSet<Integer> expected = new HashSet<>();
        expected.addAll(Arrays.asList(1, 2, 3, 4, 5, 6));
        assertThat(solid.convert(ari), is(expected));
    }
    /**
     * Test4 convert.
     */
    @Test
    public void whenAddListThreeArraysThenCommonList() {
        ConvertList solid = new ConvertList();
        ArrayList<int[]> ari = new ArrayList<>();
        ari.add(new int[] {1, 10});
        ari.add(new int[] {7, 8, 9});
        ari.add(new int[] {3, 4, 5, 6, 2});
        HashSet<Integer> expected = new HashSet<>();
        expected.addAll(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10));
        assertThat(solid.convert(ari), is(expected));
    }
}