package ru.job4j.ticktacktoe;

import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * Test.
 *
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */

public class TicktacktoeTest {
    /**
     * cell filling options.
     *
     */
    private static final int ZERO = 0, CROSS = 1;
    /**
     * Test1 horizontally.
     */
    @Test
    public void whenThreeTickHorizontallyThenTrue() {
        Ticktacktoe game = new Ticktacktoe(5);
        Cage cageZero = new Cage(ZERO);
        Cage cageCross = new Cage(CROSS);

        game.getField().add(cageZero, 0, 0);
        game.getField().add(cageZero, 1, 0);
        game.getField().add(cageZero, 2, 0);
        game.getField().add(cageZero, 3, 0);
        game.getField().add(cageZero, 4, 0);

        game.getField().add(cageZero, 0, 1);
        game.getField().add(cageCross, 1, 1);
        game.getField().add(cageZero, 2, 1);
        game.getField().add(cageCross, 3, 1);
        game.getField().add(cageZero, 4, 1);

        game.getField().add(cageZero, 0, 2);
        game.getField().add(cageCross, 1, 2);
        game.getField().add(cageCross, 2, 2);
        game.getField().add(cageCross, 3, 2);
        game.getField().add(cageZero, 4, 2);

        game.getField().add(cageZero, 0, 3);
        game.getField().add(cageZero, 1, 3);
        game.getField().add(cageCross, 2, 3);
        game.getField().add(cageZero, 3, 3);
        game.getField().add(cageZero, 4, 3);
        game.getField().add(cageCross, 0, 4);
        game.getField().add(cageZero, 1, 4);
        game.getField().add(cageCross, 2, 4);
        game.getField().add(cageZero, 3, 4);
        game.getField().add(cageCross, 4, 4);

        boolean result = game.win(1, 2);
        assertThat(result, is(true));
    }
    /**
     * Test2 Diagonal from down right.
     * }
     */
    @Test
    public void whenThreeTickDiagonalDownRightThenTrue() {
        Ticktacktoe game = new Ticktacktoe(5);
        Cage cageZero = new Cage(ZERO);
        Cage cageCross = new Cage(CROSS);

        game.getField().add(cageZero, 0, 0);
        game.getField().add(cageZero, 1, 0);
        game.getField().add(cageZero, 2, 0);
        game.getField().add(cageZero, 3, 0);
        game.getField().add(cageZero, 4, 0);

        game.getField().add(cageCross, 0, 1);
        game.getField().add(cageCross, 1, 1);
        game.getField().add(cageCross, 2, 1);
        game.getField().add(cageCross, 3, 1);
        game.getField().add(cageCross, 4, 1);

        game.getField().add(cageCross, 0, 2);
        game.getField().add(cageCross, 1, 2);
        game.getField().add(cageZero, 2, 2);
        game.getField().add(cageCross, 3, 2);
        game.getField().add(cageCross, 4, 2);

        game.getField().add(cageZero, 0, 3);
        game.getField().add(cageZero, 1, 3);
        game.getField().add(cageCross, 2, 3);
        game.getField().add(cageZero, 3, 3);
        game.getField().add(cageZero, 4, 3);
        game.getField().add(cageCross, 0, 4);
        game.getField().add(cageCross, 1, 4);
        game.getField().add(cageCross, 2, 4);
        game.getField().add(cageCross, 3, 4);
        game.getField().add(cageZero, 4, 4);

        boolean result = game.win(2, 2);
        assertThat(result, is(true));

    }
    /**
     * Test3 Vertical.
     */
    @Test
    public void whenThreeVerticalThenTrue() {
        Ticktacktoe game = new Ticktacktoe(5);
        Cage cageZero = new Cage(ZERO);
        Cage cageCross = new Cage(CROSS);

        game.getField().add(cageZero, 0, 0);
        game.getField().add(cageZero, 1, 0);
        game.getField().add(cageZero, 2, 0);
        game.getField().add(cageZero, 3, 0);
        game.getField().add(cageZero, 4, 0);

        game.getField().add(cageCross, 0, 1);
        game.getField().add(cageCross, 1, 1);
        game.getField().add(cageCross, 2, 1);
        game.getField().add(cageCross, 3, 1);
        game.getField().add(cageCross, 4, 1);

        game.getField().add(cageCross, 0, 2);
        game.getField().add(cageCross, 1, 2);
        game.getField().add(cageZero, 2, 2);
        game.getField().add(cageCross, 3, 2);
        game.getField().add(cageZero, 4, 2);

        game.getField().add(cageZero, 0, 3);
        game.getField().add(cageZero, 1, 3);
        game.getField().add(cageCross, 2, 3);
        game.getField().add(cageCross, 3, 3);
        game.getField().add(cageZero, 4, 3);

        game.getField().add(cageCross, 0, 4);
        game.getField().add(cageCross, 1, 4);
        game.getField().add(cageCross, 2, 4);
        game.getField().add(cageCross, 3, 4);
        game.getField().add(cageZero, 4, 4);

        boolean result = game.win(4, 4);
        assertThat(result, is(true));
    }

    /**
     * Test4 Diagonal from down left.
     */
    @Test
    public void whenThreeTickDiagonalDownLeftThenTrue() {
        Ticktacktoe game = new Ticktacktoe(5);
        Cage cageZero = new Cage(ZERO);
        Cage cageCross = new Cage(CROSS);

        game.getField().add(cageCross, 0, 0);
        game.getField().add(cageCross, 1, 0);
        game.getField().add(cageZero, 2, 0);
        game.getField().add(cageCross, 3, 0);
        game.getField().add(cageZero, 4, 0);

        game.getField().add(cageCross, 0, 1);
        game.getField().add(cageZero, 1, 1);
        game.getField().add(cageCross, 2, 1);
        game.getField().add(cageCross, 3, 1);
        game.getField().add(cageCross, 4, 1);

        game.getField().add(cageZero, 0, 2);
        game.getField().add(cageCross, 1, 2);
        game.getField().add(cageZero, 2, 2);
        game.getField().add(cageCross, 3, 2);
        game.getField().add(cageZero, 4, 2);

        game.getField().add(cageZero, 0, 3);
        game.getField().add(cageZero, 1, 3);
        game.getField().add(cageCross, 2, 3);
        game.getField().add(cageCross, 3, 3);
        game.getField().add(cageZero, 4, 3);

        game.getField().add(cageCross, 0, 4);
        game.getField().add(cageCross, 1, 4);
        game.getField().add(cageCross, 2, 4);
        game.getField().add(cageCross, 3, 4);
        game.getField().add(cageZero, 4, 4);

        boolean result = game.win(2, 0);
        assertThat(result, is(true));
    }
}