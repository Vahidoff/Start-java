package ru.job4j.tracker;

import org.junit.Test;

import java.sql.SQLException;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
/**
 * Test.
 *
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class TrackerTest {
    /**
     * Test1 findAll.
     */
    @Test
    public void whenAddNewItemThenTrackerHasSameItem() throws SQLException {
        Tracker tracker = new Tracker();
        tracker.connectDb();
        Item item = new Item("test1", "testDescription", 123L, "testCommit");
        tracker.add(item);

        Item result = tracker.findAll()[0];

        assertThat(result.getId(), is(item.getId()));
        tracker.disconnectDb();
    }
    /**
     * Test2 findAll.
     */
    @Test
    public void whenAddNewItemThenTrackerHasSameItem2() throws SQLException {
        Tracker tracker = new Tracker();
        tracker.connectDb();
        Item item = new Item("test1", "testDescription", 123L, "testCommit");
        Item bid = new Item("test2", "testDescription2", 1234L, "testCommit2");
        tracker.add(item);
        tracker.add(bid);
        assertThat(tracker.findAll()[1].getId(), is(bid.getId()));
        tracker.disconnectDb();
    }
    /**
     * Test3 update.
     */
    @Test
    public void whenAddAnotherItemThenTrackerReplacement() throws SQLException {
        Tracker tracker = new Tracker();
        tracker.connectDb();
        Item item = new Item("test1", "testDescription", 123L, "testCommit");
        Item bid = new Item("test2", "testDescription2", 1234L, "testCommit2");
        tracker.add(item);
        tracker.add(bid);
        bid.setComment("updateCommit");
        tracker.update(bid);
        assertThat(tracker.findAll()[1].getId(), is(bid.getId()));
        tracker.disconnectDb();
    }
    /**
     * Test4 delete.
     */
    @Test
    public void whenAddItemThenTrackerReplacesByZero() throws SQLException {
        Tracker tracker = new Tracker();
        tracker.connectDb();
        Item item = new Item("test1", "testDescription", 123L, "testCommit");
        Item bid = new Item("test2", "testDescription2", 1234L, "testCommit2");
        Item claim = new Item("test3", "testDescription3", 12345L, "testCommit3");
        tracker.add(item);
        tracker.add(bid);
        tracker.add(claim);
        String id = bid.getId();
        tracker.delete(bid);
        assertThat(tracker.findById(id), is((Item) null));
        tracker.disconnectDb();
    }
    /**
     * Test5 findById.
     */
    @Test
    public void whenAddItemIdThenReturnTracker() throws SQLException {
        Tracker tracker = new Tracker();
        tracker.connectDb();
        Item item = new Item("test1", "testDescription", 123L, "testCommit");
        Item bid = new Item("test2", "testDescription2", 1234L, "testCommit2");
        Item claim = new Item("test3", "testDescription3", 12345L, "testCommit3");
        tracker.add(item);
        tracker.add(bid);
        tracker.add(claim);
        assertThat(tracker.findById(bid.getId()).getComment(), is(bid.getComment()));
        tracker.disconnectDb();
    }
    /**
     * Test6 findByName.
     */
    @Test
    public void whenAddItemNameThenReturnAllTrackerName() throws SQLException {
        Tracker tracker = new Tracker();
        tracker.connectDb();
        Item item = new Item("key", "testDescription", 123L, "testCommit");
        Item bid = new Item("test2", "testDescription2", 1234L, "testCommit2");
        Item claim = new Item("key", "testDescription3", 12345L, "testCommit3");
        Item proposal = new Item("key", "testDescription4", 123456L, "testCommit4");
        tracker.add(item);
        tracker.add(bid);
        tracker.add(claim);
        tracker.add(proposal);

        Long[] solid = {item.getCreate(), claim.getCreate(), proposal.getCreate()};
        Long[] result = new Long[3];
        int i = 0;
        for (Item temp : tracker.findByName("key")) {
            result[i++] = temp.getCreate();
        }

        assertThat(result, is(solid));
        tracker.disconnectDb();
    }
}
