CREATE TABLE items (
  id          SERIAL PRIMARY KEY,
  id_item     VARCHAR(20) NOT NULL,
  name        VARCHAR(50) NOT NULL,
  description TEXT,
  create_long BIGINT      NOT NULL DEFAULT 987456,
  comment     VARCHAR(200)
);