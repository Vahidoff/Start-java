package ru.job4j.models;

import javax.persistence.*;

@Entity
@Table(name = "gearbox")
public class Gearbox {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "name")
    private String name;

    @Column(name = "condition")
    private String condition;

    public Gearbox(int id, String name, String condition) {
        this.id = id;
        this.name = name;
        this.condition = condition;
    }

    public Gearbox() { }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }
}
