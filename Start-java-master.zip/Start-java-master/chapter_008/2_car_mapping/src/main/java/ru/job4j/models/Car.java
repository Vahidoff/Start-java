package ru.job4j.models;

import javax.persistence.*;
import java.sql.Date;
import java.util.List;

@Entity
@Table(name = "automobile")
public class Car {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private long id;

    @Column(name = "name")
    private String name;

    @ManyToOne
    @JoinColumn(name = "gearbox")
    private Gearbox gearbox;

    @ManyToOne
    @JoinColumn(name = "transmission")
    private Transmission transmission;

    @ManyToOne
    @JoinColumn(name = "engine")
    private Engine engine;

    @Column(name = "release_date")
    private Date releaseDate;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "car")
    private List<CarOptions> options;

    public Car() { }

    /**
     * Constructor with parameter.
     */
    public Car(long id) {
        this.id = id;
    }

    /**
     * Constructor with parameters.
     */
    public Car(String name, Gearbox gearbox, Transmission transmission, Engine engine,
               Date releaseDate, List<CarOptions> options) {
        this.name = name;
        this.gearbox = gearbox;
        this.transmission = transmission;
        this.engine = engine;
        this.releaseDate = releaseDate;
        this.options = options;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Gearbox getGearbox() {
        return gearbox;
    }

    public void setGearbox(Gearbox gearbox) {
        this.gearbox = gearbox;
    }

    public Transmission getTransmission() {
        return transmission;
    }

    public void setTransmission(Transmission transmission) {
        this.transmission = transmission;
    }

    public Engine getEngine() {
        return engine;
    }

    public void setEngine(Engine engine) {
        this.engine = engine;
    }

    public Date getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(Date releaseDate) {
        this.releaseDate = releaseDate;
    }

    public List<CarOptions> getOptions() {
        return options;
    }

    public void setOptions(List<CarOptions> options) {
        this.options = options;
    }

    @Override
    public String toString() {
        return "Car{"
                + "id=" + id
                + ", name='" + name + '\''
                + ", gearbox='" + gearbox.getName() + '\''
                + ", transmission='" + transmission.getName() + '\''
                + ", engine=" + engine.getName()
                + ", release date=" + releaseDate
                + ", options = " + options
                + '}';
    }
}
