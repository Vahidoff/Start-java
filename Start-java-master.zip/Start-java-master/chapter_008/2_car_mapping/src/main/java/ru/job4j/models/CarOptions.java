package ru.job4j.models;

import javax.persistence.*;

@Entity
@Table(name = "options")
public class CarOptions {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "name")
    private String name;


    @ManyToOne
    @JoinColumn(name = "id_car")
    private Car car;

    public CarOptions(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public CarOptions() {
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "CarOptions{"
                + "id=" + id
                + ", name='" + name + '\''
                + '}';
    }
}
