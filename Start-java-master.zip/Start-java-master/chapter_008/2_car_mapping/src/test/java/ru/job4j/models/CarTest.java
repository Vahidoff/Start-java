package ru.job4j.models;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.junit.*;

import java.sql.Date;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 * Test class.
 */
public class CarTest {

    private static SessionFactory factory;

    @BeforeClass
    public static void init() {
        factory = new Configuration().configure().buildSessionFactory();
    }

    @AfterClass
    public static void destroy() {
        factory.close();
    }

    @Before
    public void addCars() {
        Session session = factory.openSession();
        session.beginTransaction();

        Engine engine = new Engine();
        engine.setName("engine" + this.temp());
        engine.setCondition("newest");

        Transmission transmission = new Transmission();
        transmission.setName("transmission" + this.temp());
        transmission.setCondition("second hand");

        Gearbox gearbox = new Gearbox();
        gearbox.setName("gearbox" + this.temp());
        gearbox.setCondition("old");

        CarOptions optionsOne = new CarOptions();
        optionsOne.setName("air conditioner " + this.temp());
        CarOptions optionsSecond = new CarOptions();
        optionsSecond.setName("leather interior " + this.temp());
        CarOptions optionsThird = new CarOptions();
        optionsThird.setName("the panoramic sunroof" + this.temp());

        Car car = new Car();
        car.setName("car" + this.temp());
        car.setEngine(engine);
        car.setTransmission(transmission);
        car.setGearbox(gearbox);
        car.setReleaseDate(new Date(System.currentTimeMillis()));

        optionsOne.setCar(car);
        optionsSecond.setCar(car);
        optionsThird.setCar(car);
        List<CarOptions> options = Arrays.asList(optionsOne, optionsSecond, optionsThird);

        session.save(transmission);
        session.save(engine);
        session.save(gearbox);
        session.save(optionsOne);
        session.save(optionsSecond);
        session.save(optionsThird);

        car.setOptions(options);

        session.save(car);

        session.getTransaction().commit();
        session.close();

    }

    private String temp() {
        Random rnd = new Random(System.currentTimeMillis());
        return String.valueOf(System.currentTimeMillis() + rnd.nextInt()).substring(2, 8);
    }

    @Test
    public void carTest() {
        Session session = factory.openSession();
        session.beginTransaction();

        List<Car> cars = session.createQuery("from Car").list();

        System.out.println(cars);

        session.close();

    }
}
