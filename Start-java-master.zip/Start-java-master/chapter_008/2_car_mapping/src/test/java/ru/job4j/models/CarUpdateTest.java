package ru.job4j.models;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 * Test class.
 */
public class CarUpdateTest {

    private static SessionFactory factory;

    @BeforeClass
    public static void init() {
        factory = new Configuration().configure().buildSessionFactory();
    }

    @AfterClass
    public static void destroy() {
        factory.close();
    }

    private String temp() {
        Random rnd = new Random(System.currentTimeMillis());
        return String.valueOf(System.currentTimeMillis() + rnd.nextInt()).substring(2, 8);
    }

    private int number;

    @Before
    public void addCars() {
        Session session = factory.openSession();
        session.beginTransaction();

        Query query = session.createQuery("from Car as i where i.id= :id");
        Random rnd = new Random(System.currentTimeMillis());
        number = 1 + rnd.nextInt(6);
        query.setParameter("id", (long) number);
        List<Car> list = query.list();
        Car car = list.get(0);

        CarOptions optionsOne = new CarOptions();
        optionsOne.setName("air conditioner update" + this.temp());
        optionsOne.setCar(car);
        CarOptions optionsSecond = new CarOptions();
        optionsSecond.setName("leather interior update" + this.temp());
        optionsSecond.setCar(car);
        CarOptions optionsThird = new CarOptions();
        optionsThird.setName("the panoramic sunroof update" + this.temp());
        optionsThird.setCar(car);
        List<CarOptions> options = Arrays.asList(optionsOne, optionsSecond, optionsThird);

        session.save(optionsOne);
        session.save(optionsSecond);
        session.save(optionsThird);

        car.setOptions(options);

        session.update(car);

        session.getTransaction().commit();
        session.close();

    }


    @Test
    public void carUpdate() {
        Session session = factory.openSession();


        Query query = session.createQuery("from Car as i where i.id= :id");
        query.setParameter("id", (long) number);
        List<Car> list = query.list();
        Car car = list.get(0);

        System.out.println(car);

        session.close();
    }
}
