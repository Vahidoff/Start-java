package ru.job4j.service;

import ru.job4j.data.Item;
import ru.job4j.command.ItemDataCommand;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Update the item from done.
 */
public class UpdateServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        Item item = new ItemDataCommand(Integer.valueOf(req.getParameter("id"))).getItem();
        item.setDone(!item.isDone());

        new ItemDataCommand(item).create();
    }
}
