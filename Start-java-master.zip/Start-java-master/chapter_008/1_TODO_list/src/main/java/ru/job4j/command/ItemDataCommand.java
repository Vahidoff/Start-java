package ru.job4j.command;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import ru.job4j.data.Item;
import ru.job4j.data.ItemDB;

import java.util.List;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version $Id$
 * @since 2018
 */
public class ItemDataCommand {

    private final SessionFactory factory = new Configuration().
            configure().
            buildSessionFactory();

    private ItemDB itemDB = new ItemDB();
    private Item item;
    private int id;

    public ItemDataCommand(Item item) {
        this.item = item;
    }

    public ItemDataCommand(int id) {
        this.id = id;
    }

    public ItemDataCommand() {

    }

    public void create() {
        Session session = this.createSession();
        this.itemDB.createItem(this.item, session);
        this.closeCommitSession(session);
    }

    public List<Item> getAllItems() {
        Session session = this.createSession();
        List<Item> items = this.itemDB.getAll(session);
        this.closeCommitSession(session);
        return items;
    }

    public void delete() {
        Session session = this.createSession();
        this.itemDB.deleteById(this.id, session);
        this.closeCommitSession(session);
    }

    public Item getItem() {
        Session session = this.createSession();
        Item item = this.itemDB.getById(this.id, session);
        this.closeCommitSession(session);
        return item;
    }

    public void finalize() throws Throwable {
        this.factory.close();
    }

    private Session createSession() {
        Session session = this.factory.openSession();
        session.beginTransaction();
        return session;
    }

    private void closeCommitSession(Session session) {
        session.getTransaction().commit();
        session.close();
    }

}
