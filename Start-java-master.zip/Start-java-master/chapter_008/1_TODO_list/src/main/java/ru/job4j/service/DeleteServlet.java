package ru.job4j.service;

import ru.job4j.command.ItemDataCommand;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class DeleteServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        new ItemDataCommand(Integer.parseInt(request.getParameter("id"))).delete();
        response.sendRedirect("index.html");
    }
}
