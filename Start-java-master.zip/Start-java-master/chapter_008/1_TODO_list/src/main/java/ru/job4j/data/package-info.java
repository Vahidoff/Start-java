/**
 * @author Alexandr Vahidov mailto: mango777555@hotmail.com
 * @version $Id$
 * @since 0.1
 */
package ru.job4j.data;