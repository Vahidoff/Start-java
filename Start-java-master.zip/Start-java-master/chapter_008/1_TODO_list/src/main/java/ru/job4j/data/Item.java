package ru.job4j.data;

/**
 * This class stores and has getters and setters.
 */
public class Item {

    private long id;

    private String desc;

    private boolean done;

    private String createDate;

    public Item(String desc, String date, boolean done) {
        this.desc = desc;
        this.createDate = date;
        this.done = done;
    }

    public Item() {
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public void setDone(boolean done) {
        this.done = done;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public long getId() {
        return id;
    }

    public String getDesc() {
        return desc;
    }

    public boolean isDone() {
        return done;
    }

    public String getCreateDate() {
        return createDate;
    }
}
