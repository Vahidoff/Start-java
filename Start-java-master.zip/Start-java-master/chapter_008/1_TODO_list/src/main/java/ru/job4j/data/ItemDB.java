package ru.job4j.data;

import org.hibernate.Session;
import org.hibernate.query.Query;

import java.util.List;

/**
 * Hibernate for database and session.
 */
public class ItemDB {

    public void createItem(final Item item, Session session) {
        session.saveOrUpdate(item);
    }

    public List<Item> getAll(Session session) {
        List<Item> items = session.createQuery("from Item order by id asc")
                .setReadOnly(true).list();
        return items;
    }

    public Item getById(int id, Session session) {
        Query query = session.createQuery("from Item as i where i.id= :id");
        query.setParameter("id", (long) id);
        query.setReadOnly(true);
        List<Item> result = query.list();
        return result.get(0);
    }

    public void deleteById(int id, Session session) {
        Item item = new Item();
        item.setId(id);
        session.delete(item);
    }
}
