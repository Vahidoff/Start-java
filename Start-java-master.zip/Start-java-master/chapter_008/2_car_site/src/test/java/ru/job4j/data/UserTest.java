package ru.job4j.data;

import org.junit.Test;
import ru.job4j.RandomString;
import ru.job4j.data.dbtools.DbManager;
import ru.job4j.data.models.User;

import java.util.Optional;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

/**
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 2018
 */
public class UserTest {

    private final DbManager dBManager = new DbManager();

    /**
     * class DbManager, methods: createUser, getUserByLoginAndPassword.
     */
    @Test
    public void createUserTest() {
        RandomString rnds = new RandomString(5);
        String login = rnds.nextString();
        RandomString rnd = new RandomString(5);
        String string = rnd.nextString();

        User user = new User(login, string, rnds.nextString(),
                rnds.nextString(), rnds.nextString());
        this.dBManager.createUser(user);

        User verification = new User();
        Optional<User> user1 = this.dBManager
                .getUserByLoginAndPassword(login, string);
        if (user1.isPresent()) {
            verification = user1.get();
        }

        System.out.format("name: %s  password: %s %n", user.getName(), user.getPassword());
        System.out.format("name: %s  password: %s", verification.getName(), verification.getPassword());
        assertTrue(user.getId() == verification.getId());
        assertThat(user.getPassword(), is(verification.getPassword()));

    }
}
