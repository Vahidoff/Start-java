package ru.job4j.data;

import org.junit.Test;
import ru.job4j.RandomString;
import ru.job4j.data.dbtools.DbManager;
import ru.job4j.data.models.Ad;
import ru.job4j.data.models.Car;
import ru.job4j.data.models.Foto;
import ru.job4j.data.models.User;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertTrue;

/**
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 2018
 */
public class AdTest {

    private static final String DEFAULT = "Choose all";

    private static final String BMW = "BMW";
    private static final String AUDI = "Audi";
    private static final String FIAT = "Fiat";
    /**
     * class DbManager, methods: createAdvertisement, getAll.
     */
    @Test
    public void getAllTest() {
        final DbManager dBManager = new DbManager();

        RandomString rnd = new RandomString(5);
        String string = rnd.nextString();

        User userOne = new User(string, string, string, string, string);
        dBManager.createUser(userOne);
        User userTwo = new User(rnd.nextString(), rnd.nextString(), rnd.nextString(), rnd.nextString(), rnd.nextString());
        dBManager.createUser(userTwo);
        User userThree = new User(rnd.nextString(), rnd.nextString(), rnd.nextString(), rnd.nextString(), rnd.nextString());
        dBManager.createUser(userThree);
        User userFour = new User(rnd.nextString(), rnd.nextString(), rnd.nextString(), rnd.nextString(), rnd.nextString());
        dBManager.createUser(userFour);
        User userFive = new User(rnd.nextString(), rnd.nextString(), rnd.nextString(), rnd.nextString(), rnd.nextString());
        dBManager.createUser(userFive);

        Car first = new Car(BMW, string, string, 210f, 2010);
        Car second = new Car(BMW, string, string, 215f, 2007);
        Car third = new Car(AUDI, string, string, 217f, 2010);
        Car fourth = new Car(AUDI, string, string, 255f, 2010);
        Car fifth = new Car(FIAT, string, string, 77f, 2015);
        List<Car> expectedAudi = Arrays.asList(third, fourth);
        List<Car> expected2010 = Arrays.asList(first, third, fourth);

        dBManager.createAdvertisement(rnd.nextString(), userOne, first, new Foto(rnd.nextString()));
        dBManager.createAdvertisement(rnd.nextString(), userTwo, second, new Foto(rnd.nextString()));
        dBManager.createAdvertisement(rnd.nextString(), userThree, third, new Foto(rnd.nextString()));
        dBManager.createAdvertisement(rnd.nextString(), userFour, fourth, new Foto(rnd.nextString()));
        dBManager.createAdvertisement(rnd.nextString(), userFive, fifth, new Foto(rnd.nextString()));

        List<Ad> declarations = dBManager.getAll(AUDI, DEFAULT);
        List<Ad> dec2010 = dBManager.getAll(DEFAULT, "2010");

        List<Car> audi = new ArrayList<>();
        for (Ad declaration : declarations) {
            audi.add(declaration.getCar());
        }

        List<Car> car2010 = new ArrayList<>();
        for (Ad declaration : dec2010) {
            car2010.add(declaration.getCar());
        }

        System.out.println(expectedAudi);
        System.out.println(audi);
        assertTrue(expectedAudi.equals(audi));
        assertTrue(expected2010.equals(car2010));
    }

    /**
     * class DbManager, methods: saveDeclaration, getDeclarationById.
     */
    @Test
    public void saveDeclarationTest() {
        final DbManager dBManager = new DbManager();

        RandomString rnd = new RandomString(5);
        String string = rnd.nextString();

        User userOne = new User(string, string, string, string, string);
        dBManager.createUser(userOne);

        Car second = new Car(BMW, string, string, 215f, 2007);

        dBManager.createAdvertisement(rnd.nextString(), userOne, second, new Foto(rnd.nextString()));
        Ad declaration = dBManager.getDeclarationById(1);

        assertTrue(!declaration.isSold());

        declaration.setSold(true);
        dBManager.saveDeclaration(declaration);

        List<Ad> list = dBManager.getAll(DEFAULT, DEFAULT);
        Ad expected = list.get(0);

        assertTrue(expected.isSold());
    }
}
