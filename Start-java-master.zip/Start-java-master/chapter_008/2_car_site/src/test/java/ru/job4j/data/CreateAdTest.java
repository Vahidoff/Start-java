package ru.job4j.data;

import org.junit.Test;
import ru.job4j.RandomString;
import ru.job4j.data.dbtools.DbManager;
import ru.job4j.data.models.Ad;
import ru.job4j.data.models.Car;
import ru.job4j.data.models.Foto;
import ru.job4j.data.models.User;

import java.util.List;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

public class CreateAdTest {

    private static final String DEFAULT = "Choose all";

    /**
     * class DbManager, methods: createAdvertisement, getAll.
     */
    @Test
    public void createAdvertisementTest() {
        final DbManager dBManager = new DbManager();

        RandomString rnds = new RandomString(5);
        String login = rnds.nextString();
        RandomString rnd = new RandomString(5);
        String string = rnd.nextString();
        String description = rnds.nextString();



        User user = new User(login, string, rnds.nextString(),
                rnds.nextString(), rnds.nextString());
        dBManager.createUser(user);

        Car car = new Car(login, string, rnd.nextString(), 75f, 2017);
        Foto photo = new Foto(string);
        dBManager.createAdvertisement(description, user, car, photo);

        List<Ad> list = dBManager.getAll(DEFAULT, DEFAULT);
        Ad expected = list.get(0);

        System.out.format("description: %s, expected: %s %n", description, expected.getDesc());
        assertThat(description, is(expected.getDesc()));
        assertThat(user, is(expected.getUser()));
        System.out.format("user: %s %n expected: %s %n", user, expected.getUser());
        assertThat(car, is(expected.getCar()));
        assertThat(photo, is(expected.getFoto()));
    }
}
