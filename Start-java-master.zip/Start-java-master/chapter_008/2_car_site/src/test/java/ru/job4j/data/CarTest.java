package ru.job4j.data;

import org.junit.Test;
import ru.job4j.RandomString;
import ru.job4j.data.dbtools.DbManager;
import ru.job4j.data.models.Car;
import ru.job4j.data.models.Foto;
import ru.job4j.data.models.User;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertTrue;

/**
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 2018
 */
public class CarTest {

    private final DbManager dBManager = new DbManager();

    private static final String BMW = "BMW";
    private static final String AUDI = "Audi";
    private static final String FIAT = "Fiat";

    /**
     * class DbManager, methods: createAdvertisement, getCars.
     */
    @Test
    public void getCarsTest() {
        RandomString rnd = new RandomString(5);
        String string = rnd.nextString();

        User userOne = new User(string, string, string, string, string);
        this.dBManager.createUser(userOne);
        User userThree = new User(rnd.nextString(), rnd.nextString(), rnd.nextString(), rnd.nextString(), rnd.nextString());
        this.dBManager.createUser(userThree);
        User userFive = new User(rnd.nextString(), rnd.nextString(), rnd.nextString(), rnd.nextString(), rnd.nextString());
        this.dBManager.createUser(userFive);

        Car first = new Car(BMW, string, string, 210f, 2010);
        Car third = new Car(AUDI, string, string, 217f, 2010);
        Car fifth = new Car(FIAT, string, string, 77f, 2015);
        List<Car> expectedCars = Arrays.asList(first, third, fifth);

        this.dBManager.createAdvertisement(rnd.nextString(), userOne, first, new Foto(rnd.nextString()));
        this.dBManager.createAdvertisement(rnd.nextString(), userThree, third, new Foto(rnd.nextString()));
        this.dBManager.createAdvertisement(rnd.nextString(), userFive, fifth, new Foto(rnd.nextString()));

        List<Car> cars = this.dBManager.getCars();

        assertTrue(expectedCars.equals(cars));
    }
}
