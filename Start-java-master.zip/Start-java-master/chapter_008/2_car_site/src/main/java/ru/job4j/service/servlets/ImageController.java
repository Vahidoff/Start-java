package ru.job4j.service.servlets;

import ru.job4j.data.dbtools.DbManager;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;

/**
 * This controllers gives to the site image.
 *
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @since 25.12.2018.
 */
public class ImageController extends HttpServlet {

    private static final String IMAGES = "C:/Data/images/";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        DbManager manager = (DbManager) req.getServletContext().getAttribute("dBManager");
        int imageId = Integer.parseInt(req.getPathInfo().substring(1));
        resp.setContentType("image/jpeg");
        File file = new File(IMAGES + manager.getFileName((long) imageId));
        BufferedImage image = ImageIO.read(file);
        try (OutputStream out = resp.getOutputStream()) {
            ImageIO.write(image, "jpg", out);
        }
    }
}
