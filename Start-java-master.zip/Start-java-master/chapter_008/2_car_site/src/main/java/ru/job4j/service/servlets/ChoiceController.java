package ru.job4j.service.servlets;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class ChoiceController extends HttpServlet {

    private static final String DEFAULT = "Choose all";

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String brand = DEFAULT;
        if (req.getParameter("brand") != null) {
            brand = req.getParameter("brand");
        }
        String year = DEFAULT;
        if (req.getParameter("year") != null) {
            year = req.getParameter("year");
        }

        HttpSession session = req.getSession();

        session.setAttribute("brand", brand);
        session.setAttribute("year", year);
        resp.sendRedirect("index.html");

    }
}
