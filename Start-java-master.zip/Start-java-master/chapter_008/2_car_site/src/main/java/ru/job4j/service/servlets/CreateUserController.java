package ru.job4j.service.servlets;

import ru.job4j.data.dbtools.DbManager;
import ru.job4j.data.models.User;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Optional;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class CreateUserController extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String userLogin = req.getParameter("login");
        String userPassword =  req.getParameter("password");
        String name = req.getParameter("name");
        String surname = req.getParameter("surname");
        String tel = req.getParameter("tel_number");

        if (!userLogin.equals("") & !userPassword.equals("") & !name.equals("") & !tel.equals("")) {
            DbManager manager = (DbManager) req.getServletContext().getAttribute("dBManager");
            Optional<User> userOptional = manager.getUserByLoginAndPassword(userLogin, userPassword);
            if (!userOptional.isPresent()) {
                HttpSession session = req.getSession();
                manager.createUser(new User(userLogin, userPassword, name, surname, tel));
                Optional<User> userl = manager.getUserByLoginAndPassword(userLogin, userPassword);
                User user = userl.get();
                session.setAttribute("user", user);
                session.removeAttribute("brand");
                session.removeAttribute("year");

                resp.sendRedirect("index.html");
            }
        } else {
            resp.sendRedirect("login.html");
        }
    }
}
