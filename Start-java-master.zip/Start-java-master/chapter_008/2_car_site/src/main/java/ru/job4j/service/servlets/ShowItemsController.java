package ru.job4j.service.servlets;

import com.fasterxml.jackson.databind.ObjectMapper;
import ru.job4j.data.dbtools.DbManager;
import ru.job4j.data.models.Ad;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version $Id$
 * @since 2017
 */
public class ShowItemsController extends HttpServlet {

    private static final String DEFAULT = "Choose all";
    /**
     * Returns all declarations.
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        DbManager manager = (DbManager) req.getServletContext().getAttribute("dBManager");

        final HttpSession session = req.getSession();
        String brand = (String) session.getAttribute("brand");
        if (brand == null) {
            brand = DEFAULT;
        }
        String year = DEFAULT;
        if (session.getAttribute("year") != null) {
            year = String.valueOf(session.getAttribute("year"));
        }

        resp.setContentType("text/json");
        resp.setCharacterEncoding("UTF-8");
        PrintWriter writer = resp.getWriter();
        ObjectMapper mapper = new ObjectMapper();

        List<Ad> ads = manager.getAll(brand, year);
        writer.append(mapper.writeValueAsString(ads));
        writer.flush();
    }

}
