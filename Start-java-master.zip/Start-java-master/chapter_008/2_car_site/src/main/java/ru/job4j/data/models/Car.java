package ru.job4j.data.models;

import java.util.Objects;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Car {

    private long id;

    private String brand;

    private String model;

    private String transmission;

    private float engineCapacity;

    private int year;

    /**
     * Default constructor.
     */
    public Car() {

    }

    /**
     * Constructor with parameter.
     */
    public Car(long id) {
        this.id = id;
    }

    /**
     * Constructor with parameters.
     */
    public Car(String brand, String model, String transmission, float engineCapacity, int year) {
        this.brand = brand;
        this.model = model;
        this.transmission = transmission;
        this.engineCapacity = engineCapacity;
        this.year = year;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getTransmission() {
        return transmission;
    }

    public void setTransmission(String transmission) {
        this.transmission = transmission;
    }

    public float getEngineCapacity() {
        return engineCapacity;
    }

    public void setEngineCapacity(float engineCapacity) {
        this.engineCapacity = engineCapacity;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    @Override
    public String toString() {
        return "Car{"
                + "id=" + id
                + ", brand='" + brand + '\''
                + ", model='" + model + '\''
                + ", transmission='" + transmission + '\''
                + ", engineCapacity=" + engineCapacity
                + ", year=" + year
                + '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj == null || obj.getClass() != this.getClass()) {
            return false;
        }
        Car car = (Car) obj;
        return this.id == car.id
                && Objects.equals(this.brand, car.brand)
                && Objects.equals(this.model, car.model)
                && Objects.equals(this.transmission, car.transmission)
                && Objects.equals(this.engineCapacity, car.engineCapacity)
                && this.year == car.year;
    }

    @Override
    public int hashCode() {
        int result = (int) (id + this.engineCapacity + this.year);
        result = 31 * result
                + (this.brand != null ? this.brand.hashCode() : 0)
                + (this.model != null ? this.brand.hashCode() : 0)
                + (this.transmission != null ? this.transmission.hashCode() : 0);
        return result;
    }
}
