package ru.job4j.service.listeners;

import ru.job4j.data.dbtools.DbManager;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

/**
 * Writes DbManager instance in servletContext when servlet is created.
 * Closes hibernate session factory that uses DbManager when application is closing.
 */
public class AppContextListener implements ServletContextListener {
    /**
     * Writes DbManager instance in servletContext when servlet is created.
     */
    @Override
    public void contextInitialized(ServletContextEvent event) {
        ServletContext ctx = event.getServletContext();
        DbManager dBManager = new DbManager();
        ctx.setAttribute("dBManager", dBManager);
    }

    /**
     * Closes hibernate session factory that uses DbManager when application is closing.
     */
    @Override
    public void contextDestroyed(ServletContextEvent event) {
        ServletContext ctx = event.getServletContext();
        DbManager dBManager = (DbManager) ctx.getAttribute("dBManager");
        dBManager.closeSessionFactory();
    }
}
