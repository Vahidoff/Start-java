package ru.job4j.data.models;

import org.hibernate.Hibernate;
import org.hibernate.proxy.HibernateProxy;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class User {

    private long id;

    private String login;

    private String password;

    private String name;

    private String surname;

    private String telNumber;

    private List<Ad> adList;

    /**
     * Default constructor.
     */
    public User() {

    }

    /**
     * Constructor with parameter.
     */
    public User(long id) {
        this.id = id;
    }

    /**
     * Constructor with parameter.
     */
    public User(String login, String password, String name, String surname,
                String telNumber) {
        this.login = login;
        this.password = password;
        this.name = name;
        this.surname = surname;
        this.telNumber = telNumber;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getTelNumber() {
        return telNumber;
    }

    public void setTelNumber(String telNumber) {
        this.telNumber = telNumber;
    }

    public List<Ad> getAdList() {
        List<Ad> result = null;
        if (this.adList != null && this.adList.size() != 0) {
            result = new ArrayList<>();
            for (Ad ad : adList) {
                if (ad instanceof HibernateProxy) {
                    Hibernate.initialize(ad);
                    ad = (Ad) ((HibernateProxy) ad)
                            .getHibernateLazyInitializer()
                            .getImplementation();
                    result.add(ad);
                }
            }
        }
        return result;
    }

    public void setAdList(List<Ad> adList) {
        this.adList = adList;
    }

    @Override
    public String toString() {

        return "User{"
                + "id=" + id
                + ", login='" + login + '\''
                + ", password='" + password + '\''
                + ", name='" + name + '\''
                + ", surname='" + surname + '\''
                + ", telNumber='" + telNumber + '\''
                + '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj == null || obj.getClass() != this.getClass()) {
            return false;
        }
        User user = (User) obj;
        return this.id == user.id
                && Objects.equals(this.login, user.login)
                && Objects.equals(this.password, user.password)
                && Objects.equals(this.telNumber, user.telNumber);
    }

    @Override
    public int hashCode() {
        int result = (int) (id);
        result = 31 * result
                + (this.name != null ? this.name.hashCode() : 0)
                + (this.surname != null ? this.surname.hashCode() : 0)
                + (this.login != null ? this.login.hashCode() : 0)
                + (this.password != null ? this.password.hashCode() : 0)
                + (this.telNumber != null ? this.telNumber.hashCode() : 0);
        if (this.adList != null) {
            for (Ad declaration : this.adList) {
                result = (int) (declaration.getUser().hashCode()
                           + declaration.getCar().hashCode()
                           + declaration.getFoto().hashCode()
                           + declaration.getId()
                           + Long.parseLong(String.valueOf(declaration.getCreateDate()))
                           + (declaration.getDesc() != null ? declaration.getDesc().hashCode() : 0));
            }
        }
        return result;
    }
}
