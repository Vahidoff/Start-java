package ru.job4j.data.models;

import java.util.Objects;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Foto {

    private long id;

    private String name;

    public Foto(String name) {
        this.name = name;
    }

    public Foto() {
    }

    public Foto(long id) {
        this.id = id;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj == null || obj.getClass() != this.getClass()) {
            return false;
        }
        Foto photo = (Foto) obj;
        return this.id == photo.id
                && Objects.equals(this.name, photo.name);
    }

    @Override
    public int hashCode() {
        int result = (int) (id);
        result = 31 * result
                + (this.name != null ? this.name.hashCode() : 0);
        return result;
    }
}
