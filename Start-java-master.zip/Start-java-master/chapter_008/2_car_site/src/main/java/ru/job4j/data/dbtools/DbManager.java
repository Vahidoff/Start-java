package ru.job4j.data.dbtools;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.job4j.data.models.Ad;
import ru.job4j.data.models.Car;
import ru.job4j.data.models.Foto;
import ru.job4j.data.models.User;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class DbManager {

    /**
     * Hibernate session factory instance.
     */
    private final SessionFactory factory = HibernateUtil.getSessionFactory();
    /**
     * Logger for database errors.
     */
    private static final Logger LOG = LoggerFactory.getLogger(DbManager.class);

    private static final String DEFAULT = "Choose all";

    public void createAdvertisement(String description, User user, Car car, Foto foto) {
        Session session = this.factory.openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            long carId = (long) session.save(car);
            long fotoId = (long) session.save(foto);
            long userId = user.getId();
            Ad ad = new Ad(description, new User(userId), new Car(carId), new Foto(fotoId));
            session.save(ad);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            LOG.error(e.getMessage(), e);
        } finally {
            session.close();
        }
    }

    public long saveDeclaration(Ad declaration) {
        long result = -1;
        Session session = this.factory.openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            session.saveOrUpdate(declaration);
            result = declaration.getId();
            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            LOG.error(e.getMessage(), e);
        } finally {
            session.close();
        }
        return result;
    }

    public String getFileName(Long id) {
        String name = null;
        Session session = this.factory.openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("SELECT F.name FROM Foto F WHERE F.id =:code");
            query.setParameter("code", id);
            name = (String) query.uniqueResult();
            tx.rollback();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            LOG.error(e.getMessage(), e);
        } finally {
            session.close();
        }
        return name;
    }

    public Ad getDeclarationById(int id) {
        Session session = this.factory.openSession();
        Transaction tx = null;
        List<Ad> declarations = new  ArrayList<>();
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("from Ad where id=:id");
            query.setParameter("id", (long) id);
            declarations = query.list();
            tx.rollback();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            LOG.error(e.getMessage(), e);
        } finally {
            session.close();
        }
        return declarations.get(0);
    }

    public List<Ad> getAll(String brand, String year) {
        List<Ad> result = new ArrayList<>();
        if (Objects.equals(brand, DEFAULT) & Objects.equals(year, DEFAULT)) {
            result = this.getAllDeclaration();
        } else {
            Session session = this.factory.openSession();
            Transaction tx = null;
            Query query;
            try {
                tx = session.beginTransaction();
                if (Objects.equals(brand, DEFAULT)) {
                    query = session.createQuery("FROM Ad as a WHERE a.car.year = :year");
                    query.setParameter("year", Integer.valueOf(year));
                } else {
                    if (Objects.equals(year, DEFAULT)) {
                        query = session.createQuery("FROM Ad as a WHERE a.car.brand = :brand");
                        query.setParameter("brand", brand);
                    } else {
                        query = session.createQuery("FROM Ad as a WHERE a.car.brand = :brand "
                                + "AND a.car.year = :year");
                        query.setParameter("brand", brand);
                        query.setParameter("year", Integer.valueOf(year));
                    }
                }
                query = query.setReadOnly(true);
                result = query.list();
                tx.rollback();
            } catch (Exception e) {
                if (tx != null) {
                    tx.rollback();
                }
                LOG.error(e.getMessage(), e);
            } finally {
                session.close();
            }
        }
        return result;
    }

    private List<Ad> getAllDeclaration() {
        List<Ad> ads = null;
        Session session = this.factory.openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            ads = session.createQuery("FROM Ad").list();
            tx.commit();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            LOG.error(e.getMessage(), e);
        } finally {
            session.close();
        }
        return ads;
    }

    public Optional<User> getUserByLoginAndPassword(String login, String password) {
        Optional<User> result = Optional.empty();
        Session session = this.factory.openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("FROM User WHERE login =:log AND password =:pass");
            query.setParameter("log", login);
            query.setParameter("pass", password);
            query = query.setReadOnly(true);
            result = query.uniqueResultOptional();
            tx.rollback();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            LOG.error(e.getMessage(), e);
        } finally {
            session.close();
        }
        return result;
    }

    public long createUser(User user) {
        long userId = 0;
        Optional<User> user1 = this.getUserByLoginAndPassword(user.getLogin(), user.getPassword());
        User persistUser;
        if (user1.isPresent()) {
            persistUser = user1.get();
            userId = persistUser.getId();
        } else {
            Session session = this.factory.openSession();
            Transaction tx = null;
            try {
                tx = session.beginTransaction();
                userId = (long) session.save(user);
                tx.commit();
            } catch (Exception e) {
                if (tx != null) {
                    tx.rollback();
                }
                LOG.error(e.getMessage(), e);
            } finally {
                session.close();
            }
        }
        return userId;
    }

    public List<Car> getCars() {
        Session session = this.factory.openSession();
        Transaction tx = null;
        List<Car> brands = new ArrayList<>();
        try {
            tx = session.beginTransaction();
            Query query = session.createQuery("FROM Car");
            brands = query.list();
            tx.rollback();
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            LOG.error(e.getMessage(), e);
        } finally {
            session.close();
        }
        return brands;
    }

    public void closeSessionFactory() {
        this.factory.close();
    }

}
