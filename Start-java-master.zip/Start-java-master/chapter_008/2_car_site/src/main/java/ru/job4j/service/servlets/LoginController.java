package ru.job4j.service.servlets;

import ru.job4j.data.dbtools.DbManager;
import ru.job4j.data.models.User;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Optional;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class LoginController extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        DbManager manager = (DbManager) req.getServletContext().getAttribute("dBManager");

        String login = req.getParameter("login");
        String password = req.getParameter("password");
        HttpSession session = req.getSession();
        Optional<User> userl = manager.getUserByLoginAndPassword(login, password);
        User user;
        if (userl.isPresent()) {
            user = userl.get();
            session.setAttribute("user", user);
            session.removeAttribute("brand");
            session.removeAttribute("year");
            resp.sendRedirect("index.html");
        } else {
            resp.sendRedirect("login.html");
        }

    }
}
