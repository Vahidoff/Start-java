package ru.job4j.service.servlets;

import ru.job4j.data.dbtools.DbManager;
import ru.job4j.data.models.Car;
import ru.job4j.data.models.Foto;
import ru.job4j.data.models.User;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class CreateAdController extends HttpServlet {

    private static final String IMAGES = "C:/Data/images/";

    /**
     * Inserts specified in request advertisement in database.
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession();
        final User user = (User) session.getAttribute("user");
        session.removeAttribute("brand");
        session.removeAttribute("year");

        Car car = new Car();
        car.setBrand(req.getParameter("brand"));
        car.setModel(req.getParameter("model"));
        car.setTransmission(req.getParameter("transmission"));
        String year = req.getParameter("year");
        if (year.equals("") | car.getBrand().equals("") | car.getModel().equals("")) {
            resp.sendRedirect("declaration.html");
        } else {
            car.setYear(Integer.valueOf(year));
            car.setEngineCapacity(Float.valueOf(req.getParameter("capacity")));

            Part filePart = req.getPart("file"); // Retrieves <input type="file" name="file">
            String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString(); // MSIE fix.
            File uploads = new File(IMAGES);

            File file = new File(uploads, fileName);

            try (InputStream fileContent = filePart.getInputStream();) {
                Files.copy(fileContent, file.toPath());
            } catch (Exception e) {
                e.printStackTrace();
            }

            Foto foto = new Foto();
            foto.setName(fileName);

            DbManager manager = (DbManager) req.getServletContext().getAttribute("dBManager");
            manager.createAdvertisement(req.getParameter("desc"), user, car, foto);
            resp.sendRedirect("index.html");
        }
    }
}
