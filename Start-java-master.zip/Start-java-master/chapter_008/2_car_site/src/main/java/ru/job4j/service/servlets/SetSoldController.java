package ru.job4j.service.servlets;

import ru.job4j.data.dbtools.DbManager;
import ru.job4j.data.models.Ad;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author Aleksundrr Vahheedofv (mailto:mango777555@hotmail.com)
 * @version $Id$
 * @since 2017
 */
public class SetSoldController extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        DbManager manager = (DbManager) req.getServletContext().getAttribute("dBManager");

        int advertId = Integer.parseInt(req.getParameter("id"));
        Ad advert = manager.getDeclarationById(advertId);
        advert.setSold(!advert.isSold());
        manager.saveDeclaration(advert);
        resp.sendRedirect("index.html");
    }
}
