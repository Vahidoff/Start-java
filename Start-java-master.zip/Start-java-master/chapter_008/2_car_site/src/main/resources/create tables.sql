CREATE DATABASE users4;

CREATE TABLE cars (
  id           SERIAL PRIMARY KEY,
  brand        CHARACTER VARYING(200),
  model        CHARACTER VARYING(200),
  transmission CHARACTER VARYING(200),
  engine       FLOAT,
  year         INTEGER
);
--  select * from cars

CREATE TABLE declarations (
  id          SERIAL PRIMARY KEY,
  description CHARACTER VARYING(200),
  sold        BOOLEAN,
  create_date TIMESTAMP,
  user_id     INTEGER REFERENCES users (id),
  car_id      INTEGER REFERENCES cars (id)
);

ALTER TABLE declarations
  ADD COLUMN foto_id INTEGER REFERENCES foto (id);
-- select * from declarations

CREATE TABLE users (
  id         SERIAL PRIMARY KEY,
  login      CHARACTER VARYING(200),
  password   CHARACTER VARYING(200),
  name       CHARACTER VARYING(200),
  surname    CHARACTER VARYING(200),
  tel_number CHARACTER VARYING(200)
);
-- select * from users

CREATE TABLE foto (
  id   SERIAL PRIMARY KEY,
  name VARCHAR(50) NOT NULL
);

-- SELECT * FROM foto