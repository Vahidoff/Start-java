- I am a student at the [job4j.ru]
* skype, email: mango777555@hotmail.com

### Chapter 2_car_site

## Реализовать площадку продаж машин. 
	Это web приложение со следующими страницами.
	1. основная страница. таблица со всеми объявлениям машин на продажу.
	2. на странице есть кнопка. добавить новое объявление.
	3. переход на страницу добавления.
	4. есть категории машины. марка. описание и тд. 
	5. важно!. добавление фото. использовать библиотеку apache fileuppload
	6. объявление имеет статус продано. или нет.
	7. должны существовать пользователи. кто подал заявление. только он может менять статус.
	
### Список объявлений:
	
<a href='https://s9.postimg.org/3t4wbs7kv/Car_shop_2.png'>
     <img src='https://s9.postimg.org/3t4wbs7kv/Car_shop_2.png' width=500>
     </a>
     
### Реализован двухуровневый пользовательский фильтр
<a href='https://s26.postimg.org/561ap5fx5/choice.png'>
<img src='https://s26.postimg.org/561ap5fx5/choice.png' width=500>
</a>
     
### Окно создания объявления:
      
 <a href='https://s26.postimg.org/wgc1jgp95/declaration.png'>
      <img src='https://s26.postimg.org/wgc1jgp95/declaration.png' width=500>
      </a>
      
### Стриница регистриции нового пользователя
<a href='https://s26.postimg.org/ku1mgrzvd/Car_shop_3.png'>
<img src='https://s26.postimg.org/ku1mgrzvd/Car_shop_3.png' width=500>
</a>
      
### Данные хранятся в базе данных PostgreSQL, а доступ к ней обеспечивается с помощью Hibernate ORM.

Пользовательские картинки загружаются и сохраняются на сервере с помощью фреймворка Apache Commons FileUpload.

Внешний вид реализован с помощью фреймворков Bootstrap и jQuery.

      В приложении были использованы следующие технологии и библиотеки:
      * Java Core
      * Hibernate ORM
      * PostgreSQL
      * Apache Commons FileUpload
      * HTML, CSS, Bootstrap, JavaScript, jQuery, Ajax, JSON
      
     
[job4j.ru]:http://job4j.ru/courses/java_with_zero_to_job.html
      
    