package ru.job4j.iterator;

import java.util.Iterator;

/**
 * IteratorTwoArray.
 * iterator for a two-dimensional array
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class IteratorTwoArray implements Iterator {
    /**
     * source array.
     */
    private final int[][] values;
    /**
     * column.
     */
    private int x = 0;
    /**
     * line.
     */
    private int y = 0;
    /**
     * total number of elements.
     */
    private int index = 0;
    /**
     * iterator for a two-dimensional array.
     * @param values - source array.
     */
    public IteratorTwoArray(final int[][] values) {
        this.values = values;
    }

    @Override
    public boolean hasNext() {
        return !(y == values.length - 1 & x == values[y].length);
    }

    @Override
    public Object next() {
        if (x == values[y].length) {
            y++;
            x = 0;
        }
        index++;
        return values[y][x++];
    }
}