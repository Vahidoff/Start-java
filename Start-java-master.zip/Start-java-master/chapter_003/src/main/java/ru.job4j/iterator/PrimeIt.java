package ru.job4j.iterator;
import java.util.Iterator;

/**
 * PrimeIt.
 * iterator for the prime numbers
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class PrimeIt implements Iterator {
    /**
     * source array.
     */
    private int[] values;
    /**
     * index of array.
     */
    private int index = 0;
    /**
     * PrimeIt.
     * @param values source array
     */
    public PrimeIt(final int[] values) {
        this.values = values;
    }

    @Override
    public boolean hasNext() {
        boolean flag = false;
        for (int x = index; x < values.length; x++) {
            if (findPrime(x) < 3) {
                flag = true;
                break;
            }
        }
        return flag;
    }

    @Override
    public Object next() {
        int result = 0;
        while (index < values.length) {
            index++;
            if (findPrime(index - 1) < 3) {
                result = values[index - 1];
                break;
            }
        }
        return result;
    }
    /**
     * findPrime - searching a prime number in an array.
     * @param c - index of values
     * @return - number of dividers
     */
    private int findPrime(int c) {
        int beam = 0;
        for (int i = 1; i <= values[c]; i++) {
            if (values[c] % i == 0) {
                beam++;
            }
        }
        return beam;
    }
}
