package ru.job4j.iterator;
import java.util.Iterator;

/**
 * EvenIt.
 * iterator for the even numbers
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class EvenIt implements Iterator {
    /**
     * source array.
     */
    private final int[] values;
    /**
     * index of array.
     */
    private int index = 0;
    /**
     * constructor.
     * @param values source array
     */
    public EvenIt(final int[] values) {
        this.values = values;
    }

    @Override
    public boolean hasNext() {
        boolean flag = false;
        while (index < values.length) {
            if (values[index] % 2 == 0) {
                flag = true;
                break;
            }
            index++;
        }
        return flag;
    }

    @Override
    public Object next() {
        int result = -1;
        while (index < values.length) {
            if (hasNext()) {
                result = values[index++];
                break;
            }
        }
        return result;
    }
}
