package ru.job4j.iterator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Converter.
 * Iterator<Integer> convert(Iterator<Iterator<Integer>>.
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Converter {
    /**
     * inner iterator.
     */
    private Iterator<Integer> it;
    /**
     * convert.
     * @param itIt - Iterator<Iterator<Integer>>
     * @return - Iterator<Integer>
     */
    public Iterator<Integer> convert(Iterator<Iterator<Integer>> itIt) {
        this.it = itIt.next();

        return new Iterator<Integer>()  {

            @Override
            public boolean hasNext() {
                return itIt.hasNext() || it.hasNext();
            }

            @Override
            public Integer next() throws NoSuchElementException {
                int result;
                if (it.hasNext()) {
                    result = it.next();
                } else {
                    it = itIt.next();
                    result = it.next();
                }
                return result;
            }
        };
    }
}
