package ru.job4j.list;

/**
 * Node.
 * the container with next reference
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 * @param <T>
 */
class Node<T>  {
    /**
     * element value.
     */
    private T value;
    /**
     * reference to next element.
     */
    private Node<T> next;
    /**
     * constructor.
     * @param t - element value.
     * @param next - reference to next element.
     */
    Node(T t, Node<T> next) {
        this.value = t;
        this.next = next;
    }
    /**
     * @param next - Node<T>.
     */
    public void setNext(Node<T> next) {
        this.next = next;
    }
    /**
     * @return - Node<T> next.
     */
    public Node<T> getNext() {
        return this.next;
    }
}
/**
 * CyclicityN.
 * definition of the cyclicity on the list
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 * @param <T>
 */
public class CyclicityN<T> {
    /**
     * hasCycle.
     * @param first - element
     * @return boolean result
     */
    boolean hasCycle(Node<T> first) {
        int power = 0;
        int lam = 0;
        Node<T> tortoise = first;
        Node<T> hare = first.getNext();

        boolean flag = true;
        while (tortoise != hare) {
            if (power == lam) {
                tortoise = hare;
                power *= 2;
            }
            try {
                hare = hare.getNext();
                lam++;
            } catch (NullPointerException n) {
                flag = false;
                break;
            }
        }

        tortoise = first;
        hare = first;
        for (int i = 0; i < lam; i++) {
            hare = hare.getNext();
        }

        while (tortoise != hare) {
            tortoise = tortoise.getNext();
            try {
                hare = hare.getNext();
            } catch (NullPointerException n) {
                flag = false;
            }
        }
        return flag;
    }
}
