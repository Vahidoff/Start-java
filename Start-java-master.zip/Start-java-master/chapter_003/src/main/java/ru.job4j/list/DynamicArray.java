package ru.job4j.list;


import java.util.Iterator;
/**
 * DynamicArray.
 * dynamic array-based list
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 * @param <T>
 */
public class DynamicArray<T> implements SimpleContainer<T> {
    /**
     * a size of the base array.
     */
    private int size = 10;
    /**
     * the base array.
     */
    private Object[] container = new Object[10];
    /**
     * the base array.
     */
    private Object[] container2 = new Object[20];
    /**
     * beginner index of the base array.
     */
    private int index = 0;
    /**
     * getContainer.
     * @return container
     */
    public Object[] getContainer() {
        return this.container;
    }

    @Override
    public void add(T t) {
        if (this.index == this.container.length) {
            enlargement();
        }
        this.container[this.index++] = t;

    }

    @Override
    public T get(int i) {
        return (T) this.container[i];
    }

    @Override
    public Iterator<T> iterator() {
        Object[] c = this.container;
        final int[][] i = {{0}};
        final int[] sum = {0};

        return new Iterator<T>() {
            @Override
            public boolean hasNext() {
                return sum[0] < index;
            }

            @Override
            public T next() {
                sum[0]++;
                return (T) c[i[0][0]++];
            }
        };
    }
    /**
     * enlargement of the array.
     */
    private void enlargement() {
        for (int i = 0; i < container.length; i++) {
            this.container2[i] = this.container[i];
        }
        this.container = this.container2;
    }
}
