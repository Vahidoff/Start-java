package ru.job4j.list;

import java.util.Iterator;
/**
 * References.
 * references for the connected list
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 * @param <E>
 */
class References<E> {
    /**
     * an element of the list.
     */
    private E e;
    /**
     * reference to the next element.
     */
    private References<E> next;
    /**
     * reference to the early element.
     */
    private References<E> early;
    /**
     * constructor.
     * @param e - an element of the list
     * @param early - reference to the early element
     * @param next - reference to the next element
     */
    References(E e, References<E> early, References<E> next) {
        this.e = e;
        this.next = next;
        this.early = early;
    }
    /**
     *@return e
     */
    E getE() {
        return this.e;
    }
    /**
      * @param e - an element of the list
     */
    void setE(E e) {
        this.e = e;
    }
    /**
     * @return References<E> next.
     */
    public References<E> getNext() {
        return this.next;
    }
    /**
     * @param next - reference to the next element.
     */
    public void setNext(References<E> next) {
        this.next = next;
    }
    /**
     * @return References<E> early.
     */
    References<E> getEarly() {
        return this.early;
    }
    /**
      * @param early - reference to the early element.
     */
    void setEarly(References<E> early) {
        this.early = early;
    }
}
/**
 * DynamicArray.
 * connected list
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 * @param <T>
 */
public class ConnectedList<T> implements SimpleContainer<T> {
    /**
     * size of the list.
     */
    private int size = 0;
    /**
     * reference to the first element.
     */
    private References<T> first;
    /**
     * reference of the end element.
     */
    private References<T> end;

    @Override
    public void add(T o) {
        size++;
        References<T> ref = this.end;
        References<T> newRef = new References<>(o, ref, null);
        this.end = newRef;
        if (ref == null) {
            this.first = newRef;
        } else {
            ref.setNext(newRef);
        }
    }

    @Override
    public T get(int index) {
        References<T> ref = this.first;
        for (int i = 0; i < index; i++) {
            ref = ref.getNext();
        }
        return ref.getE();
    }
    /**
     * deleting the first element of the deposit.
     * @return the first element of the deposit
     */
    public T deleteFirst() {
        References<T> first = this.first;
        T element = first.getE();
        References<T> next = first.getNext();

        first.setE(null);
        first.setNext(null);
        this.first = next;
        if (next == null) {
            this.end = null;
        } else {
            next.setEarly(null);
        }
        this.size--;
        return element;
    }
    /**
     * deleting the last element of the deposit.
     * @return the last element of the deposit
     */
    public T deleteEnd() {
        References<T> last = this.end;
        T element = last.getE();
        References<T> early = last.getEarly();

        last.setE(null);
        last.setEarly(null);
        this.end = early;
        if (early == null) {
            this.first = null;
        } else {
            early.setNext(null);
        }
        this.size--;
        return element;
    }

    @Override
    public Iterator<T> iterator() {
        int size = this.size;
        final int[] amount = {0};
        final References<T>[] ref = new References[]{this.first};
        return new Iterator<T>() {

            @Override
            public boolean hasNext() {
                return amount[0] < size;
            }

            @Override
            public T next() {
                T e = ref[0].getE();
                ref[0] = ref[0].getNext();
                amount[0]++;
                return e;
            }
        };
    }
}
