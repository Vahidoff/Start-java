package ru.job4j.list;
/**
 * SimpleContainer.
 * the interface for user's containers
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 * @param <E>
 */
public interface SimpleContainer<E> extends Iterable<E> {
    /**
     * adding an element to the container.
     * @param e - element of the container
     */
    void add(E e);
    /**
     * getting the element from the container.
     * @param index of the container
     * @return element of the container
     */
    E get(int index);
}