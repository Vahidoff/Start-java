package ru.job4j.list;
/**
 * MQueue.
 * a container in the likeness on the queue
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 * @param <T>
 */
public class MQueue<T> extends ConnectedList<T> {
    /**
     * push. Adding an element to the stack.
     * @param value -
     */
    void offer(T value) {
        add(value);
    }
    /**
     * pop.
     * @return - getting an element from the stack
     */
    T peek() {
        return deleteFirst();
    }
}
