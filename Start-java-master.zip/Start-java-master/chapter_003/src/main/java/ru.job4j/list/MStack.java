package ru.job4j.list;
/**
 * MStack.
 * a container in the likeness on the stack
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 * @param <T>
 */
public class MStack<T> extends ConnectedList<T> {
    /**
     * push. Adding an element to the stack.
     * @param value -
     */
    void push(T value) {
        add(value);
    }
    /**
     * pop.
     * @return - getting an element from the stack
     */
    T pop() {
        return deleteEnd();
    }
}
