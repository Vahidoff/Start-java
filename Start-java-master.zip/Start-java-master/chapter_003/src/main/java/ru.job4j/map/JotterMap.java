package ru.job4j.map;

import java.util.Arrays;
import java.util.Iterator;

/**
 * JotterMap.
 * the data structure similar to a handbook
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 * @param <K> - key
 * @param <V> - value
 */
public class JotterMap<K, V> implements Iterable<V> {
    /**
     * start size.
     */
    private static final int SIZE = 5;
    /**
     * increase multiple.
     */
    private static final int FACTOR = 2;
    /**
     * basket for storage.
     */
    private Entry<K, V>[] basket = (Entry<K, V>[]) new Entry[SIZE];
    /**
     * insert - the element to the storage.
     * @param key -
     * @param value -
     * @return boolean result.
     */
    public boolean insert(K key, V value) {
        boolean flag = false;

        int position = this.getPosition(key);
        Entry<K, V> en = this.basket[position];
        if (en == null) {
            this.basket[position] = new Entry<>(key, value);
            flag = true;
        } else {
            if (key.equals(en.getKey())) {
                en.setValue(value);
            } else {
                this.upBasket();
                insert(key, value);
            }
        }
        return flag;
    }
    /**
     * getting the element.
     * @param key -
     * @return - Entry element
     */
    public V get(K key) {
        return this.basket[getPosition(key)].getValue();
    }
    /**
     * deleting the element.
     * @param key -
     * @return - boolean result
     */
    public boolean delete(K key) {
        boolean flag = false;
        int position = getPosition(key);
        Entry<K, V> en = this.basket[position];
        if (key.equals(en.getKey())) {
            this.basket[position] = null;
            flag = true;
        }
        return flag;
    }
    /**
     * generateHash - creating a key hash.
     * @param key -
     * @return - the hash of the key
     */
    private int generateHash(K key) {
        return key.hashCode() ^ (key.hashCode() >>> 2) ^ (key.hashCode() >>> 12);
    }
    /**
     * increase the storage.
     */
    private void upBasket() {
        Entry<K, V>[] temp = this.basket;
        this.basket = Arrays.copyOf(this.basket, this.basket.length * FACTOR);

        this.basket = (Entry<K, V>[]) new Entry[this.basket.length];
        for (Entry<K, V> en : temp) {
            if (en != null) {
                this.basket[getPosition(en.getKey())] = en;
            }
        }
    }
    /**
     * finding a place in the basket.
     * @param key -
     * @return the place
     */
    private int getPosition(K key) {
        int position = 0;
        if (key != null) {
            position = Math.abs(generateHash(key) % this.basket.length);
        }
        return position;
    }

    @Override
    public Iterator iterator() {
        final int[] index = {0};
        final int[] early = {0};

        return new Iterator<Entry>() {
            @Override
            public boolean hasNext() {
                boolean flag = false;
                int position = index[0];

                while (position < basket.length) {
                    if (basket[position] != null) {
                        flag = true;
                        break;
                    } else {
                        position++;
                    }
                }
                return flag;
            }

            @Override
            public Entry next() {
                Entry<K, V> en = null;
                for (; early[0] < basket.length; early[0]++) {
                    if (basket[early[0]] != null) {
                        en = basket[early[0]];
                        index[0] = early[0] + 1;
                        early[0]++;
                        break;
                    }
                }
                return en;
            }
        };
    }
}
