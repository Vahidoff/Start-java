package ru.job4j.map;

/**
 * storage structure.
 * @param <K> - key
 * @param <V> - value
 */
 class Entry<K, V> {
    /**
     * key.
     */
    private K key;
    /**
     * value.
     */
    private V value;
    /**
     * constructor.
     * @param key -
     * @param value -
     */
    Entry(K key, V value) {
        this.key = key;
        this.value = value;
    }
    /**
     * getting the key.
     * @return key
     */
    K getKey() {
        return key;
    }
    /**
     * getting the value.
     * @return value
     */
    V getValue() {
        return value;
    }
    /**
     * setting the value.
     * @param value -
     */
    void setValue(V value) {
        this.value = value;
    }
}
