package ru.job4j.collectionspro;

/**
 * Order.
 * the container with book, type, price, value, id
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Order implements Comparable {
    /**
     * book.
     */
    private String book;
    /**
     * type: SELL or BUY.
     */
    private Type type;
    /**
     * price.
     */
    private float price;
    /**
     * value.
     */
    private int value;
    /**
     * id.
     */
    private int id;
    /**
     * getBook.
     * @return book
     */
    public int getValue() {
        return value;
    }
    /**
     * getId.
     * @return id
     */
    public int getId() {
        return id;
    }
    /**
     * getBook.
     * @return book
     */
    public String getBook() {
        return this.book;
    }
    /**
     * getType.
     * @return type
     */
    public Order.Type getType() {
        return this.type;
    }
    /**
     * getPrice.
     * @return price
     */
    public float getPrice() {
        return this.price;
    }
    /**
     * Type : SELL, BUY.
     */
    enum Type { SELL, BUY
    }

    /**
     * constructor.
     * @param book -
     * @param type -
     * @param price -
     * @param value -
     * @param id -
     */
    public Order(String book, Type type, float price, int value, int id) {
        this.book = book;
        this.type = type;
        this.price = price;
        this.value = value;
        this.id = id;
    }
    /**
     * setValue.
     * @param value -
     */
    public void setValue(int value) {
        this.value = value;
    }

    @Override
    public int compareTo(Object o) {
        Order order = (Order) o;
        if (order.type == Type.SELL) {
            return  this.price < order.price ? -1 : 1;
        } else {
            return  this.price > order.price ? -1 : 1;
        }
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj == null || obj.getClass() != this.getClass()) {
            return false;
        }
        Order order = (Order) obj;
        return this.id == order.id;
    }

    @Override
    public int hashCode() {
        return this.id;
    }

}
