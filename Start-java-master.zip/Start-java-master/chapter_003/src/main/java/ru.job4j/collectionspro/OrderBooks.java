package ru.job4j.collectionspro;

import java.io.FileNotFoundException;
import java.util.TreeSet;
import java.util.Set;
import java.util.TreeMap;
import java.util.ArrayList;
/**
 * OrderBooks.
 * here under the books orders are aggregated, and delete unprofitable deals
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class OrderBooks {
    /**
     * sorted ascending for "SELL" and sorting in decreasing for "BUY".
     */
    private TreeMap<String, TreeMap<Order.Type, TreeMap<Order, Float>>> allSorted;
    /**
     * constructor.
     * @param allSorted -
     */
    OrderBooks(TreeMap<String, TreeMap<Order.Type, TreeMap<Order, Float>>> allSorted) {
        this.allSorted = allSorted;
    }

    /**
     * aggregation - we put together orders with the same price.
     * @return TreeMap String  HashMap<Order.Type, TreeSet<Order>>> -
     * String - book
     * @throws FileNotFoundException - "file not find".
     */

    TreeMap<String, TreeMap<Order.Type, TreeSet<Order>>> aggregation() throws FileNotFoundException {
        TreeMap<String, TreeMap<Order.Type, TreeSet<Order>>> result = new TreeMap<>();

        TreeMap<Order.Type, TreeMap<Order, Float>> hashMapType;

        Set<String> setBook = allSorted.keySet();
        for (String book : setBook) {
            hashMapType = allSorted.get(book);

            TreeMap<Order.Type, TreeSet<Order>> tempType = new TreeMap<>();
            Set<Order.Type> setType = hashMapType.keySet();
            for (Order.Type type : setType) {

                Set<Order> setOrder = hashMapType.get(type).keySet();

                ArrayList<Order> arrayOrder = new ArrayList<>(setOrder);
                for (int i = 0; i < arrayOrder.size() - 1; i++) {

                    if (arrayOrder.get(i).getPrice() == arrayOrder.get(i + 1).getPrice()) {
                        arrayOrder.get(i).setValue(arrayOrder.get(i).getValue() + arrayOrder.get(i + 1).getValue());
                        arrayOrder.remove(i + 1);
                        i--;
                    }
                }
                TreeSet<Order> tempOrder = new TreeSet<>(arrayOrder);
                tempType.put(type, tempOrder);
            }
            result.put(book, tempType);
        }
        return result;
    }
    /**
     * delete unprofitable deals.
     * @return TreeMap String, HashMap<Order.Type, TreeSet<Order>>>
     * @throws FileNotFoundException - "file not find".
     */
    TreeMap<String, TreeMap<Order.Type, TreeSet<Order>>> removalUnprofitableDeals()
            throws FileNotFoundException {
        TreeMap<String, TreeMap<Order.Type, TreeSet<Order>>> aggregateMap = aggregation();
        TreeMap<String, TreeMap<Order.Type, TreeSet<Order>>> result = new TreeMap<>();
        TreeMap<Order.Type, TreeSet<Order>> hashMapType;

        Set<String> setBook = aggregateMap.keySet();
        for (String book : setBook) {
            hashMapType = aggregateMap.get(book);
            TreeMap<Order.Type, TreeSet<Order>> tempType = new TreeMap<>();
                ArrayList<Order> arrayBuy;
                ArrayList<Order> arraySell;
                    Set<Order> setOrderBuy = hashMapType.get(Order.Type.BUY);
                    arrayBuy = new ArrayList<>(setOrderBuy);
                    Set<Order> setOrderSell = hashMapType.get(Order.Type.SELL);
                    arraySell = new ArrayList<>(setOrderSell);

                for (int i = 0; i < arrayBuy.size(); i++) {
                    if (i < arraySell.size() && arrayBuy.get(i).getPrice() >= arraySell.get(i).getPrice()) {
                        if (arrayBuy.get(i).getValue() >= arraySell.get(i).getValue()) {
                            arrayBuy.get(i).setValue(arrayBuy.get(i).getValue() - arraySell.get(i).getValue());
                            arraySell.remove(i);
                        }
                        if (arrayBuy.get(i).getValue() < arraySell.get(i).getValue()) {
                            arrayBuy.get(i).setValue(arraySell.get(i).getValue() - arrayBuy.get(i).getValue());
                            arrayBuy.remove(i);
                        }
                        i--;
                }

                }
            TreeSet<Order> tempOrderBuy = new TreeSet<>(arrayBuy);
            TreeSet<Order> tempOrderSell = new TreeSet<>(arraySell);
            tempType.put(Order.Type.BUY, tempOrderBuy);
            tempType.put(Order.Type.SELL, tempOrderSell);
            result.put(book, tempType);
            }
            return result;

        }
    /**
     * display of exchange glasses for individual books.
     * @throws FileNotFoundException - "file not find".
     */
    void showResult() throws FileNotFoundException {
            TreeMap<String, TreeMap<Order.Type, TreeSet<Order>>> removalNonprofits = removalUnprofitableDeals();

            Set<String> books = removalNonprofits.keySet();
            StringBuilder builder = new StringBuilder();
            TreeMap<Order.Type, TreeSet<Order>> tempType;
            for (String book : books) {

                tempType = removalNonprofits.get(book);

                TreeSet<Order> orders = tempType.get(Order.Type.SELL);
                builder.append(String.format("%s  ", book));
                builder.append(String.format("%s\n", Order.Type.SELL));
                for (Order temp : orders) {
                    builder.append(String.format("\t\t%5s %7s\n", temp.getPrice(), temp.getValue()));
                }
                TreeSet<Order> ordersBuy = tempType.get(Order.Type.BUY);
                builder.append(String.format("%s  ", book));
                builder.append(String.format("%s\n", Order.Type.BUY));
                for (Order temp : ordersBuy) {
                    builder.append(String.format("%s %7s\n", temp.getPrice(), temp.getValue()));
                }
            }
            System.out.println(builder);
        }
}