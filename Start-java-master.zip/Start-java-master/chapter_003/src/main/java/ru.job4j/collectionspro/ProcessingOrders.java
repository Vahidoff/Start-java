package ru.job4j.collectionspro;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Set;
import java.util.TreeMap;

/**
 * ProcessingOrders.
 * reading and processing orders from a file
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class ProcessingOrders {
    /**
     * line reading of a file.
     * @param st - the path of the file.
     * @return - HashMap<String, HashMap<Integer, Order>>
     *     String - book, Integer - Order.id.
     * @throws FileNotFoundException - file not find
     */
    protected HashMap<String, HashMap<Integer, Order>> readFile(String st) throws FileNotFoundException {
        HashMap<String, HashMap<Integer, Order>> orders = new HashMap<>();
        try (BufferedReader br = new BufferedReader(new FileReader(st))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("<A")) {
                    final Order order = this.parse(line, true);
                    HashMap<Integer, Order> list = orders.get(order.getBook());
                    if (list == null) {
                        list = new HashMap<>();
                        orders.put(order.getBook(), list);
                    }
                    list.put(order.getId(), order);
                } else if (line.startsWith("<D")) {
                    final Order order = this.parse(line, false);
                    orders.get(order.getBook()).remove(order.getId());
                }
            }
        }
        catch (IOException e) {
              System.out.println("file not find");
        }
        return orders;
    }
    /**
     * finding Order class variable in one line.
     * @param text - the one line
     * @param add - adding: true; deleting: false
     * @return new Order
     */
    public Order parse(final String text, boolean add) {
        boolean start = false;
        int pos = -1;
        String[] values = new String[5];
        int current = 0;
        for (int i = 0; i != text.length(); ++i) {
            if (text.charAt(i) == '\"') {
                if (start) {
                    values[current++] = text.substring(pos + 1, i);
                    start = false;
                } else {
                    start = true;
                }
                pos = i;
            }
        }
        if (add) {
            return new Order(
                    values[0],
                    "SELL".equals(values[1]) ? Order.Type.SELL : Order.Type.BUY,
                    Float.valueOf(values[2]), Integer.valueOf(values[3]), Integer.valueOf(values[4])
            );
        } else {
            return new Order(values[0], Order.Type.BUY, 0f, 0, Integer.valueOf(values[1]));
        }

    }
    /**
     * sort ascending for "SELL" and sorting in decreasing for "BUY".
     * @param st - the path of the file.
     * @return - TreeMap<String, HashMap<Order.Type, TreeMap<Order, Float>>>
     *     String - book, Order.Type - SELL, BUY; Float - Order.price
     * @throws FileNotFoundException - file not find
     */
    protected TreeMap<String, TreeMap<Order.Type, TreeMap<Order, Float>>> sortSellBuy(String st)
            throws FileNotFoundException {
        TreeMap<String, TreeMap<Order.Type, TreeMap<Order, Float>>> allSellBuy = new TreeMap<>();
        HashMap<String, HashMap<Integer, Order>> allOrders = this.readFile(st);
        Set<String> setBooks = allOrders.keySet();


        for (String book : setBooks) {
            HashMap<Integer, Order> bookOrders = allOrders.get(book);
            TreeMap<Order.Type, TreeMap<Order, Float>> tempType = new TreeMap<>();

            for (Order order : bookOrders.values()) {

                if (order.getType() == Order.Type.SELL) {

                    if (tempType == null) {
                        tempType = new TreeMap<>();
                        tempType.put(Order.Type.SELL, new TreeMap<>());
                    }
                    TreeMap<Order, Float> temp = tempType.get(order.getType());
                    if (temp == null) {
                        temp = new TreeMap<>();
                        tempType.put(Order.Type.SELL, temp);
                    }
                    temp.put(order, order.getPrice());
                } else {
                    if (tempType == null) {
                        tempType = new TreeMap<>();
                        tempType.put(Order.Type.BUY, new TreeMap<>());
                    }
                    TreeMap<Order, Float> temp = tempType.get(Order.Type.BUY);
                    if (temp == null) {
                        temp = new TreeMap<>();
                        tempType.put(Order.Type.BUY, temp);
                    }
                    temp.put(order, order.getPrice());
                }
            }
            allSellBuy.put(book, tempType);
        }
        return allSellBuy;
    }

}

