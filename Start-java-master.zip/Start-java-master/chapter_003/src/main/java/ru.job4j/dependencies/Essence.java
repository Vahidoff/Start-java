package ru.job4j.dependencies;
/**
 * Entity.
 * the container for entities
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Essence {
    /**
     * number of a first entity.
     */
    private int first;
    /**
     * number of a second entity.
     */
    private int second;
    /**
     * constructor.
     * @param first -
     * @param second -
     */
    Essence(int first, int second) {
        this.first = first;
        this.second = second;
    }
    /**
     * getFirst.
     * @return first
     */
    public int getFirst() {
        return first;
    }
    /**
     * getSecond.
     * @return second
     */
    public int getSecond() {
        return second;
    }
}
