/**
 * Package for: processing of the file in which finding the.
 * dependencies of entities from each other
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
package ru.job4j.dependencies;