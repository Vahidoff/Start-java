package ru.job4j.dependencies;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

/**
 * Entities.
 * processing of the file in which specification
 * dependencies of entities from each other
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class Entities {
    /**
     * reading entities from a file.
     * @param file -
     * @return ArrayList<Essence> essences
     * @throws IOException - "file not find".
     */
    protected ArrayList<Essence> readEntities(String file) throws IOException {
        ArrayList<Essence> essences = new ArrayList<>();
        try {
            List<String> lines = Files.readAllLines(Paths.get(file), StandardCharsets.UTF_8);
            for (String line : lines) {
                if (line.startsWith("<e")) {
                    essences.add(readNo(line));
                }
            }
        } catch (IOException e) {
            System.out.println("file not find");
        }
        return essences;
    }
    /**
     * reading in a row of related numbers.
     * @param line - string
     * @return Essence
     */
    private Essence readNo(final String line) {
        String[] temp = new String[2];
        int index = 0;
        int pos = 0;
        boolean flag = true;

        for (int i = 0; i < line.length(); i++) {
            if (line.charAt(i) == '\"') {
                if (flag) {
                    pos = i + 1;
                    flag = false;
                } else {
                    temp[index++] = line.substring(pos, i);
                    flag = true;
                }
            }
        }
        return new Essence(Integer.parseInt(temp[0]), Integer.parseInt(temp[1]));
    }
    /**
     * determination of cyclicity.
     * @param file - ArrayList<Essence> = readEntities(file)
     * @return boolean result
     * @throws IOException - "file not find".
     */
    protected HashMap<Integer, LinkedList<Integer>> findCycle(String file) throws IOException {
        ArrayList<Essence> buffer = readEntities(file);
        HashMap<Integer, LinkedList<Integer>> result = new HashMap<>();
        int index = 0;
        for (int i = 0; i < buffer.size() - 1; i++) {
            for (int j = i; j < buffer.size() - 1; j++) {
                if ((buffer.get(j).getSecond() - buffer.get(j).getFirst()) == 1
                        & buffer.get(j).getSecond() == buffer.get(j + 1).getFirst()) {
                    if (buffer.get(i).getFirst() == buffer.get(j + 1).getSecond()) {
                        LinkedList<Integer> list = new LinkedList<>();
                        list.add(buffer.get(i).getFirst());
                        list.add(buffer.get(i).getSecond());
                        for (int pop = i + 1; pop <= j + 1; pop++) {
                            list.add(buffer.get(pop).getSecond());
                        }
                        result.put(index++, list);
                    }
                }
            }
        }
        return result;
    }
}
