package ru.job4j.set;
import ru.job4j.list.ConnectedList;

import java.util.Iterator;
/**
 * ConnectedSet.
 * connected set
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 * @param <T>
 */
public class ConnectedSet<T> extends ConnectedList<T> {
    /**
     * addCSet.
     * no duplicates and no more than two null elements are allowed.
     * @param t - element adding to the container
     */
    void addCSet(T t) {
        boolean flag = true;
        Iterator<T> it = super.iterator();
        while (it.hasNext()) {
            if (it.next() == t) {
                flag = false;
            }
        }
        if (flag) {
            super.add(t);
        }
    }
    /**
     * @return iterator.
     */
    public Iterator<T> iterator() {
        return super.iterator();
    }
}
