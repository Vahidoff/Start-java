package ru.job4j.set;
import ru.job4j.list.ConnectedList;

import java.util.Iterator;

/**
 * SimpleSet.
 * set array-based collection
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 * @param <T>
 */
public class SimpleFastSet<T> {
    /**
     * ConnectedList.
     * Array of elements type T
     */
    private ConnectedList[] depositCL = new ConnectedList[SCALE];
    /**
     * an amount of null elements.
     */
    private static final int SCALE = 16;
    /**
     * adding an element to the set container.
     * no duplicates and no more than two null elements are allowed
     * @param t - element of the container
     */
    void addSFastSet(T t) {
        boolean flag = false;
        int number = Math.abs(t.hashCode() / this.depositCL.length);
        while (number > this.depositCL.length - 1) {
            number /= this.depositCL.length;
        }
        if (this.depositCL[number] == null) {
            this.depositCL[number] = new ConnectedList();
        }
        Iterator<T> itT = this.depositCL[number].iterator();
        while (itT.hasNext()) {
            if (t.equals(itT.next())) {
                flag = true;
                break;
            }
        }
        if (!flag) {
            this.depositCL[number].add(t);
        }
    }
    /**
     * iterator.
     * @return Iterator<T> iterator.
     */
    public Iterator<T> iterator() {
        final int[] indexIT = {0};
        final Iterator<T>[] tempIT = new Iterator[1];
        final boolean[] flagIT = {false};

        return new Iterator<T>() {
            @Override
            public boolean hasNext() {
                boolean flag = false;

                if (depositCL.length > indexIT[0] && depositCL[indexIT[0]] != null) {
                    if (!flagIT[0]) {
                        tempIT[0] = depositCL[indexIT[0]].iterator();
                        flagIT[0] = true;
                    }
                    if (tempIT[0].hasNext()) {
                        flag = true;
                    }
                }
                return flag;
            }

            @Override
            public T next() {
                T result = null;
                while (indexIT[0] <= depositCL.length) {
                    if (hasNext()) {
                        result = tempIT[0].next();
                        break;
                    } else {
                        indexIT[0]++;
                        flagIT[0] = false;
                    }
                }
                return result;
            }
        };
    }
}
