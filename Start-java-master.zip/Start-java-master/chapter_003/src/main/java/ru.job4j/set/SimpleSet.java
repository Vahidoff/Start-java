package ru.job4j.set;

import ru.job4j.list.DynamicArray;
import ru.job4j.list.SimpleContainer;

import java.util.Iterator;

/**
 * SimpleSet.
 * set array-based collection
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 * @param <T>
 */
public class SimpleSet<T> implements SimpleContainer<T> {
    /**
     * dynamic array-based list.
     */
    private DynamicArray<T> deposit = new DynamicArray<>();
    /**
     * adding an element to the set container.
     * no duplicates and no more than two null elements are allowed
     * @param t - element of the container
     */
    @Override
    public void add(T t) {
        boolean flag = true;
        for (T aDeposit : deposit) {
            if (aDeposit == t) {
                flag = false;
                break;
            }
        }
        if (flag) {
            deposit.add(t);
        }
    }
    /**
     * @return iterator.
     */
    public Iterator<T> iterator() {
        return deposit.iterator();
    }

    @Override
    public T get(int index) {
        return deposit.get(index);
    }
}
