package ru.job4j.tree;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * MTree.
 * the elementary tree structure
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 * @param <E>
 */
class MTree<E extends Comparable<E>> implements SimpleTree<E> {
    /**
     * Node.
     * tree branching structure
     * @param <E>
     */
    class Node<E> {
        /**
         * the element of a tree.
         */
        private E value;
        /**
         * tree branching.
         */
        private List<Node<E>> children = new ArrayList<>();
        /**
         * constructor.
         * @param e -
         */
        Node(E e) {
            this.value = e;
        }
    }
    /**
     * the base of a tree.
     */
    private Node<E> base;
    /**
     * constructor.
     * @param base -
     */
    MTree(E base) {
        this.base = new Node<>(base);
    }

    @Override
    public boolean addTree(E parent, E child) {
        boolean result = false;
            Node<E> findNode = findElement(parent, base);
            if (findNode != null) {
                findNode.children.add(new Node<>(child));
                result = true;
            }
        return result;
    }
    /**
     * finding the Node element in the tree.
     * @param element -
     * @param parent -
     * @return the Node element of tree
     */
    protected Node<E> findElement(E element, Node<E> parent) {
        Node<E> node = null;

        if (parent.value.equals(element)) {
            node = parent;
        } else {
            List<Node<E>> childList = parent.children;
            for (Node<E> child : childList) {
                node = findElement(element, child);
                if (node != null) {
                    break;
                }
            }
        }
        return node;
    }
    /**
     * checking the number of children in a tree.
     * @return there should be no more than two
     */
    public boolean isBinary() {
        getBinary(this.base);
        return flagBinary;
    }
    /**
     * result of isBinary.
     */
    private boolean flagBinary = true;
    /**
     * checking child elements.
     * @param parent -
     */
    private void getBinary(Node<E> parent) {
        for (Node<E> element : parent.children) {
            if (parent.children.size() > 2) {
                flagBinary = false;
            }
            getBinary(element);
        }
    }
    /**
     * getAll.
     * @return the list of elements of the tree
     */
    public List<E> getAll() {
        List<E> list = new ArrayList<>();
        getList(list, base);
        return list;
    }

    /**
     * putting elements of a tree in the list.
     * @param list -
     * @param parent - beginning element
     */
    private void getList(List<E> list, Node<E> parent) {
        list.add(parent.value);
        for (Node<E> element : parent.children) {
            getList(list, element);
        }
    }

    @Override
    public Iterator<E> iterator() {
        List<E> result = getAll();
        final int[] i = {0};

        return new Iterator<E>() {

            @Override
            public boolean hasNext() {
                return i[0] < result.size();
            }

            @Override
            public E next() {
                return result.get(i[0]++);
            }
        };
    }
}
