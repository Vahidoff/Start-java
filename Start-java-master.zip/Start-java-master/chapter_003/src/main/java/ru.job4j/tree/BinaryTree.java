package ru.job4j.tree;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * BinaryTree.
 * the binary tree structure
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 * @param <E>
 */
public class BinaryTree<E extends Comparable<E>> implements SimpleTree<E> {
    /**
     * Node.
     * tree branching structure
     * @param <E>
     */
    class NodeB<E> {
        /**
         * the element of a tree.
         */
        private E value;
        /**
         * smaller element than the value.
         */
        private NodeB<E> left;
        /**
         * bigger element than the value.
         */
        private NodeB<E> right;
        /**
         * constructor.
         * @param e -
         */
        NodeB(E e) {
            this.value = e;
        }
        /**
         * @param left -
         */
        public void setLeft(NodeB<E> left) {
            this.left = left;
        }
        /**
         * @param right -
         */
        public void setRight(NodeB<E> right) {
            this.right = right;
        }
    }
    /**
     * the base of a tree.
     */
    private NodeB<E> base;
    /**
     * constructor.
     * @param base -
     */
    BinaryTree(E base) {
        this.base = new NodeB<>(base);
    }

    @Override
    public boolean addTree(E parent, E child) {
        boolean result = false;
        NodeB<E> findNode = findElement(parent, base);
        if (findNode != null) {
            if (child.compareTo(parent) <= 0) {
                findNode.setLeft(new NodeB<>(child));
                result = true;
            } else {
                findNode.setRight(new NodeB<>(child));
                result = true;
            }
        }
        return result;
    }
    /**
     * finding the Node element in the tree.
     * @param element -
     * @param parent -
     * @return the Node element of tree
     */
    protected NodeB<E> findElement(E element, NodeB<E> parent) {
        NodeB<E> node = null;

        if (parent.value.equals(element)) {
            node = parent;
        } else {
            List<NodeB<E>> childList = new ArrayList<>();
            NodeB<E> childLeft = parent.left;
            NodeB<E> childRight = parent.right;
            if (childLeft != null) {
                childList.add(childLeft);
            }
            if (childRight != null) {
                childList.add(childRight);
            }

            for (NodeB<E> child : childList) {

                node = findElement(element, child);
                if (node != null) {
                    break;
                }
            }
        }
        return node;
    }
    /**
     * getAll.
     * @return the list of elements of the tree
     */
    public List<E> getAll() {
        List<E> list = new ArrayList<>();
        getList(list, base);
        return list;
    }
    /**
     * putting elements of a tree in the list.
     * @param list -
     * @param parent - beginning element
     */
    private void getList(List<E> list, NodeB<E> parent) {
        list.add(parent.value);

        List<NodeB<E>> childList = new ArrayList<>();
        NodeB<E> childLeft = parent.left;
        NodeB<E> childRight = parent.right;
        if (childLeft != null) {
            childList.add(childLeft);
        }
        if (childRight != null) {
            childList.add(childRight);
        }

        for (NodeB<E> element : childList) {
            getList(list, element);
        }
    }

    @Override
    public Iterator<E> iterator() {
        List<E> result = getAll();
        final int[] i = {0};
        return new Iterator<E>() {

            @Override
            public boolean hasNext() {
                return i[0] < result.size();
            }

            @Override
            public E next() {
                return result.get(i[0]++);
            }
        };
    }
}
