package ru.job4j.tree;
/**
 * SimpleTree.
 * the interface for the elementary structure of a tree
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 * @param <E>
 */
public interface SimpleTree<E extends Comparable<E>> extends Iterable<E> {
    /**
     * Добавить элемент child в parent.
     * Parent может иметь список child.
     * @param parent parent.
     * @param child child.
     * @return - boolean result
     */
    boolean addTree(E parent, E child);
}
