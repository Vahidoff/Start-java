package ru.job4j.generic;
/**
 * SimpleArray.
 * container for various types
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 * @param <T> - generic
 */
public class SimpleArray<T> {
    /**
     * array deposit.
     */
    private Object[] objects;
    /**
     * index of array.
     */
    private int index = 0;
    /**
     * constructor.
     * @param size -  a size of array
     */
    public SimpleArray(int size) {
        this.objects = new Object[size];
    }
    /**
     * getting objects.
     * @return - objects
     */
    public Object[] getObjects() {
        return this.objects;
    }
    /**
     * add. Adding new element to the array.
     * @param value - new element
     */
    public void add(T value) {
        this.objects[index++] = value;
    }
    /**
     * deleteValue. Deleting an element from the array.
     * @param value - deleted an element
     * @return - boolean result
     */
    public boolean deleteValue(T value) {
        boolean flag = false;
        for (int i = 0; i < objects.length; i++) {
            if (value == objects[i]) {
                objects[i] = null;
                flag = true;
            }
        }
        return flag;
    }
    /**
     * update. changing an element in the array.
     * @param value -
     * @param upValue - new element
     */
    public void update(T value, T upValue) {
        for (int i = 0; i < objects.length; i++) {
            if (value == objects[i]) {
                objects[i] = upValue;
            }
        }
    }
    /**
     * get. Search element by index.
     * @param position - index of array
     * @return - the element with entering an index
     */
    public T get(int position) {
        return (T) this.objects[position];
    }
}
