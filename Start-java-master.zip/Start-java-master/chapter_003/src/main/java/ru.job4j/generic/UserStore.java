package ru.job4j.generic;
/**
 * Store.
 * the deposit for User
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class UserStore {
    /**
     * name of deposit.
     */
    private String name;
    /**
     * size of deposit.
     */
    private int size;
    /**
     * deposit.
     */
    private Store<User> deposit;
    /**
     * constructor.
     * @param name - of deposit
     * @param size - of deposit
     */
    UserStore(String name, int size) {
        this.size = size;
        this.name = name;
        deposit = new Store<>(size);
    }
    /**
     * adding User.
     * @param user -
     */
    void add(User user) {
        this.deposit.getBasket().add(user);
    }
    /**
     * deleting User.
     * @param user -
     * @return boolean result
     */
    boolean delete(User user) {
        return this.deposit.getBasket().deleteValue(user);
    }
    /**
     * update. changing User in the deposit.
     * @param user -
     * @param upUser - new element
     */
    void update(User user, User upUser) {
        this.deposit.getBasket().update(user, upUser);
    }
    /**
     * get. Search element by index.
     * @param position - index of array
     * @return - the element with entering an index
     */
    User get(int position) {
        return this.deposit.getBasket().get(position);
    }
}
