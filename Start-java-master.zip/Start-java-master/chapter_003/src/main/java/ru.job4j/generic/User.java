package ru.job4j.generic;
/**
 * User.
 * extends Base
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class User extends Base {
    /**
     * User's name.
     */
    private String name;
    /**
     * constructor with setId.
     * @param name - User
     */
    public User(String name) {
        this.name = name;
        super.setId();
    }
    /**
     * getName.
     * @return - User's name
     */
    public String getName() {
        return name;
    }
}
