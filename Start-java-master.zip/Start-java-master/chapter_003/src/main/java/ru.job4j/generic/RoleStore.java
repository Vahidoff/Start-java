package ru.job4j.generic;
/**
 * RoleStore.
 * the deposit for Role
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class RoleStore extends Store {
    /**
     * name of deposit.
     */
    private String name;
    /**
     * size of deposit.
     */
    private Store<Role> deposit;
    /**
     * constructor.
     * @param name - of deposit
     * @param size - of deposit
     */
    RoleStore(String name, int size) {
        super(size);
        this.name = name;
        deposit = new Store<>(size);
    }
    /**
     * adding Role.
     * @param role -
     */
    void add(Role role) {
        this.deposit.getBasket().add(role);
    }
    /**
     * deleting Role.
     * @param role -
     * @return boolean result
     */
    boolean delete(Role role) {
        return this.deposit.getBasket().deleteValue(role);
    }
    /**
     * update. changing User in the deposit.
     * @param role -
     * @param upRole - new element
     */
    void update(Role role, Role upRole) {
        this.deposit.getBasket().update(role, upRole);
    }
    /**
     * get. Search element by index.
     * @param position - index of array
     * @return - the element with entering an index
     */
    Role get(int position) {
        return this.deposit.getBasket().get(position);
    }
}
