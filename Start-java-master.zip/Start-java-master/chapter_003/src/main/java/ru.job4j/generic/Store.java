package ru.job4j.generic;
/**
 * Store.
 * a deposit for User and Store
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 * @param <T> - extends Base
 */
public class Store<T extends Base> {
    /**
     * size of deposit.
     */
    private int size;
    /**
     * deposit for User and Role.
     */
    private SimpleArray<T> basket;
    /**
     * constructor.
     * @param size - of deposit
     */
    Store(int size) {
        this.size = size;
        basket = new SimpleArray<>(size);
    }
    /**
     * getBasket.
     * @return deposit
     */
    public SimpleArray<T> getBasket() {
        return basket;
    }
}
