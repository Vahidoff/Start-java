package ru.job4j.generic;

import java.util.Random;

/**
 * Base.
 * for User and Role
 * @author Aleksundrr Vahheedofv (mailto:arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public abstract class Base {
    /**
     * id.
     */
    private String id;
    /**
     * class Random variable.
     */
    private static final Random RN = new Random();
    /**
     * setId.
     * appropriation id
     */
    public void setId() {
        this.id = generateId();
    }
    /**
     * getId.
     * @return id.
     */
    public String getId() {
        return this.id;
    }
    /**
     * generateId.
     * @return String
     */
    private String generateId() {
        return String.valueOf(System.currentTimeMillis() + RN.nextInt()).substring(0, 5);
    }
}
