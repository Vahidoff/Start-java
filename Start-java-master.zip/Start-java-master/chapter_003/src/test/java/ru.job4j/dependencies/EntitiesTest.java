package ru.job4j.dependencies;
import org.junit.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Set;
import java.util.ArrayList;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * Test.
 * EntitiesTest
 *
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class EntitiesTest {
    /**
     * getting file paths.
     */
    private class DepositFile {
        /**
         * small test file.
         * test run separately.
         * https://yadi.sk/d/cp90CBOk3NLK9b
         */
        private final String file = "D:\\Users\\Arbuz333\\Temp Java\\Entities.xml";
    }
    /**
     * Test1.
     * readEntities.
     * @throws IOException - "file not find".
     */
    @Test
    public void whenReadEntitiesShouldContains() throws IOException {
        Entities entities = new Entities();
        DepositFile deposit = new DepositFile();
        ArrayList<Essence> al = entities.readEntities(deposit.file);

        StringBuilder result = new StringBuilder();
        for (Essence essence : al) {
            result.append(essence.getFirst()).append(" ");
            result.append(essence.getSecond()).append(" ");
            result.append("; ");
        }

        assertThat(result.toString(), is("4 5 ; 5 4 ; 7 4 ; 7 9 ; 9 10 ; 10 9 ; "
                + "5 9 ; 15 16 ; 16 17 ; 17 18 ; 18 15 ; "));
    }
    /**
     * Test2.
     * findCycle.
     * @throws IOException - "file not find".
     */
    @Test
    public void whenFindCycleShouldContainsCycle() throws IOException {
        Entities entities = new Entities();
        DepositFile deposit = new DepositFile();

        StringBuilder line = new StringBuilder();
        HashMap<Integer, LinkedList<Integer>> result = entities.findCycle(deposit.file);
        Set<Integer> set = result.keySet();
        for (Integer key : set) {
            line.append(result.get(key)).append(" ");
        }
        assertThat(line.toString(), is("[4, 5, 4] [9, 10, 9] [15, 16, 17, 18, 15] "));
    }
}
