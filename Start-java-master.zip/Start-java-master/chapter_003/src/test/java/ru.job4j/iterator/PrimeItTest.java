package ru.job4j.iterator;
import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * Test.
 * PrimeItTest
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class PrimeItTest {
    /**
     * Test1 PrimeIt.
     */
    @Test
    public void whenGetPrimeIteratorArray1ThenOutputPrimeNumbers() {
        int[] value = {9, 7, 4, 3, 8, 5, 6, 11, 13};
        PrimeIt itP = new PrimeIt(value);
        StringBuilder result = new StringBuilder();

        while (itP.hasNext()) {
            result.append(itP.next().toString()).append(" ");
        }

        assertThat(result.toString(), is("7 3 5 11 13 "));
    }
    /**
     * Test2 PrimeIt.
     */
    @Test
    public void whenGetPrimeIteratorArray2ThenOutputPrimeNumbers() {
        int[] value2 = {7, 3, 6};
        PrimeIt itP = new PrimeIt(value2);
        StringBuilder result = new StringBuilder();

        while (itP.hasNext()) {
            result.append(itP.next().toString()).append(" ");
        }

        assertThat(result.toString(), is("7 3 "));
    }
    /**
     * Test3 PrimeIt.
     */
    @Test
    public void whenGetPrimeIteratorArray3ThenOutputPrimeNumbers() {
        int[] value3 = {2, 8, 11, 5};
        PrimeIt itP = new PrimeIt(value3);
        StringBuilder result = new StringBuilder();

        while (itP.hasNext()) {
            result.append(itP.next().toString()).append(" ");
        }
        assertThat(result.toString(), is("2 11 5 "));
    }
}
