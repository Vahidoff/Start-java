package ru.job4j.iterator;
import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * Test.
 * IteratorTwoArray
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class EvenItTest {
    /**
     * Test1 EvenIt.
     */
    @Test
    public void whenGetEvenIteratorArrayThenOutputEvenNumbers() {
        int[] value = {2, 1, 7, 3, 4, 8, 5, 6};
        EvenIt itE = new EvenIt(value);
        StringBuilder result = new StringBuilder();

        while (itE.hasNext()) {
            result.append(itE.next().toString());
        }

        assertThat(result.toString(), is("2486"));
    }
    /**
     * Test2 EvenIt.
     */
    @Test
    public void whenGetEvenIteratorArray2ThenOutputEvenNumbers() {
        int[] value2 = {8, 2, 7, 3};
        EvenIt itE = new EvenIt(value2);
        StringBuilder result = new StringBuilder();

        while (itE.hasNext()) {
            result.append(itE.next().toString());
        }

        assertThat(result.toString(), is("82"));
    }
    /**
     * Test3 EvenIt.
     */
    @Test
    public void whenGetEvenIteratorArray3ThenOutputEvenNumbers() {
        int[] value3 = {3, 1, 6, 4};
        EvenIt itE = new EvenIt(value3);
        StringBuilder result = new StringBuilder();

        while (itE.hasNext()) {
            result.append(itE.next().toString());
        }

        assertThat(result.toString(), is("64"));
    }
}
