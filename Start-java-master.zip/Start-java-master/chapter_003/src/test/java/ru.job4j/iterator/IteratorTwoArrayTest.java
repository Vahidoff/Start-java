package ru.job4j.iterator;
import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * Test.
 * IteratorTwoArray
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class IteratorTwoArrayTest {
    /**
     * the array for test.
     */
    private int[][] value = {
            {1, 2, 7},
            {3, 4, 8},
            {5, 6}
    };
    /**
     * Test1 sortingUnits.
     */
    @Test
    public void whenGetIteratorDoubleArrayThenDirectOutput() {
        IteratorTwoArray itT = new IteratorTwoArray(value);
        StringBuilder result = new StringBuilder();

        while (itT.hasNext()) {
            result.append(itT.next().toString());
        }

        assertThat(result.toString(), is("12734856"));
    }
}
