package ru.job4j.iterator;

import org.junit.Test;


import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
/**
 * Test.
 * ConverterTest
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class ConverterTest {
    /**
     * Test1 convert.
     */
    @Test
    public void whenItHasTwoInnerIt() {
        Iterator<Iterator<Integer>> it = Arrays.asList(
                Collections.singletonList(1).iterator(),
                Collections.singletonList(2).iterator()
        ).iterator();
        Iterator<Integer> convert = new Converter().convert(it);
        convert.next();
        int result = convert.next();
        assertThat(result, is(2));
    }
    /**
     * Test2 convert.
     */
    @Test
    public void whenItHasThreeInnerIt() {
        List<Integer> li = new ArrayList<>();
        li.add(5);
        li.add(2);
        Iterator<Iterator<Integer>> it = Arrays.asList(
                Collections.singletonList(1).iterator(),
                Collections.singletonList(2).iterator(),
                li.iterator()
        ).iterator();
        Iterator<Integer> itI = new Converter().convert(it);

        int sum = 0;
        while (itI.hasNext()) {
            sum += itI.next();
        }

        assertThat(sum, is(10));
    }
}
