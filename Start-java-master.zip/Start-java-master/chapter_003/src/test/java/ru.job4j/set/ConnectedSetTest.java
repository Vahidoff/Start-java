package ru.job4j.set;
import org.junit.Test;

import java.util.Iterator;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
/**
 * Test.
 * ConnectedSetTest
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class ConnectedSetTest {
    /**
     * Test1 addCSet.
     */
    @Test
    public void whenAddConnectedSetThenContain() {
        ConnectedSet<Integer> csI = new ConnectedSet<>();
        csI.addCSet(23);
        csI.addCSet(5);
        csI.addCSet(12);
        csI.addCSet(5);
        csI.addCSet(7);
        csI.addCSet(23);

        StringBuilder result = new StringBuilder();
        Iterator<Integer> it = csI.iterator();
        while (it.hasNext()) {
            result.append(it.next().toString()).append(" ");
        }

        assertThat(result.toString(), is("23 5 12 7 "));
    }
    /**
     * Test2 addCSet null.
     */
    @Test
    public void whenAddNullConnectedSetThenContain() {
        ConnectedSet<Character> csC = new ConnectedSet<>();
        csC.addCSet('j');
        csC.addCSet(null);
        csC.addCSet('T');
        csC.addCSet('j');
        csC.addCSet(null);
        csC.addCSet('a');

        Iterator<Character> ic = csC.iterator();
        assertThat(ic.next(), is('j'));
        assertNull(ic.next());
        assertThat(ic.next(), is('T'));
        assertThat(ic.next(), is('a'));
    }

}
