package ru.job4j.set;
import org.junit.Test;

import java.util.Iterator;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
/**
 * Test.
 * SimpleSetTest
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class SimpleSetTest {
    /**
     * Test1 add.
     */
    @Test
    public void whenAddSimpleSetThenContain() {
        SimpleSet<Integer> ssI = new SimpleSet<>();
        ssI.add(1);
        ssI.add(15);
        ssI.add(19);
        ssI.add(15);
        ssI.add(1);
        ssI.add(3);

        StringBuilder result = new StringBuilder();
        Iterator<Integer> it = ssI.iterator();
        while (it.hasNext()) {
            result.append(it.next().toString()).append(" ");
        }

        assertThat(result.toString(), is("1 15 19 3 "));
    }
    /**
     * Test1 add null.
     */
    @Test
    public void whenAddNullSimpleSetThenContain() {
        SimpleSet<Integer> ssI = new SimpleSet<>();
        ssI.add(1);
        ssI.add(15);
        ssI.add(null);
        ssI.add(1);
        ssI.add(null);
        ssI.add(3);

        Iterator<Integer> it = ssI.iterator();

        assertThat(it.next(), is(1));
        assertThat(it.next(), is(15));
        assertNull(it.next());
        assertThat(it.next(), is(3));
    }
}
