package ru.job4j.set;
import org.junit.Test;

import java.util.Iterator;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
/**
 * Test.
 * SimpleSetTest
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class SimpleFastSetTest {
    /**
     * Test1 addSFastSet.
     */
    @Test
    public void whenAddSimpleSetThenContain() {
        SimpleFastSet<Integer> sfSI = new SimpleFastSet<>();
        sfSI.addSFastSet(5);
        sfSI.addSFastSet(7);
        sfSI.addSFastSet(4);
        sfSI.addSFastSet(5);
        sfSI.addSFastSet(7);
        sfSI.addSFastSet(3);

        StringBuilder result = new StringBuilder();
        Iterator<Integer> it = sfSI.iterator();
        while (it.hasNext()) {
            result.append(it.next().toString()).append(" ");
        }

        assertThat(result.toString(), is("5 7 4 3 "));
    }
    /**
     * Test2 addSFastSet.
     * comparison of the speed of insertion of elements into
     * SimpleFastSet and ConnectedSet
     */
    @Test
    public void whenAddSimpleSetThenTime() {
        SimpleFastSet<Integer> sfSI = new SimpleFastSet<>();
        long start, end;
        start = System.nanoTime();
        for (int i = 100; i < 1000; i++) {
            sfSI.addSFastSet(i);
        }
        end = System.nanoTime();
        long speedFastSet = end - start;

        ConnectedSet<Integer> cSI = new ConnectedSet<>();
        long start2, end2;
        start2 = System.nanoTime();
        for (int i = 100; i < 1000; i++) {
            cSI .addCSet(i);
        }
        end2 = System.nanoTime();
        long speedSet = end2 - start2;

        System.out.format(" %d  speed %d", speedFastSet, speedSet);

    }

}

