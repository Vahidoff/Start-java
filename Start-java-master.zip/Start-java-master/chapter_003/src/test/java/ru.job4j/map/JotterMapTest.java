package ru.job4j.map;
import org.junit.Test;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Iterator;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * Test.
 * JotterMap
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class JotterMapTest {
    /**
     * creating the handbook.
     */
    private JotterMap<UserMap, String> jotter = new JotterMap<>();
    /**
     * filling in a handbook.
     */
    private void createJotter() {
        Calendar birthday1 = new GregorianCalendar(2005, 11, 7);
        Calendar birthday2 = new GregorianCalendar(2015, 5, 15);
        Calendar birthday3 = new GregorianCalendar(2010, 10, 23);
        UserMap first = new UserMap("Isak", 3, birthday1);
        UserMap second = new UserMap("Tom", 0, birthday2);
        UserMap third = new UserMap("Tad", 4, birthday3);
        UserMap fourth = new UserMap("Ram", 1, birthday3);
        UserMap sixth = new UserMap("Kat", 2, birthday2);
        UserMap fifth = new UserMap("Mill", 1, birthday1);
        jotter.insert(first, "first");
        jotter.insert(second, "second");
        jotter.insert(third, "third");
        jotter.insert(fourth, "fourth");

        jotter.insert(second, "second");
        jotter.insert(fifth, "fifth");
        jotter.insert(sixth, "sixth");
    }
    /**
     * Test1 insert.
     */
    @Test
    public void whenInsertJotterMapShouldContains() {
        createJotter();

        StringBuilder result = new StringBuilder();
        Iterator<Entry> it = jotter.iterator();
        while (it.hasNext()) {
            result.append(it.next().getValue().toString()).append(" ");
        }

        assertThat(result.toString(), is("fifth second first sixth third fourth "));
    }
    /**
     * Test2 get.
     */
    @Test
    public void whenGetJotterMapShouldExtradition() {
        Calendar birthday1 = new GregorianCalendar(2005, 11, 7);
        Calendar birthday2 = new GregorianCalendar(2015, 5, 15);
        UserMap first = new UserMap("Isak", 3, birthday1);
        UserMap second = new UserMap("Tom", 0, birthday2);
        UserMap third = new UserMap("Tad", 4, birthday1);
        jotter.insert(first, "first");
        jotter.insert(second, "second");
        jotter.insert(third, "third");

        assertThat(jotter.get(third), is("third"));
        assertThat(jotter.get(first), is("first"));

        jotter.insert(third, "fifth");

        assertThat(jotter.get(third), is("fifth"));
    }
    /**
     * Test3 delete.
     */
    @Test
    public void whenDeleteElementShouldNo() {
        Calendar birthday1 = new GregorianCalendar(2005, 11, 7);
        Calendar birthday2 = new GregorianCalendar(2015, 5, 15);
        UserMap first = new UserMap("Isak", 3, birthday1);
        UserMap second = new UserMap("Tom", 0, birthday2);
        UserMap third = new UserMap("Tad", 4, birthday1);
        jotter.insert(first, "first");
        jotter.insert(second, "second");
        jotter.insert(third, "third");

        jotter.delete(second);

        StringBuilder result = new StringBuilder();
        Iterator<Entry> it = jotter.iterator();
        while (it.hasNext()) {
            result.append(it.next().getValue().toString()).append(" ");
        }

        assertThat(result.toString(), is("third first "));
    }
}
