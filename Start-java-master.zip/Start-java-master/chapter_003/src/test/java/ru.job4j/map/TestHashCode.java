package ru.job4j.map;
import org.junit.Test;
import ru.job4j.generic.User;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * TestHashCode.
 * checking the rules for override the method hashCode
 */
public class TestHashCode {
    /**
     * Test 1.
     * Если поле value имеет тип boolean, вычислите (value ? О : 1).
     */
    @Test
    public void whenHashCodeSameObjectShouldTrue() {
        /**
         * class with a boolean field.
         */
        class ABoolean {
            private boolean flag;
            /**
             * constructor.
             * @param flag - boolean
             */
            protected ABoolean(boolean flag) {
                this.flag = flag;
            }
            /**
             * equals.
             * @param ab - ABoolean
             * @return boolean result
             */
            public boolean equals(ABoolean ab) {
                return this.flag == ab.flag;
            }
            @Override
            public int hashCode() {
                return this.flag ? 0 : 1;
            }
        }

        ABoolean a = new ABoolean(true);
        ABoolean b = new ABoolean(false);
        ABoolean c = new ABoolean(true);

        assertThat(a.equals(b), is(false));
        assertThat(b.equals(c), is(false));
        assertThat(a.equals(c), is(true));
    }
    /**
     * Test 2.
     * Если поле value имеет тип byte, char, short или int, вычислите (int)value.
     */
    @Test
    public void whenHashByteShouldTrue() {
        /**
         * class with a byte field.
         */
        class BByte {
            private byte value;
            /**
             * constructor.
             * @param value byte
             */
            protected BByte(byte value) {
                this.value = value;
            }
            /**
             * equals.
             * @param bb - BByte
             * @return boolean result
             */
            public boolean equals(BByte bb) {
                return this.value == bb.value;
            }
            @Override
            public int hashCode() {
                return ((int) value);
            }
        }
        BByte a = new BByte((byte) 12);
        BByte b = new BByte((byte) 7);
        BByte c = new BByte((byte) 12);

        assertThat(a.equals(b), is(false));
        assertThat(b.equals(c), is(false));
        assertThat(a.equals(c), is(true));
    }
    /**
     * Test 3.
     * Если поле value имеет тип long, вычислите (int)(value - (value >>> 32))
     * Если поле value имеет тип float, вычислите Float.floatToIntBits(value).
     */
    @Test
    public void whenHashLongFloatShouldTrue() {
        /**
         * class with a long and a float field.
         */
        class LongFloatHash {
            private long l;
            private float f;
            /**
             * constructor.
             * @param l long
             * @param f float
             */
            LongFloatHash(long l, float f) {
                this.f = f;
                this.l = l;
            }
            /**
             * equals.
             * @param lfh - LongFloatHash
             * @return boolean result
             */
            public boolean equals(LongFloatHash lfh) {
                return lfh.l == this.l & lfh.f == this.f;
            }
            @Override
            public int hashCode() {
                int result = 1;
                int h = 37;
                result = result * h + (int) (this.l - (this.l >>> 32));
                return result * h + Float.floatToIntBits(this.f);
            }
        }
        LongFloatHash a = new LongFloatHash(123L, 123.4F);
        LongFloatHash b = new LongFloatHash(12345L, 12345.6F);
        LongFloatHash c = new LongFloatHash(123L, 123.4F);

        assertThat(a.equals(b), is(false));
        assertThat(b.equals(c), is(false));
        assertThat(a.equals(c), is(true));
    }
    /**
     * Test 4.
     * Если поле value имеет тип double, вычислите Double.doubleToLongBits(value),
     * а затем преобразуйте полученное значение, как указано в п.4
     * Если поле value является ссылкой на объект, вызывайте метод hashCode() этого объекта
     */
    @Test
    public void whenDoubleUserShouldTrue() {
        /**
         * class with a double field.
         */
        class DoubleUserHash {
            private double aDouble;
            private User user;
            /**
             * constructor.
             * @param aDouble -
             * @param user -
             */
            DoubleUserHash(double aDouble, User user) {
                this.aDouble = aDouble;
                this.user = user;
            }
            /**
             * equals.
             * @param duh - DoubleUserHash
             * @return boolean result
             */
            public boolean equals(DoubleUserHash duh) {
                return duh.user.equals(this.user) & duh.aDouble == this.aDouble;
            }
            @Override
            public int hashCode() {
                int result = 1;
                int h = 37;
                long l = Double.doubleToLongBits(this.aDouble);
                result = result * h + (int) (l - (l >>> 32));
                return result * h + this.user.hashCode();
            }
        }
        User user1 = new User("Tad");
        User user2 = new User("Lora");
        DoubleUserHash a = new DoubleUserHash(123.4, user1);
        DoubleUserHash b = new DoubleUserHash(123.5, user2);
        DoubleUserHash c = new DoubleUserHash(123.4, user1);

        assertThat(a.equals(b), is(false));
        assertThat(b.equals(c), is(false));
        assertThat(a.equals(c), is(true));
    }
    /**
     * Test 5.
     * Если поле является массивом, примените данные правила для каждого элемента массива
     * Объедините полученные значения следующим образом: 37*result + value.
     */
    @Test
    public void whenArrayHashShouldTrue() {
        /**
         * class with a array field.
         */
        class ArrayHash {
            private String[] st;
            /**
             * constructor.
             * @param st - array
             */
            ArrayHash(String[] st) {
                this.st = st;
            }
            /**
             * equals.
             * @param arrayHash - ArrayHash
             * @return boolean result
             */
            public boolean equals(ArrayHash arrayHash) {
                boolean flag = false;
                for (int i = 0; i < this.st.length; i++) {
                    flag = this.st[i].equals(arrayHash.st[i]);
                }
                return flag;
            }
            @Override
            public int hashCode() {
                int result = 1;
                for (String i : this.st) {
                    result = result * 37 + i.hashCode();
                }
                return result;
            }
        }
        String[] st1 = {"first", "second", "third"};
        String[] st2 = {"fourth", "fifth", "sixth"};
        String[] st3 = {"first", "second", "third"};
        ArrayHash arrayHash1 = new ArrayHash(st1);
        ArrayHash arrayHash2 = new ArrayHash(st2);
        ArrayHash arrayHash3 = new ArrayHash(st3);

        assertThat(arrayHash1.equals(arrayHash2), is(false));
        assertThat(arrayHash2.equals(arrayHash3), is(false));
        assertThat(arrayHash1.equals(arrayHash3), is(true));
    }
}
