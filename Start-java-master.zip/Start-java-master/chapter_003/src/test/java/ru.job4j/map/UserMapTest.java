package ru.job4j.map;
import org.junit.Test;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Map;
import java.util.HashMap;

/**
 * Test.
 * UserMap
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class UserMapTest {
    /**
     * Test1.
     * add two objects with same fields to the map
     *
     * Test2
     * 3. Перекрывать hashCode #1003
     * результат {ru.job4j.map.UserMap@51521cc1=Senior, ru.job4j.map.UserMap@1376c05c=Middle}
     * При добавлении значения в HashMap ключ нового элемента сравнивается с ключами имеющихся
     * при этом испльзуются значения методов hashCode() и equals().
     * В этом случае у объектов-ключей first и second будут одинаковые хэши, но результат вызова
     * метода equals() будет false,т. к. он сравнивает ссылки, а не содержимое объектов, т. е.
     * адреса объектов во внутренней памяти.
     * Поэтому при выполнении метода put() в HashMap, объекты-ключи first и second являются двумя разными ключами,
     * поэтому произойдет запись двух пар ключь-значение в одну ячейку корзины.
     *
     * Test3
     * 4. Перекрывать equals [#1004]
     * результат  {ru.job4j.map.UserMap@51521cc1=Senior, ru.job4j.map.UserMap@1376c05c=Middle}
     * При добавлении значения в HashMap ключ нового элемента сравнивается с ключами имеющихся
     * при этом испльзуются значения методов hashCode() и equals().
     * В этом случае у ключей first и second будут разные хэши, т. к. они возникли в разное время и имеют разные ссылки
     * на внутреннюю память. Не смотря на то, что метод equals() возвратит true,
     * данные объекты будут являться разными ключами.
     * В итоге произойдет запись двух пар ключь-значение в HashMap.
     *
     * Test4
     * 5. Перекрывать и equals и hashCode [#1002]
     * результат {ru.job4j.map.UserMap@6324335d=Senior}
     * В данном случае переопределены два метода hashCode() и equals(), в которых учитываются поля
     * ключей first и second. Так как поля идинаковые, то метод hashCode() вернет одинаковые значения
     * метод equals() вернет true. Таким образом ключи являются одинаковыми и проезойдет замена
     * значения одинаковых ключей при добавлении пары ("Middle" заменяется на "Senior").
     */
    @Test
    public void whenAddSameFieldsShouldOverwriting() {
        Calendar birthday = new GregorianCalendar(2005, 11, 5);
        UserMap first = new UserMap("Iskandar", 3, birthday);
        UserMap second = new UserMap("Iskandar", 3, birthday);

        Map<UserMap, String> map = new HashMap<>();
        map.put(first, "Middle");
        map.put(second, "Senior");

        System.out.println(map);
    }
}
