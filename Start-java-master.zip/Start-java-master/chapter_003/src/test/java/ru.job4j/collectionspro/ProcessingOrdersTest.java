package ru.job4j.collectionspro;

import org.junit.Test;

import java.io.FileNotFoundException;
import java.util.TreeSet;
import java.util.Set;
import java.util.TreeMap;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * Test.
 * ProcessingOrders
 *
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class ProcessingOrdersTest {
    /**
     * getting file paths.
     */
    class DepositFile {
        /**
         * @return file.
         */
        String getFILE() {
            return file;
        }

        /**
         * @return file2.
         */
        String getFILE2() {
            return file2;
        }

        /**
         * small test file.
         * test run separately.
         * https://yadi.sk/d/iqha1T2W3MmCVN
         */
        private final String file = "D:\\Users\\Arbuz333\\Temp Java\\Orders\\orders555.xml";
        /**
         * order.xml - go to the test 4.
         * https://yadi.sk/d/cciS7Dqy35uQjU
         */
        private final String file2 = "D:\\Users\\Arbuz333\\Temp Java\\Orders\\orders.xml";
    }

    /**
     * show orders in treeMp.
     *
     * @param treeMap - TreeMap<String, HashMap<Order.Type, TreeSet<Order>>>
     * @return string result
     */
    private String stringOrders(TreeMap<String, TreeMap<Order.Type, TreeSet<Order>>> treeMap) {
        Set<String> books = treeMap.keySet();
        StringBuilder result = new StringBuilder();
        for (String book : books) {
            result.append(book).append(" ");
            TreeMap<Order.Type, TreeSet<Order>> tempType = treeMap.get(book);
            Set<Order.Type> setType = tempType.keySet();
            for (Order.Type type : setType) {
                result.append(type).append(" ");
                TreeSet<Order> orders = tempType.get(type);
                for (Order temp : orders) {
                    result.append(temp.getPrice()).append("-").append(temp.getValue()).append(", ");
                }
                result.append("; ");
            }
        }
        return result.toString();
    }

    /**
     * Test1.
     * sort ascending for "SELL" and sorting in decreasing for "BUY".
     *
     * @throws FileNotFoundException - "file not find".
     */
    @Test
    public void whenProcessingOrdersShouldContains() throws FileNotFoundException {
        ProcessingOrders process = new ProcessingOrders();
        DepositFile deposit = new DepositFile();

        Set<String> setBook = process.sortSellBuy(deposit.file).keySet();
        System.out.println(setBook);

        StringBuilder result = new StringBuilder();
        TreeMap<String, TreeMap<Order.Type, TreeMap<Order, Float>>> temp;
        temp = process.sortSellBuy(deposit.file);
        for (String book : setBook) {
            result.append(book).append(" ");
            Set<Order.Type> setType = temp.get(book).keySet();
            for (Order.Type type : setType) {
                result.append(type).append(" ");
                Set<Order> setOrder = temp.get(book).get(type).keySet();
                for (Order order : setOrder) {
                    result.append(order.getPrice()).append("-").append(order.getValue()).append(", ");
                }
                result.append("; ");

            }
        }
        assertThat(result.toString(), is("book-1 SELL 30.4-95, 30.4-115, 70.4-125, ; "
                + "BUY 69.4-65, 68.3-47, 68.3-45, ; book-2 SELL 69.9-84, 70.1-23, 70.1-37, ; "
                + "BUY 70.6-87, 70.6-21, 68.3-41, ; book-3 SELL 90.4-12, 100.4-52, 170.4-32, ; "
               + "BUY 150.4-31, 110.4-51, 70.4-61, 70.4-11, ; "));
    }

    /**
     * Test2 aggregation.
     * we put together orders with the same price
     *
     * @throws FileNotFoundException - "file not find".
     */
    @Test
    public void whenAggregationShouldAggregationBook() throws FileNotFoundException {
        ProcessingOrders process = new ProcessingOrders();
        DepositFile deposit = new DepositFile();
        OrderBooks orderBooks = new OrderBooks(process.sortSellBuy(deposit.file));
        Set<String> setBook = process.sortSellBuy(deposit.file).keySet();
        System.out.println(setBook);

        TreeMap<String, TreeMap<Order.Type, TreeSet<Order>>> noDuplicates = orderBooks.aggregation();
        String result = this.stringOrders(noDuplicates);

        assertThat(result, is("book-1 SELL 30.4-210, 70.4-125, ; BUY 69.4-65, 68.3-92, ; "
                + "book-2 SELL 69.9-84, 70.1-60, ; "
                + "BUY 70.6-108, 68.3-41, ; book-3 SELL 90.4-12, 100.4-52, 170.4-32, ; "
                + "BUY 150.4-31, 110.4-51, 70.4-72, ; "));
    }

    /**
     * Test3 removalUnprofitableDeals.
     * delete unprofitable deals
     *
     * @throws FileNotFoundException - "file not find".
     */
    @Test
    public void whenRemovalUnprofitableDealsShouldProfitable() throws FileNotFoundException {
        ProcessingOrders process = new ProcessingOrders();
        DepositFile deposit = new DepositFile();
        OrderBooks orderBooks = new OrderBooks(process.sortSellBuy(deposit.file));
        TreeMap<String, TreeMap<Order.Type, TreeSet<Order>>> removalNonprofits =
                orderBooks.removalUnprofitableDeals();

        String result = this.stringOrders(removalNonprofits);

        assertThat(result, is("book-1 SELL 30.4-210, 70.4-125, ; BUY ; "
                + "book-2 SELL 70.1-60, ; BUY 68.3-41, ; "
                + "book-3 SELL 100.4-52, 170.4-32, ; BUY 70.4-72, ; "));
    }

    /**
     * Test4 - show result for the file2.
     *
     * @throws FileNotFoundException - "file not find".
     */
    @Test
    public void whenShowResultShouldPrint() throws FileNotFoundException {
        long start, end;
        start = System.nanoTime();
        DepositFile deposit = new DepositFile();

        ProcessingOrders process = new ProcessingOrders();
        OrderBooks orderBooks = new OrderBooks(process.sortSellBuy(deposit.file));

        orderBooks.showResult();

        end = System.nanoTime();
        long speedFastSet = end - start;
        System.out.format(" speed %,5d", speedFastSet);
    }

}
