package ru.job4j.generic;

import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * Test.
 * SimpleArray
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class SimpleArrayTest {
    /**
     * Test1 add.
     */
    @Test
    public void whenAddElementThenContain() {
        SimpleArray<String> solid = new SimpleArray<>(4);
        solid.add("Tom");
        solid.add("Rob");
        solid.add("Cat");
        solid.add("Sam");

        StringBuilder result = new StringBuilder();
        for (Object st : solid.getObjects()) {
            result.append(st).append(" ");
        }

        assertThat(result.toString(), is("Tom Rob Cat Sam "));
    }
    /**
     * Test2 deleteValue.
     */
    @Test
    public void whenDeleteElementThenElementIsNull() {
        SimpleArray<String> solid = new SimpleArray<>(4);
        solid.add("Tom");
        solid.add("Rob");
        solid.add("Cat");
        solid.add("Sam");
        solid.deleteValue("Cat");

        StringBuilder result = new StringBuilder();
        for (Object st : solid.getObjects()) {
            result.append(st).append(" ");
        }

        assertThat(result.toString(), is("Tom Rob null Sam "));
    }
    /**
     * Test3 update.
     */
    @Test
    public void whenDeleteUpdateThenElementIsNew() {
        SimpleArray<Integer> solid = new SimpleArray<>(2);
        solid.add(1);
        solid.add(5);

        solid.update(5, 8);

        assertThat(solid.get(1), is(8));
    }
}
