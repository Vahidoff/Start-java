package ru.job4j.generic;

import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

/**
 * Test.
 * tests for UserStore and RoleStore
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class StoreTest {
    /**
     * Test1 add UserStore.
     */
    @Test
    public void whenAddUserStoreThenContain() {
        UserStore users = new UserStore("Customers", 3);
        User tom = new User("Tom");
        User bob = new User("Bob");
        users.add(new User("Sam"));
        users.add(bob);
        users.add(new User("Cat"));

        users.update(bob, tom);
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < 3; i++) {
            result.append(users.get(i).getName()).append(" ");
        }

        assertThat(result.toString(), is("Sam Tom Cat "));
    }
    /**
     * Test2 add RoleStore.
     */
    @Test
    public void whenAddRoleStoreThenContain() {
        RoleStore roles = new RoleStore("Goods", 3);
        Role bob = new Role("Bob");
        roles.add(bob);
        roles.add(new Role("Sam"));
        roles.add(new Role("Cat"));

        roles.delete(bob);

        assertNull(roles.get(0));
        assertThat(roles.get(1).getName(), is("Sam"));
        assertThat(roles.get(2).getName(), is("Cat"));
    }
}