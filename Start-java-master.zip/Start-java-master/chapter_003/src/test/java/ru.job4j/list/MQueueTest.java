package ru.job4j.list;
import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
/**
 * Test.
 * MQueueTest
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class MQueueTest {
    /**
     * Test1 add, get.
     */
    @Test
    public void whenAddIntegerMQueueTestThenContain() {
        MQueue<Integer> mqI = new MQueue<>();
        for (int i = 1; i < 8; i++) {
            mqI.offer(i);
        }

        StringBuilder result = new StringBuilder();
        for (int i = 1; i < 8; i++) {
            result.append(mqI.peek()).append(" ");
        }

        assertThat(result.toString(), is("1 2 3 4 5 6 7 "));
    }
    /**
     * Test2 add, get.
     */
    @Test
    public void whenAddStringMQueueTestThenContain() {
        MQueue<String> mqS = new MQueue<>();
        for (int i = 65; i < 70; i++) {
            mqS.offer(Character.toString((char) i));
        }

        StringBuilder result = new StringBuilder();
        for (int i = 65; i < 70; i++) {
            result.append(mqS.peek()).append(" ");
        }

        assertThat(result.toString(), is("A B C D E "));
    }
}
