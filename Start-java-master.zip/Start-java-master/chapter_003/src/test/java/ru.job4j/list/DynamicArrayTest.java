package ru.job4j.list;
import org.junit.Test;

import java.util.Iterator;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
/**
 * Test.
 * DynamicArray
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class DynamicArrayTest {
    /**
     * Test1 add.
     */
    @Test
    public void whenAddDynamicArrayThenContain() {
        DynamicArray<Integer> da = new DynamicArray<>();
        for (int i = 0; i < 10; i++) {
            da.add(i);
        }
        da.add(22);

        StringBuilder result = new StringBuilder();
        Iterator<Integer> it = da.iterator();
        while (it.hasNext()) {
            result.append(it.next().toString()).append(" ");
        }

        assertThat(result.toString(), is("0 1 2 3 4 5 6 7 8 9 22 "));
        assertThat(da.getContainer().length, is(20));
    }
    /**
     * Test2 add.
     */
    @Test
    public void whenAddStringDynamicArrayThenContain() {
        DynamicArray<String> daS = new DynamicArray<>();
        for (int i = 65; i < 70; i++) {
            daS.add(Character.toString((char) i));
        }

        StringBuilder result = new StringBuilder();
        Iterator<String> it = daS.iterator();
        while (it.hasNext()) {
            result.append(it.next()).append(" ");
        }

        assertThat(result.toString(), is("A B C D E "));
        assertThat(daS.getContainer().length, is(10));
    }
    /**
     * Test3 get.
     */
    @Test
    public void whenGetCharDynamicArrayThenContain() {
        DynamicArray<Character> daC = new DynamicArray<>();
        daC.add('a');
        daC.add('b');
        daC.add('c');

        assertNull(daC.get(3));
        assertThat(daC.get(2), is('c'));
    }
}
