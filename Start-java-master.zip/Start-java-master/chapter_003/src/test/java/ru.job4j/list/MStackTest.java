package ru.job4j.list;
import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
/**
 * Test.
 * MStackTest
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class MStackTest {
    /**
     * Test1 add, get.
     */
    @Test
    public void whenAddIntegerMStackTestThenContain() {
        MStack<Integer> msI = new MStack<Integer>();
        for (int i = 1; i < 8; i++) {
            msI.push(i);
        }

        StringBuilder result = new StringBuilder();
        for (int i = 1; i < 8; i++) {
            result.append(msI.pop()).append(" ");
        }

        assertThat(result.toString(), is("7 6 5 4 3 2 1 "));
    }
    /**
     * Test2 add, get.
     */
    @Test
    public void whenAddStringMStackTestThenContain() {
        MStack<String> msS = new MStack<String>();
        for (int i = 65; i < 70; i++) {
            msS.push(Character.toString((char) i));
        }

        StringBuilder result = new StringBuilder();
        for (int i = 65; i < 70; i++) {
            result.append(msS.pop()).append(" ");
        }

        assertThat(result.toString(), is("E D C B A "));
    }
}

