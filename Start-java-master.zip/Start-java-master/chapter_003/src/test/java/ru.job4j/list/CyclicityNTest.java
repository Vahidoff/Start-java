package ru.job4j.list;
import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
/**
 * Test.
 * ConnectedListTest
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class CyclicityNTest {
    /**
     * Test1 add, get.
     */
    @Test
    public void whenContainerCyclicityThenTrue() {
        CyclicityN<Integer> cnI = new CyclicityN<>();

        Node<Integer> first = new Node<>(1, null);
        Node<Integer> four = new Node<>(4, first);
        Node<Integer> third = new Node<>(3, four);
        Node<Integer> two = new Node<>(2, third);
        first.setNext(two);

        assertThat(cnI.hasCycle(first), is(true));
    }
    /**
     * Test1 add, get.
     */
    @Test
    public void whenContainerNonCyclicityThenTrue() {
        CyclicityN<Integer> cnI = new CyclicityN<>();

        Node<Integer> first = new Node<>(1, null);
        Node<Integer> four = new Node<>(4, first);
        Node<Integer> third = new Node<>(3, four);
        Node<Integer> two = new Node<>(2, third);

        Node<Integer> eleven = new Node<>(11, null);
        first.setNext(eleven);

        assertThat(cnI.hasCycle(first), is(false));
    }
}