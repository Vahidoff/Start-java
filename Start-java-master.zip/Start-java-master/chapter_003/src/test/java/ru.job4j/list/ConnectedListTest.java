package ru.job4j.list;
import org.junit.Test;

import java.util.Iterator;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
/**
 * Test.
 * ConnectedListTest
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class ConnectedListTest {
    /**
     * Test1 add, get.
     */
    @Test
    public void whenAddConnectedListThenContain() {
        ConnectedList<Integer> clI = new ConnectedList<>();
        clI.add(null);
        clI.add(155);

        assertNull(clI.get(0));
        assertThat(clI.get(1), is(155));
    }
    /**
     * Test2 iterator.
     */
    @Test
    public void whenAddConnectedListThenIterator() {
        ConnectedList<String> clS = new ConnectedList<>();
        for (int i = 65; i < 70; i++) {
            clS.add(Character.toString((char) i));
        }

        StringBuilder result = new StringBuilder();
        Iterator<String> it = clS.iterator();
        while (it.hasNext()) {
            result.append(it.next()).append(" ");
        }

        assertThat(result.toString(), is("A B C D E "));
    }
}
