package ru.job4j.tree;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * Test.
 * MTree
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class MTreeTest {
    /**
     * Test1 addTree and Iterator.
     */
    @Test
    public void whenAddMTreeShouldContains() {
        MTree<Integer> mTree = new MTree<>(0);
        mTree.addTree(0, 1);
        mTree.addTree(1, 2);
        mTree.addTree(1, 3);
        mTree.addTree(3, 22);
        mTree.addTree(3, 11);

        StringBuilder result = new StringBuilder();
        Iterator<Integer> it = mTree.iterator();
        while (it.hasNext()) {
            result.append(it.next().toString()).append(" ");
        }

        assertThat(result.toString(), is("0 1 2 3 22 11 "));
    }
    /**
     * Test2 addTree.
     */
    @Test
    public void whenAddMTreeStringShouldContains() {
        List<String> list = new ArrayList<>(Arrays.asList("0", "1", "2", "3", "6", "4", "5"));
        MTree<String> mTree = new MTree<>("0");
        mTree.addTree("0", "1");
        mTree.addTree("1", "2");
        mTree.addTree("1", "3");
        mTree.addTree("3", "6");
        mTree.addTree("3", "4");
        mTree.addTree("3", "5");

        List<String> result = mTree.getAll();

        assertThat(result, is(list));
    }
    /**
     * Test3 addTree and isBinary.
     */
    @Test
    public void whenAddMTreeBinaryShouldTrue() {
        MTree<Integer> mTree = new MTree<>(0);
        mTree.addTree(0, 1);
        mTree.addTree(0, 3);
        mTree.addTree(1, 4);
        mTree.addTree(1, 5);
        mTree.addTree(3, 6);
        mTree.addTree(3, 7);

        assertThat(mTree.isBinary(), is(true));
    }
    /**
     * Test4 addTree and isBinary.
     */
    @Test
    public void whenAddMTreeNotBinaryShouldFalse() {
        MTree<Integer> mTree = new MTree<>(0);
        mTree.addTree(0, 1);
        mTree.addTree(0, 3);
        mTree.addTree(1, 4);
        mTree.addTree(1, 5);
        mTree.addTree(1, 6);
        mTree.addTree(3, 7);

        assertThat(mTree.isBinary(), is(false));
    }
}

