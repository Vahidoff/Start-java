package ru.job4j.tree;
import org.junit.Test;

import java.util.Iterator;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

/**
 * Test.
 * BinaryTree
 * @author Aleksundrr Vahheedofv (arbuzz333@hotmail.com)
 * @version $Id$
 * @since 0.1
 */
public class BinaryTreeTest {
    /**
     * Test1 addTree and Iterator.
     */
    @Test
    public void whenAddBinaryTreeShouldContains() {
        BinaryTree<Integer> bTree = new BinaryTree<>(0);
        bTree.addTree(0, -2);
        bTree.addTree(0, 1);
        bTree.addTree(1, -1);
        bTree.addTree(1, 2);
        bTree.addTree(2, 1);
        bTree.addTree(2, 3);
        bTree.addTree(3, 2);
        bTree.addTree(3, 4);
        bTree.addTree(4, -3);
        bTree.addTree(4, 5);

        StringBuilder result = new StringBuilder();
        Iterator<Integer> it = bTree.iterator();
        while (it.hasNext()) {
            result.append(it.next().toString()).append(" ");
        }

        assertThat(result.toString(), is("0 -2 1 -1 2 1 3 2 4 -3 5 "));
    }
}
