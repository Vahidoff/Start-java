# Aleksandr Vahidov

# Здесь собраны мои давние изыскания JAVA

### chapter_009.
###  Сайт объявлений продаж автомобилей 
	1) Chapter spring_mvc: это web приложение по функционалу полностью совпадает с приложением
	  из Chapter 2_car_site. Однако back-end полностью переработан и основан на Spring MVC.
	2) Chapter spring_jpa: Аналогичное web приложение, но back-ebd выполнен с использованием 
	  Spring and JPA так же Spring Security. Реализовано взоимодействие с пользователями, которые 
	  имеют разные роли. Доступ к определенным страницам происходит согласно настройкам WebSecurityConfig.java

### chapter_008: Chapter 2_car_site

### Реализовать площадку продаж машин. 
	Это web приложение со следующими страницами.
	1. основная страница. таблица со всеми объявлениям машин на продажу.
	2. на странице есть кнопка. добавить новое объявление.
	3. переход на страницу добавления.
	4. есть категории машины. марка. описание и тд. 
	5. важно! добавление фото. использовать библиотеку apache fileuppload
	6. объявление имеет статус продано. или нет.
	7. должны существовать пользователи. кто подал заявление. только он может менять статус.
	
### Список объявлений:
	
<a href='https://s9.postimg.org/3t4wbs7kv/Car_shop_2.png'>
     <img src='https://s9.postimg.org/3t4wbs7kv/Car_shop_2.png' width=500>
     </a>
     
### Реализован двухуровневый пользовательский фильтр
<a href='https://s26.postimg.org/561ap5fx5/choice.png'>
<img src='https://s26.postimg.org/561ap5fx5/choice.png' width=500>
</a>
     
### Окно создания объявления:
      
 <a href='https://s26.postimg.org/wgc1jgp95/declaration.png'>
      <img src='https://s26.postimg.org/wgc1jgp95/declaration.png' width=500>
      </a>
      
### Данные хранятся в базе данных PostgreSQL, а доступ к ней обеспечивается с помощью Hibernate ORM.

Пользовательские картинки загружаются и сохраняются на сервере с помощью фреймворка Apache Commons FileUpload.

Внешний вид реализован с помощью фреймворков Bootstrap и jQuery.

      В приложении были использованы следующие технологии и библиотеки:
      * Tomcat Servlet Container
      * Hibernate ORM
      * PostgreSQL
      * Apache Commons FileUpload
      * HTML, CSS, Bootstrap, JavaScript, jQuery, Ajax, JSON